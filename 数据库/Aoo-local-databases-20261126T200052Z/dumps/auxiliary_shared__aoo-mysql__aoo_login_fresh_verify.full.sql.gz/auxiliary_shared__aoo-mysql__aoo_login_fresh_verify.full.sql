-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: aoo_login_fresh_verify
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aoo_login_fresh_verify`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aoo_login_fresh_verify` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `aoo_login_fresh_verify`;

--
-- Table structure for table `activity_check_in`
--

DROP TABLE IF EXISTS `activity_check_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_check_in` (
  `player_id` bigint NOT NULL,
  `activity_code` varchar(64) NOT NULL,
  `activity_version` bigint NOT NULL,
  `business_date` date NOT NULL,
  `streak` int NOT NULL,
  `created_at_ms` bigint NOT NULL,
  PRIMARY KEY (`player_id`,`activity_code`,`business_date`),
  KEY `fk_activity_checkin_version` (`activity_code`,`activity_version`),
  CONSTRAINT `fk_activity_checkin_version` FOREIGN KEY (`activity_code`, `activity_version`) REFERENCES `activity_version` (`activity_code`, `version`),
  CONSTRAINT `activity_check_in_chk_1` CHECK ((`streak` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_check_in`
--

LOCK TABLES `activity_check_in` WRITE;
/*!40000 ALTER TABLE `activity_check_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_check_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_mission_progress`
--

DROP TABLE IF EXISTS `activity_mission_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_mission_progress` (
  `player_id` bigint NOT NULL,
  `activity_code` varchar(64) NOT NULL,
  `activity_version` bigint NOT NULL,
  `mission_code` varchar(64) NOT NULL,
  `progress_value` bigint NOT NULL,
  PRIMARY KEY (`player_id`,`activity_code`,`activity_version`,`mission_code`),
  KEY `fk_activity_progress_mission` (`activity_code`,`activity_version`,`mission_code`),
  CONSTRAINT `fk_activity_progress_mission` FOREIGN KEY (`activity_code`, `activity_version`, `mission_code`) REFERENCES `activity_mission_version` (`activity_code`, `activity_version`, `mission_code`),
  CONSTRAINT `activity_mission_progress_chk_1` CHECK ((`progress_value` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_mission_progress`
--

LOCK TABLES `activity_mission_progress` WRITE;
/*!40000 ALTER TABLE `activity_mission_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_mission_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_mission_version`
--

DROP TABLE IF EXISTS `activity_mission_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_mission_version` (
  `activity_code` varchar(64) NOT NULL,
  `activity_version` bigint NOT NULL,
  `mission_code` varchar(64) NOT NULL,
  `event_type` varchar(64) NOT NULL,
  `target_value` bigint NOT NULL,
  `reward_currency` varchar(32) NOT NULL,
  `reward_amount` bigint NOT NULL,
  PRIMARY KEY (`activity_code`,`activity_version`,`mission_code`),
  CONSTRAINT `fk_activity_mission_version` FOREIGN KEY (`activity_code`, `activity_version`) REFERENCES `activity_version` (`activity_code`, `version`),
  CONSTRAINT `activity_mission_version_chk_1` CHECK ((`target_value` > 0)),
  CONSTRAINT `activity_mission_version_chk_2` CHECK ((`reward_amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_mission_version`
--

LOCK TABLES `activity_mission_version` WRITE;
/*!40000 ALTER TABLE `activity_mission_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_mission_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_progress_event`
--

DROP TABLE IF EXISTS `activity_progress_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_progress_event` (
  `event_id` varchar(128) NOT NULL,
  `player_id` bigint NOT NULL,
  `activity_code` varchar(64) NOT NULL,
  `activity_version` bigint NOT NULL,
  `mission_code` varchar(64) NOT NULL,
  `delta_value` bigint NOT NULL,
  `created_at_ms` bigint NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `fk_activity_progress_event_mission` (`activity_code`,`activity_version`,`mission_code`),
  CONSTRAINT `fk_activity_progress_event_mission` FOREIGN KEY (`activity_code`, `activity_version`, `mission_code`) REFERENCES `activity_mission_version` (`activity_code`, `activity_version`, `mission_code`),
  CONSTRAINT `activity_progress_event_chk_1` CHECK ((`delta_value` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_progress_event`
--

LOCK TABLES `activity_progress_event` WRITE;
/*!40000 ALTER TABLE `activity_progress_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_progress_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_reward_claim`
--

DROP TABLE IF EXISTS `activity_reward_claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_reward_claim` (
  `claim_key` varchar(191) NOT NULL,
  `player_id` bigint NOT NULL,
  `activity_code` varchar(64) NOT NULL,
  `activity_version` bigint NOT NULL,
  `claim_type` varchar(16) NOT NULL,
  `subject_code` varchar(64) NOT NULL,
  `reward_currency` varchar(32) NOT NULL,
  `reward_amount` bigint NOT NULL,
  `state` varchar(16) NOT NULL,
  `failure_code` varchar(64) DEFAULT NULL,
  `created_at_ms` bigint NOT NULL,
  `updated_at_ms` bigint NOT NULL,
  PRIMARY KEY (`claim_key`),
  KEY `fk_activity_claim_version` (`activity_code`,`activity_version`),
  KEY `idx_activity_claim_player` (`player_id`,`activity_code`,`activity_version`,`state`),
  CONSTRAINT `fk_activity_claim_version` FOREIGN KEY (`activity_code`, `activity_version`) REFERENCES `activity_version` (`activity_code`, `version`),
  CONSTRAINT `activity_reward_claim_chk_1` CHECK ((`reward_amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_reward_claim`
--

LOCK TABLES `activity_reward_claim` WRITE;
/*!40000 ALTER TABLE `activity_reward_claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_reward_claim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_version`
--

DROP TABLE IF EXISTS `activity_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_version` (
  `activity_code` varchar(64) NOT NULL,
  `version` bigint NOT NULL,
  `title` varchar(128) NOT NULL,
  `starts_at_ms` bigint NOT NULL,
  `ends_at_ms` bigint NOT NULL,
  `time_zone` varchar(64) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at_ms` bigint NOT NULL,
  PRIMARY KEY (`activity_code`,`version`),
  KEY `idx_activity_version_window` (`published`,`starts_at_ms`,`ends_at_ms`),
  CONSTRAINT `activity_version_chk_1` CHECK ((`ends_at_ms` > `starts_at_ms`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_version`
--

LOCK TABLES `activity_version` WRITE;
/*!40000 ALTER TABLE `activity_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_authorization_audit`
--

DROP TABLE IF EXISTS `admin_authorization_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_authorization_audit` (
  `audit_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_id` varchar(128) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `permission_code` varchar(96) NOT NULL,
  `http_method` varchar(8) NOT NULL,
  `request_path` varchar(256) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `occurred_at` datetime(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_admin_auth_operator` (`operator_id`,`occurred_at`),
  KEY `idx_admin_auth_denial` (`decision`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_authorization_audit`
--

LOCK TABLES `admin_authorization_audit` WRITE;
/*!40000 ALTER TABLE `admin_authorization_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_authorization_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_browser_session`
--

DROP TABLE IF EXISTS `admin_browser_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_browser_session` (
  `session_hash` char(64) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `csrf_hash` char(64) NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `last_seen_at` datetime(3) NOT NULL,
  `revoked_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`session_hash`),
  KEY `idx_admin_session_operator` (`operator_id`,`expires_at`),
  KEY `idx_admin_session_expiry` (`expires_at`),
  CONSTRAINT `fk_admin_session_operator` FOREIGN KEY (`operator_id`) REFERENCES `admin_operator_account` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_browser_session`
--

LOCK TABLES `admin_browser_session` WRITE;
/*!40000 ALTER TABLE `admin_browser_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_browser_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_command_dedup`
--

DROP TABLE IF EXISTS `admin_command_dedup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_command_dedup` (
  `request_id` varchar(128) NOT NULL,
  `resource_type` varchar(64) NOT NULL,
  `resource_id` varchar(128) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `response_json` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`request_id`),
  KEY `idx_admin_command_resource` (`resource_type`,`resource_id`,`created_at`),
  KEY `idx_admin_command_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_command_dedup`
--

LOCK TABLES `admin_command_dedup` WRITE;
/*!40000 ALTER TABLE `admin_command_dedup` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_command_dedup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_control_resource`
--

DROP TABLE IF EXISTS `admin_control_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_control_resource` (
  `resource_type` varchar(64) NOT NULL,
  `resource_id` varchar(128) NOT NULL,
  `payload_json` json NOT NULL,
  `updated_by` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`resource_type`,`resource_id`),
  KEY `idx_admin_resource_updated` (`resource_type`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_control_resource`
--

LOCK TABLES `admin_control_resource` WRITE;
/*!40000 ALTER TABLE `admin_control_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_control_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operator_account`
--

DROP TABLE IF EXISTS `admin_operator_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_operator_account` (
  `operator_id` bigint unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `credential_verifier` varchar(512) NOT NULL COMMENT 'PBKDF2-SHA256 iterations:base64-salt:base64-digest',
  `enabled` tinyint NOT NULL DEFAULT '1',
  `password_changed_at` datetime(3) NOT NULL,
  PRIMARY KEY (`operator_id`),
  UNIQUE KEY `uk_admin_operator_username` (`username`),
  CONSTRAINT `chk_admin_operator_enabled` CHECK ((`enabled` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operator_account`
--

LOCK TABLES `admin_operator_account` WRITE;
/*!40000 ALTER TABLE `admin_operator_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_operator_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operator_permission`
--

DROP TABLE IF EXISTS `admin_operator_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_operator_permission` (
  `operator_id` bigint unsigned NOT NULL,
  `permission_code` varchar(96) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `granted_by` bigint unsigned NOT NULL,
  `granted_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`operator_id`,`permission_code`),
  KEY `idx_admin_permission_code` (`permission_code`,`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operator_permission`
--

LOCK TABLES `admin_operator_permission` WRITE;
/*!40000 ALTER TABLE `admin_operator_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_operator_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operator_role`
--

DROP TABLE IF EXISTS `admin_operator_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_operator_role` (
  `operator_id` bigint unsigned NOT NULL,
  `role_code` varchar(64) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `granted_by` bigint unsigned NOT NULL,
  `granted_at` datetime(3) NOT NULL,
  PRIMARY KEY (`operator_id`,`role_code`),
  KEY `idx_admin_operator_role` (`role_code`,`enabled`),
  CONSTRAINT `fk_admin_operator_role_role` FOREIGN KEY (`role_code`) REFERENCES `admin_role` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operator_role`
--

LOCK TABLES `admin_operator_role` WRITE;
/*!40000 ALTER TABLE `admin_operator_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_operator_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role`
--

DROP TABLE IF EXISTS `admin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_role` (
  `role_code` varchar(64) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role`
--

LOCK TABLES `admin_role` WRITE;
/*!40000 ALTER TABLE `admin_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permission`
--

DROP TABLE IF EXISTS `admin_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_role_permission` (
  `role_code` varchar(64) NOT NULL,
  `permission_code` varchar(96) NOT NULL,
  `granted_at` datetime(3) NOT NULL,
  PRIMARY KEY (`role_code`,`permission_code`),
  CONSTRAINT `fk_admin_role_permission_role` FOREIGN KEY (`role_code`) REFERENCES `admin_role` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permission`
--

LOCK TABLES `admin_role_permission` WRITE;
/*!40000 ALTER TABLE `admin_role_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_security_nonce`
--

DROP TABLE IF EXISTS `admin_security_nonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_security_nonce` (
  `nonce_namespace` varchar(32) NOT NULL,
  `nonce_value` varchar(128) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `consumed_at` datetime(3) NOT NULL,
  PRIMARY KEY (`nonce_namespace`,`nonce_value`),
  KEY `idx_admin_security_nonce_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_security_nonce`
--

LOCK TABLES `admin_security_nonce` WRITE;
/*!40000 ALTER TABLE `admin_security_nonce` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_security_nonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sensitive_export`
--

DROP TABLE IF EXISTS `admin_sensitive_export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_sensitive_export` (
  `export_id` varchar(128) NOT NULL,
  `definition_code` varchar(64) NOT NULL,
  `scope_code` varchar(96) NOT NULL,
  `row_limit` int unsigned NOT NULL,
  `requester_id` bigint unsigned NOT NULL,
  `approver_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(512) NOT NULL,
  `state` varchar(32) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`export_id`),
  KEY `idx_sensitive_export_requester` (`requester_id`,`updated_at`),
  KEY `idx_sensitive_export_state` (`state`,`updated_at`),
  CONSTRAINT `chk_sensitive_export_rows` CHECK ((`row_limit` between 1 and 100000)),
  CONSTRAINT `chk_sensitive_export_state` CHECK ((`state` in (_utf8mb4'PENDING_APPROVAL',_utf8mb4'APPROVED',_utf8mb4'EXPORTED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sensitive_export`
--

LOCK TABLES `admin_sensitive_export` WRITE;
/*!40000 ALTER TABLE `admin_sensitive_export` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_sensitive_export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sensitive_export_artifact`
--

DROP TABLE IF EXISTS `admin_sensitive_export_artifact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_sensitive_export_artifact` (
  `export_id` varchar(128) NOT NULL,
  `artifact_json` json NOT NULL,
  `content_hash` char(64) NOT NULL,
  `generated_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  PRIMARY KEY (`export_id`),
  KEY `idx_sensitive_artifact_expiry` (`expires_at`),
  CONSTRAINT `fk_sensitive_artifact_export` FOREIGN KEY (`export_id`) REFERENCES `admin_sensitive_export` (`export_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sensitive_export_artifact`
--

LOCK TABLES `admin_sensitive_export_artifact` WRITE;
/*!40000 ALTER TABLE `admin_sensitive_export_artifact` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_sensitive_export_artifact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sensitive_export_audit`
--

DROP TABLE IF EXISTS `admin_sensitive_export_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_sensitive_export_audit` (
  `audit_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `export_id` varchar(128) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `action` varchar(32) NOT NULL,
  `scope_code` varchar(96) NOT NULL,
  `row_count` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `occurred_at` datetime(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_sensitive_audit_export` (`export_id`,`audit_id`),
  KEY `idx_sensitive_audit_operator` (`operator_id`,`occurred_at`),
  CONSTRAINT `fk_sensitive_audit_export` FOREIGN KEY (`export_id`) REFERENCES `admin_sensitive_export` (`export_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sensitive_export_audit`
--

LOCK TABLES `admin_sensitive_export_audit` WRITE;
/*!40000 ALTER TABLE `admin_sensitive_export_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_sensitive_export_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sensitive_export_request`
--

DROP TABLE IF EXISTS `admin_sensitive_export_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_sensitive_export_request` (
  `request_id` varchar(128) NOT NULL,
  `export_id` varchar(128) NOT NULL,
  PRIMARY KEY (`request_id`),
  KEY `fk_sensitive_request_export` (`export_id`),
  CONSTRAINT `fk_sensitive_request_export` FOREIGN KEY (`export_id`) REFERENCES `admin_sensitive_export` (`export_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sensitive_export_request`
--

LOCK TABLES `admin_sensitive_export_request` WRITE;
/*!40000 ALTER TABLE `admin_sensitive_export_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_sensitive_export_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_account`
--

DROP TABLE IF EXISTS `aoo_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account` (
  `account_id` bigint NOT NULL AUTO_INCREMENT,
  `password_hash` varchar(255) DEFAULT NULL,
  `guest_credential_hash` char(64) DEFAULT NULL,
  `recovery_credential_hash` char(64) DEFAULT NULL,
  `guest` tinyint(1) NOT NULL DEFAULT '1',
  `auth_generation` bigint NOT NULL DEFAULT '0',
  `banned_until` timestamp(3) NULL DEFAULT NULL,
  `ban_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `uk_aoo_account_guest` (`guest_credential_hash`),
  UNIQUE KEY `uk_aoo_account_recovery` (`recovery_credential_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account`
--

LOCK TABLES `aoo_account` WRITE;
/*!40000 ALTER TABLE `aoo_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_aoo_account_default_crystal` AFTER INSERT ON `aoo_account` FOR EACH ROW INSERT INTO aoo_currency_balance(player_id,currency,currency_scope_id,balance,version,updated_at)
VALUES(NEW.account_id,'CRYSTAL',0,10000,0,CURRENT_TIMESTAMP(3)) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_account_audit`
--

DROP TABLE IF EXISTS `aoo_account_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` bigint NOT NULL,
  `action_name` varchar(64) NOT NULL,
  `detail_value` varchar(255) NOT NULL,
  `source_ip` varchar(64) NOT NULL,
  `occurred_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_account_audit_owner_time` (`account_id`,`occurred_at`),
  CONSTRAINT `fk_account_audit_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account_audit`
--

LOCK TABLES `aoo_account_audit` WRITE;
/*!40000 ALTER TABLE `aoo_account_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_account_device`
--

DROP TABLE IF EXISTS `aoo_account_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account_device` (
  `account_id` bigint NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `channel_name` varchar(64) NOT NULL,
  `client_version` varchar(64) NOT NULL,
  `first_seen_at` timestamp(3) NOT NULL,
  `last_seen_at` timestamp(3) NOT NULL,
  `revoked_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`,`device_id`),
  CONSTRAINT `fk_account_device_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account_device`
--

LOCK TABLES `aoo_account_device` WRITE;
/*!40000 ALTER TABLE `aoo_account_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_account_identity`
--

DROP TABLE IF EXISTS `aoo_account_identity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account_identity` (
  `identity_id` bigint NOT NULL AUTO_INCREMENT,
  `identity_type` varchar(24) NOT NULL,
  `normalized_value` varchar(255) NOT NULL,
  `value_hash` char(64) NOT NULL,
  `account_id` bigint NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `active_value_hash` char(64) GENERATED ALWAYS AS ((case when (`status` = _utf8mb4'ACTIVE') then `value_hash` else NULL end)) STORED,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`identity_id`),
  UNIQUE KEY `uk_account_identity_active` (`identity_type`,`active_value_hash`),
  KEY `idx_account_identity_owner` (`account_id`,`status`,`identity_type`),
  CONSTRAINT `fk_account_identity_owner` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `ck_account_identity_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DISABLED',_utf8mb4'MIGRATED'))),
  CONSTRAINT `ck_account_identity_type` CHECK ((`identity_type` in (_utf8mb4'DISPLAY_ID',_utf8mb4'ALIAS',_utf8mb4'PHONE',_utf8mb4'WECHAT_UNION',_utf8mb4'WECHAT_OPEN',_utf8mb4'TRUSTED_DEVICE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account_identity`
--

LOCK TABLES `aoo_account_identity` WRITE;
/*!40000 ALTER TABLE `aoo_account_identity` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account_identity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_account_legal_hold`
--

DROP TABLE IF EXISTS `aoo_account_legal_hold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account_legal_hold` (
  `hold_id` char(36) NOT NULL,
  `account_id` bigint NOT NULL,
  `authority_reference` varchar(128) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `placed_by` varchar(128) NOT NULL,
  `placed_at` timestamp(3) NOT NULL,
  `released_by` varchar(128) DEFAULT NULL,
  `released_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`hold_id`),
  KEY `idx_account_hold` (`account_id`,`released_at`),
  CONSTRAINT `fk_account_hold_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account_legal_hold`
--

LOCK TABLES `aoo_account_legal_hold` WRITE;
/*!40000 ALTER TABLE `aoo_account_legal_hold` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account_legal_hold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_account_session`
--

DROP TABLE IF EXISTS `aoo_account_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_account_session` (
  `session_id` char(36) NOT NULL,
  `account_id` bigint NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `token_family` char(36) NOT NULL,
  `access_hash` char(64) NOT NULL,
  `refresh_hash` char(64) NOT NULL,
  `access_expires_at` timestamp(3) NOT NULL,
  `refresh_expires_at` timestamp(3) NOT NULL,
  `auth_generation` bigint NOT NULL,
  `revoked_at` timestamp(3) NULL DEFAULT NULL,
  `revoke_reason` varchar(64) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `uk_account_access_hash` (`access_hash`),
  UNIQUE KEY `uk_account_refresh_hash` (`refresh_hash`),
  KEY `idx_account_session_owner` (`account_id`,`revoked_at`),
  CONSTRAINT `fk_account_session_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_account_session`
--

LOCK TABLES `aoo_account_session` WRITE;
/*!40000 ALTER TABLE `aoo_account_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_account_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_achievement_claim`
--

DROP TABLE IF EXISTS `aoo_achievement_claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_achievement_claim` (
  `player_id` bigint NOT NULL,
  `achievement_code` varchar(64) NOT NULL,
  `business_id` varchar(160) NOT NULL,
  `claimed_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`player_id`,`achievement_code`),
  UNIQUE KEY `business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_achievement_claim`
--

LOCK TABLES `aoo_achievement_claim` WRITE;
/*!40000 ALTER TABLE `aoo_achievement_claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_achievement_claim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_achievement_definition`
--

DROP TABLE IF EXISTS `aoo_achievement_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_achievement_definition` (
  `code` varchar(64) NOT NULL,
  `target_value` bigint NOT NULL,
  `reward_kind` enum('CURRENCY','ITEM') NOT NULL,
  `reward_code` varchar(64) NOT NULL,
  `reward_amount` bigint NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_achievement_definition`
--

LOCK TABLES `aoo_achievement_definition` WRITE;
/*!40000 ALTER TABLE `aoo_achievement_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_achievement_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_achievement_progress`
--

DROP TABLE IF EXISTS `aoo_achievement_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_achievement_progress` (
  `player_id` bigint NOT NULL,
  `achievement_code` varchar(64) NOT NULL,
  `progress` bigint NOT NULL,
  `updated_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`player_id`,`achievement_code`),
  KEY `fk_progress_definition` (`achievement_code`),
  CONSTRAINT `fk_progress_definition` FOREIGN KEY (`achievement_code`) REFERENCES `aoo_achievement_definition` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_achievement_progress`
--

LOCK TABLES `aoo_achievement_progress` WRITE;
/*!40000 ALTER TABLE `aoo_achievement_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_achievement_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_admin_audit`
--

DROP TABLE IF EXISTS `aoo_admin_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_admin_audit` (
  `audit_id` bigint NOT NULL,
  `operator_id` bigint NOT NULL,
  `permission_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_value` json DEFAULT NULL,
  `after_value` json DEFAULT NULL,
  `trace_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_admin_audit_resource` (`resource_type`,`resource_id`,`created_at`),
  KEY `idx_admin_audit_operator` (`operator_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_admin_audit`
--

LOCK TABLES `aoo_admin_audit` WRITE;
/*!40000 ALTER TABLE `aoo_admin_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_admin_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_appeal`
--

DROP TABLE IF EXISTS `aoo_appeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_appeal` (
  `appeal_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `club_id` bigint DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  `appeal_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidence_snapshot` json NOT NULL,
  `resolution` json DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `resolved_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`appeal_id`),
  KEY `idx_appeal_status_time` (`status`,`created_at`),
  KEY `idx_appeal_player_time` (`player_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_appeal`
--

LOCK TABLES `aoo_appeal` WRITE;
/*!40000 ALTER TABLE `aoo_appeal` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_appeal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_archive_run`
--

DROP TABLE IF EXISTS `aoo_archive_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_archive_run` (
  `archive_run_id` bigint unsigned NOT NULL,
  `source_table` varchar(64) NOT NULL,
  `archive_table` varchar(64) NOT NULL,
  `partition_name` varchar(64) DEFAULT NULL,
  `boundary_start` datetime(3) NOT NULL,
  `boundary_end` datetime(3) NOT NULL,
  `source_count` bigint unsigned NOT NULL,
  `archive_count` bigint unsigned NOT NULL,
  `source_hash` char(64) NOT NULL,
  `archive_hash` char(64) NOT NULL,
  `legal_hold_excluded_count` bigint unsigned NOT NULL,
  `reclaimed_bytes` bigint unsigned NOT NULL DEFAULT '0',
  `idempotency_key` varchar(128) NOT NULL,
  `status` varchar(24) NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`archive_run_id`),
  UNIQUE KEY `uk_archive_run_idempotency` (`idempotency_key`),
  KEY `idx_archive_run_status` (`status`,`source_table`,`boundary_end`),
  CONSTRAINT `chk_archive_boundary` CHECK ((`boundary_end` > `boundary_start`)),
  CONSTRAINT `chk_archive_hashes` CHECK ((regexp_like(`source_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`archive_hash`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_archive_status` CHECK ((`status` in (_utf8mb4'DRY_RUN',_utf8mb4'COPYING',_utf8mb4'VERIFYING',_utf8mb4'SWITCHED',_utf8mb4'PURGING',_utf8mb4'SUCCEEDED',_utf8mb4'FAILED',_utf8mb4'ROLLED_BACK')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_archive_run`
--

LOCK TABLES `aoo_archive_run` WRITE;
/*!40000 ALTER TABLE `aoo_archive_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_archive_run` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_archive_success_guard` BEFORE UPDATE ON `aoo_archive_run` FOR EACH ROW BEGIN
    IF NEW.status='SUCCEEDED' AND (
        NEW.completed_at IS NULL
        OR NEW.source_count<>NEW.archive_count
        OR NEW.source_hash<>NEW.archive_hash
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='archive run cannot succeed before count/hash reconciliation';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_backup_manifest`
--

DROP TABLE IF EXISTS `aoo_backup_manifest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_backup_manifest` (
  `backup_id` bigint unsigned NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `backup_type` varchar(16) NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) NOT NULL,
  `binlog_file` varchar(128) NOT NULL,
  `binlog_position` bigint unsigned NOT NULL,
  `gtid_set` text NOT NULL,
  `object_uri` varchar(512) NOT NULL,
  `encrypted` tinyint unsigned NOT NULL,
  `encryption_key_version` varchar(64) NOT NULL,
  `content_hash` char(64) NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `status` varchar(16) NOT NULL,
  PRIMARY KEY (`backup_id`),
  UNIQUE KEY `uk_backup_content` (`environment_code`,`content_hash`),
  KEY `idx_backup_expiry` (`status`,`expires_at`,`backup_id`),
  CONSTRAINT `chk_backup_encrypted` CHECK ((`encrypted` = 1)),
  CONSTRAINT `chk_backup_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_backup_status` CHECK ((`status` in (_utf8mb4'CREATING',_utf8mb4'VERIFIED',_utf8mb4'CORRUPT',_utf8mb4'EXPIRED',_utf8mb4'PURGED'))),
  CONSTRAINT `chk_backup_time` CHECK (((`completed_at` >= `started_at`) and (`expires_at` > `completed_at`))),
  CONSTRAINT `chk_backup_type` CHECK ((`backup_type` in (_utf8mb4'FULL',_utf8mb4'INCREMENTAL',_utf8mb4'BINLOG')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_backup_manifest`
--

LOCK TABLES `aoo_backup_manifest` WRITE;
/*!40000 ALTER TABLE `aoo_backup_manifest` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_backup_manifest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_business_idempotency`
--

DROP TABLE IF EXISTS `aoo_business_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_business_idempotency` (
  `request_id` varchar(64) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `user_id` varchar(128) DEFAULT NULL,
  `operation` varchar(128) DEFAULT NULL,
  `room_id` bigint NOT NULL DEFAULT '0',
  `round_no` int NOT NULL DEFAULT '0',
  `client_request_id` varchar(128) DEFAULT NULL,
  `status` varchar(16) NOT NULL,
  `response_code` int DEFAULT NULL,
  `response_version` varchar(32) DEFAULT NULL,
  `response_schema_version` int DEFAULT NULL,
  `response_payload` json DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  PRIMARY KEY (`request_id`),
  KEY `idx_idempotency_expiry` (`expires_at`),
  KEY `idx_idempotency_business_scope` (`user_id`,`operation`,`room_id`,`round_no`,`client_request_id`),
  KEY `idx_idempotency_result` (`request_id`,`status`,`expires_at`),
  CONSTRAINT `chk_edge_idempotency_result` CHECK ((((`status` = _utf8mb4'COMPLETED') and (`response_code` is not null) and (`response_payload` is not null)) or ((`status` in (_utf8mb4'PROCESSING',_utf8mb4'UNKNOWN')) and (`response_code` is null)))),
  CONSTRAINT `chk_edge_idempotency_status` CHECK ((`status` in (_utf8mb4'PROCESSING',_utf8mb4'COMPLETED',_utf8mb4'UNKNOWN'))),
  CONSTRAINT `chk_idempotency_status` CHECK ((`status` in (_utf8mb4'PROCESSING',_utf8mb4'COMPLETED',_utf8mb4'UNKNOWN')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_business_idempotency`
--

LOCK TABLES `aoo_business_idempotency` WRITE;
/*!40000 ALTER TABLE `aoo_business_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_business_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_capacity_forecast`
--

DROP TABLE IF EXISTS `aoo_capacity_forecast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_capacity_forecast` (
  `forecast_id` bigint unsigned NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `baseline_at` datetime(3) NOT NULL,
  `baseline_rows` bigint unsigned NOT NULL,
  `baseline_bytes` bigint unsigned NOT NULL,
  `daily_row_growth` decimal(20,4) NOT NULL,
  `daily_byte_growth` decimal(20,4) NOT NULL,
  `retention_days` int unsigned DEFAULT NULL,
  `forecast_30d_bytes` bigint unsigned NOT NULL,
  `forecast_90d_bytes` bigint unsigned NOT NULL,
  `forecast_365d_bytes` bigint unsigned NOT NULL,
  `warning_threshold_bytes` bigint unsigned NOT NULL,
  `critical_threshold_bytes` bigint unsigned NOT NULL,
  `model_version` varchar(64) NOT NULL,
  `input_hash` char(64) NOT NULL,
  PRIMARY KEY (`forecast_id`),
  UNIQUE KEY `uk_capacity_forecast` (`table_name`,`environment_code`,`baseline_at`,`model_version`),
  KEY `idx_capacity_threshold` (`environment_code`,`forecast_90d_bytes`,`critical_threshold_bytes`),
  CONSTRAINT `chk_capacity_growth` CHECK (((`daily_row_growth` >= 0) and (`daily_byte_growth` >= 0))),
  CONSTRAINT `chk_capacity_hash` CHECK (regexp_like(`input_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_capacity_horizon` CHECK (((`forecast_30d_bytes` <= `forecast_90d_bytes`) and (`forecast_90d_bytes` <= `forecast_365d_bytes`))),
  CONSTRAINT `chk_capacity_threshold` CHECK ((`critical_threshold_bytes` > `warning_threshold_bytes`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_capacity_forecast`
--

LOCK TABLES `aoo_capacity_forecast` WRITE;
/*!40000 ALTER TABLE `aoo_capacity_forecast` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_capacity_forecast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_card_category`
--

DROP TABLE IF EXISTS `aoo_card_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_card_category` (
  `category_code` varchar(32) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`category_code`),
  CONSTRAINT `chk_card_category_code` CHECK (regexp_like(`category_code`,_utf8mb4'^[A-Z][A-Z0-9_]{0,31}$')),
  CONSTRAINT `chk_card_category_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_card_category`
--

LOCK TABLES `aoo_card_category` WRITE;
/*!40000 ALTER TABLE `aoo_card_category` DISABLE KEYS */;
INSERT INTO `aoo_card_category` VALUES ('LONG_CARD','长牌','ACTIVE','2026-09-26 12:28:16.818'),('MAHJONG','麻将','ACTIVE','2026-09-26 12:28:16.818'),('OTHER','其他','ACTIVE','2026-09-26 12:28:16.818'),('POKER','扑克','ACTIVE','2026-09-26 12:28:16.818'),('WORD_CARD','字牌','ACTIVE','2026-09-26 12:28:16.818');
/*!40000 ALTER TABLE `aoo_card_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_client_feature_flag`
--

DROP TABLE IF EXISTS `aoo_client_feature_flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_client_feature_flag` (
  `flag_key` varchar(128) NOT NULL,
  `platform` varchar(32) NOT NULL DEFAULT '*',
  `channel` varchar(64) NOT NULL DEFAULT '*',
  `enabled` tinyint(1) NOT NULL,
  `flag_value` varchar(1000) DEFAULT NULL,
  `rollout_percent` smallint NOT NULL DEFAULT '100',
  `enabled_from` timestamp(3) NOT NULL,
  `enabled_until` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`flag_key`,`platform`,`channel`),
  KEY `ix_feature_resolution` (`platform`,`channel`,`enabled_from`,`enabled_until`),
  CONSTRAINT `ck_feature_rollout` CHECK ((`rollout_percent` between 0 and 100)),
  CONSTRAINT `ck_feature_window` CHECK (((`enabled_until` is null) or (`enabled_until` > `enabled_from`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_client_feature_flag`
--

LOCK TABLES `aoo_client_feature_flag` WRITE;
/*!40000 ALTER TABLE `aoo_client_feature_flag` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_client_feature_flag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_client_notice`
--

DROP TABLE IF EXISTS `aoo_client_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_client_notice` (
  `id` bigint NOT NULL,
  `platform` varchar(32) NOT NULL DEFAULT '*',
  `channel` varchar(64) NOT NULL DEFAULT '*',
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `severity` varchar(16) NOT NULL,
  `starts_at` timestamp(3) NOT NULL,
  `ends_at` timestamp(3) NULL DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `ix_notice_active` (`enabled`,`starts_at`,`ends_at`),
  CONSTRAINT `ck_notice_severity` CHECK ((`severity` in (_utf8mb4'INFO',_utf8mb4'WARNING',_utf8mb4'CRITICAL')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_client_notice`
--

LOCK TABLES `aoo_client_notice` WRITE;
/*!40000 ALTER TABLE `aoo_client_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_client_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_client_release`
--

DROP TABLE IF EXISTS `aoo_client_release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_client_release` (
  `id` bigint NOT NULL,
  `platform` varchar(32) NOT NULL,
  `channel` varchar(64) NOT NULL,
  `version` varchar(32) NOT NULL,
  `version_code` bigint NOT NULL,
  `min_supported_version` varchar(32) NOT NULL,
  `force_update` tinyint(1) NOT NULL DEFAULT '0',
  `rollout_percent` smallint NOT NULL DEFAULT '100',
  `rollback_version` varchar(32) DEFAULT NULL,
  `download_url` varchar(1024) NOT NULL,
  `state` varchar(24) NOT NULL,
  `published_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_client_release` (`platform`,`channel`,`version`),
  KEY `ix_release_resolution` (`platform`,`channel`,`state`,`published_at`,`version_code`),
  CONSTRAINT `ck_release_rollout` CHECK ((`rollout_percent` between 0 and 100)),
  CONSTRAINT `ck_release_state` CHECK ((`state` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'ROLLED_BACK',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_client_release`
--

LOCK TABLES `aoo_client_release` WRITE;
/*!40000 ALTER TABLE `aoo_client_release` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_client_release` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_guard`
--

DROP TABLE IF EXISTS `aoo_club_guard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_guard` (
  `club_id` bigint unsigned NOT NULL,
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`club_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_guard`
--

LOCK TABLES `aoo_club_guard` WRITE;
/*!40000 ALTER TABLE `aoo_club_guard` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_guard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_ledger`
--

DROP TABLE IF EXISTS `aoo_club_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_ledger` (
  `club_id` bigint unsigned NOT NULL,
  `business_key` varchar(160) NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `amount` decimal(20,4) NOT NULL,
  `reason` varchar(160) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`club_id`,`business_key`),
  KEY `ix_club_ledger_player` (`club_id`,`player_id`,`created_at`),
  CONSTRAINT `chk_club_ledger_nonzero` CHECK ((`amount` <> 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_ledger`
--

LOCK TABLES `aoo_club_ledger` WRITE;
/*!40000 ALTER TABLE `aoo_club_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_member`
--

DROP TABLE IF EXISTS `aoo_club_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_member` (
  `club_id` bigint unsigned NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `member_status` varchar(16) NOT NULL,
  `member_role` varchar(16) NOT NULL,
  `online` tinyint NOT NULL DEFAULT '0',
  `profile_payload` json NOT NULL,
  `joined_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`club_id`,`player_id`),
  UNIQUE KEY `uk_club_member_business` (`club_id`,`player_id`),
  KEY `idx_club_member_page` (`club_id`,`member_status`,`player_id`),
  KEY `idx_club_online_page` (`club_id`,`online`,`player_id`),
  KEY `idx_club_manager_online` (`club_id`,`member_role`,`online`,`player_id`),
  KEY `idx_player_clubs` (`player_id`,`member_status`,`club_id`),
  CONSTRAINT `chk_club_member_identity` CHECK (((`club_id` > 0) and (`player_id` > 0))),
  CONSTRAINT `chk_club_member_revision` CHECK ((`row_version` > 0)),
  CONSTRAINT `chk_club_member_status` CHECK (((`member_status` in (_utf8mb4'ACTIVE',_utf8mb4'SUSPENDED',_utf8mb4'LEFT')) and (`online` in (0,1))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_member`
--

LOCK TABLES `aoo_club_member` WRITE;
/*!40000 ALTER TABLE `aoo_club_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_room_projection`
--

DROP TABLE IF EXISTS `aoo_club_room_projection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_room_projection` (
  `club_id` bigint unsigned NOT NULL,
  `room_id` varchar(64) NOT NULL,
  `template_code` varchar(64) NOT NULL,
  `room_status` varchar(16) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`club_id`,`room_id`),
  KEY `ix_club_room_display` (`club_id`,`room_status`,`created_at`),
  CONSTRAINT `chk_club_room_status` CHECK ((`room_status` in (_utf8mb4'OPEN',_utf8mb4'PLAYING',_utf8mb4'FINISHED',_utf8mb4'DISSOLVED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_room_projection`
--

LOCK TABLES `aoo_club_room_projection` WRITE;
/*!40000 ALTER TABLE `aoo_club_room_projection` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_room_projection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_state`
--

DROP TABLE IF EXISTS `aoo_club_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_state` (
  `club_id` bigint unsigned NOT NULL,
  `state_json` json NOT NULL,
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`club_id`),
  CONSTRAINT `chk_club_state_revision` CHECK ((`row_version` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_state`
--

LOCK TABLES `aoo_club_state` WRITE;
/*!40000 ALTER TABLE `aoo_club_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_template_index`
--

DROP TABLE IF EXISTS `aoo_club_template_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_template_index` (
  `club_id` bigint unsigned NOT NULL,
  `template_code` varchar(64) NOT NULL,
  `sort_index` int unsigned NOT NULL,
  PRIMARY KEY (`club_id`,`template_code`),
  UNIQUE KEY `uk_club_template_sort` (`club_id`,`sort_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_template_index`
--

LOCK TABLES `aoo_club_template_index` WRITE;
/*!40000 ALTER TABLE `aoo_club_template_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_template_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_club_write_idempotency`
--

DROP TABLE IF EXISTS `aoo_club_write_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_club_write_idempotency` (
  `scope_key` varchar(160) NOT NULL,
  `response_json` text NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`scope_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_club_write_idempotency`
--

LOCK TABLES `aoo_club_write_idempotency` WRITE;
/*!40000 ALTER TABLE `aoo_club_write_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_club_write_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_competition_event`
--

DROP TABLE IF EXISTS `aoo_competition_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_competition_event` (
  `event_id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `event_type` varchar(48) NOT NULL,
  `payload_json` json NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `idx_competition_event_player` (`player_id`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_competition_event`
--

LOCK TABLES `aoo_competition_event` WRITE;
/*!40000 ALTER TABLE `aoo_competition_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_competition_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_competition_idempotency`
--

DROP TABLE IF EXISTS `aoo_competition_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_competition_idempotency` (
  `player_id` bigint NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `operation` varchar(24) NOT NULL,
  `response_json` json NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`player_id`,`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_competition_idempotency`
--

LOCK TABLES `aoo_competition_idempotency` WRITE;
/*!40000 ALTER TABLE `aoo_competition_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_competition_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_compiled_index_active`
--

DROP TABLE IF EXISTS `aoo_compiled_index_active`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_compiled_index_active` (
  `game_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `index_generation` bigint unsigned NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `cache_epoch` bigint unsigned NOT NULL,
  `activated_by` bigint unsigned NOT NULL,
  `activation_reason` varchar(500) NOT NULL,
  `activated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`,`region_code`),
  UNIQUE KEY `uk_compiled_active_release_region` (`release_id`,`region_code`),
  KEY `idx_compiled_active_direct` (`game_id`,`region_code`,`play_version`,`index_generation`),
  KEY `fk_compiled_active_index_release` (`game_id`,`region_code`,`play_version`,`index_generation`,`release_id`),
  CONSTRAINT `fk_compiled_active_index_release` FOREIGN KEY (`game_id`, `region_code`, `play_version`, `index_generation`, `release_id`) REFERENCES `aoo_compiled_room_create_index` (`game_id`, `region_code`, `play_version`, `index_generation`, `release_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_compiled_active_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_compiled_active_epoch` CHECK ((`cache_epoch` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_compiled_index_active`
--

LOCK TABLES `aoo_compiled_index_active` WRITE;
/*!40000 ALTER TABLE `aoo_compiled_index_active` DISABLE KEYS */;
INSERT INTO `aoo_compiled_index_active` VALUES (8,'CN-51-01','1.0.0',2026091002,2034091002,6,1,'Publish CD201 PDK common bundle','2026-09-26 12:28:20.039'),(629,'CN-51-10','legacy-equivalent-1',2026090706,6292026090706,4,1,'Regional PDK optional room restrictions','2026-09-26 12:28:19.908'),(90005,'CN-51-34','xqp-equivalent-1',2026090711,900052026090711,9,1,'Repair LS201 UTF-8 publication boundary','2026-09-26 12:28:20.008');
/*!40000 ALTER TABLE `aoo_compiled_index_active` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_compiled_room_create_index`
--

DROP TABLE IF EXISTS `aoo_compiled_room_create_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_compiled_room_create_index` (
  `game_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `index_generation` bigint unsigned NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `component_chain` json NOT NULL,
  `rule_validator` json NOT NULL,
  `ui_schema` json NOT NULL,
  `lookup_hash` char(64) NOT NULL,
  `bundle_hash` char(64) NOT NULL,
  `lifecycle_state` varchar(16) NOT NULL DEFAULT 'STAGED',
  `compiled_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `validated_at` datetime(3) DEFAULT NULL,
  `activated_at` datetime(3) DEFAULT NULL,
  `retired_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`game_id`,`region_code`,`play_version`,`index_generation`),
  UNIQUE KEY `uk_compiled_index_release_region` (`release_id`,`region_code`),
  UNIQUE KEY `uk_compiled_index_release_identity` (`game_id`,`region_code`,`play_version`,`index_generation`,`release_id`),
  KEY `idx_compiled_index_activation` (`lifecycle_state`,`region_code`,`game_id`,`validated_at`),
  KEY `fk_compiled_index_play_version` (`game_id`,`play_version`),
  KEY `fk_compiled_index_region` (`region_code`),
  KEY `fk_compiled_index_release_identity` (`release_id`,`game_id`,`play_version`),
  CONSTRAINT `fk_compiled_index_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_compiled_index_region` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_compiled_index_release_identity` FOREIGN KEY (`release_id`, `game_id`, `play_version`) REFERENCES `aoo_game_release` (`release_id`, `game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_compiled_index_release_region` FOREIGN KEY (`release_id`, `region_code`) REFERENCES `aoo_game_release_region` (`release_id`, `region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_compiled_index_bundle_hash` CHECK (regexp_like(`bundle_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_compiled_index_generation` CHECK ((`index_generation` > 0)),
  CONSTRAINT `chk_compiled_index_lookup_hash` CHECK (regexp_like(`lookup_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_compiled_index_state` CHECK ((`lifecycle_state` in (_utf8mb4'STAGED',_utf8mb4'READY',_utf8mb4'ACTIVE',_utf8mb4'RETIRED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_compiled_room_create_index`
--

LOCK TABLES `aoo_compiled_room_create_index` WRITE;
/*!40000 ALTER TABLE `aoo_compiled_room_create_index` DISABLE KEYS */;
INSERT INTO `aoo_compiled_room_create_index` VALUES (8,'CN-51-01','1.0.0',1,800000001,'[\"com.aoo.bcg.poker.PdkGameProvider@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playFamily\": \"poker:pao-de-kuai\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\"}','2c7db25d642899f2cb8ec5383c4cbe10133494f7f42b5a6af26eeaed30d3d9bf','8477b021f049503a743bac8496d92aed8da1ff4b6f9198628faadd77c6fcef33','RETIRED','2026-09-26 12:28:19.598','2026-09-26 12:28:19.598','2026-09-26 12:28:19.598','2026-09-26 12:28:19.611'),(8,'CN-51-01','1.0.0',2,800000002,'[\"com.aoo.bcg.poker.PdkGameProvider@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [{\"key\": \"basicPatternCapabilities\", \"label\": \"基础牌型（固定支持）\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"单张（固定支持）\", \"value\": \"SINGLE\", \"disabled\": true}, {\"label\": \"对子（固定支持）\", \"value\": \"PAIR\", \"disabled\": true}, {\"label\": \"顺子（固定支持）\", \"value\": \"STRAIGHT\", \"disabled\": true}, {\"label\": \"连对（固定支持）\", \"value\": \"CONSECUTIVE_PAIRS\", \"disabled\": true}, {\"label\": \"炸弹（固定支持）\", \"value\": \"BOMB\", \"disabled\": true}, {\"label\": \"飞机（固定支持）\", \"value\": \"AIRPLANE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"optionalPatternCapabilities\", \"label\": \"可选牌型能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"三带一（公共支持）\", \"value\": \"TRIPLE_WITH_ONE\", \"disabled\": true}, {\"label\": \"三带二（当前玩法启用）\", \"value\": \"TRIPLE_WITH_PAIR\", \"disabled\": true}, {\"label\": \"四带一（需具体玩法开启）\", \"value\": \"FOUR_WITH_ONE\", \"disabled\": true}, {\"label\": \"四带二（当前玩法启用）\", \"value\": \"FOUR_WITH_TWO\", \"disabled\": true}, {\"label\": \"四带三（默认关闭，需具体玩法开启）\", \"value\": \"FOUR_WITH_THREE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"flowCapabilities\", \"label\": \"公共流程能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"准备与发牌\", \"value\": \"READY_DEAL\", \"disabled\": true}, {\"label\": \"轮转、提示、出牌与过牌\", \"value\": \"TURN_HINT_PLAY_PASS\", \"disabled\": true}, {\"label\": \"托管与超时处理\", \"value\": \"TRUSTEE_TIMEOUT\", \"disabled\": true}, {\"label\": \"断线重连与回放\", \"value\": \"RECONNECT_REPLAY\", \"disabled\": true}, {\"label\": \"小结算与大结算\", \"value\": \"SETTLEMENT\", \"disabled\": true}], \"disabled\": true}], \"playFamily\": \"poker:pao-de-kuai\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','cf23a72c1b48cab30a4390624f64d41414120fb412ea90d082becf3472310887','aa0c19508472795dce40e720a5875b878c3681c56a4b66e8144f092ff36752b7','RETIRED','2026-09-26 12:28:19.610','2026-09-26 12:28:19.610','2026-09-26 12:28:19.610','2026-09-26 12:28:19.647'),(8,'CN-51-01','1.0.0',3,8000003,'[\"com.aoo.bcg.poker.PdkGameProvider@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"basicPatternCapabilities\", \"label\": \"基础牌型（固定支持）\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"单张（固定支持）\", \"value\": \"SINGLE\", \"disabled\": true}, {\"label\": \"对子（固定支持）\", \"value\": \"PAIR\", \"disabled\": true}, {\"label\": \"顺子（固定支持）\", \"value\": \"STRAIGHT\", \"disabled\": true}, {\"label\": \"连对（固定支持）\", \"value\": \"CONSECUTIVE_PAIRS\", \"disabled\": true}, {\"label\": \"炸弹（固定支持）\", \"value\": \"BOMB\", \"disabled\": true}, {\"label\": \"飞机（固定支持）\", \"value\": \"AIRPLANE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"optionalPatternCapabilities\", \"label\": \"可选牌型能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"三带一（公共支持）\", \"value\": \"TRIPLE_WITH_ONE\", \"disabled\": true}, {\"label\": \"三带二（当前玩法启用）\", \"value\": \"TRIPLE_WITH_PAIR\", \"disabled\": true}, {\"label\": \"四带一（需具体玩法开启）\", \"value\": \"FOUR_WITH_ONE\", \"disabled\": true}, {\"label\": \"四带二（当前玩法启用）\", \"value\": \"FOUR_WITH_TWO\", \"disabled\": true}, {\"label\": \"四带三（默认关闭，需具体玩法开启）\", \"value\": \"FOUR_WITH_THREE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"flowCapabilities\", \"label\": \"公共流程能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"准备与发牌\", \"value\": \"READY_DEAL\", \"disabled\": true}, {\"label\": \"轮转、提示、出牌与过牌\", \"value\": \"TURN_HINT_PLAY_PASS\", \"disabled\": true}, {\"label\": \"托管与超时处理\", \"value\": \"TRUSTEE_TIMEOUT\", \"disabled\": true}, {\"label\": \"断线重连与回放\", \"value\": \"RECONNECT_REPLAY\", \"disabled\": true}, {\"label\": \"小结算与大结算\", \"value\": \"SETTLEMENT\", \"disabled\": true}], \"disabled\": true}], \"playFamily\": \"poker:pao-de-kuai\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','ede831b04c60754e5a0c74a090dbe0a5f6533150fda4a648a441041769032b6c','d30e2bd2130fda98ae928609c7f7219147376f91bbeb52d458d8a1d7a1f4b515','RETIRED','2026-09-26 12:28:19.646','2026-09-26 12:28:19.646','2026-09-26 12:28:19.646','2026-09-26 12:28:19.856'),(8,'CN-51-01','1.0.0',2026090703,82026090703,'[\"com.aoo.bcg.poker.PdkGameProvider:CD201@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"basicPatternCapabilities\", \"label\": \"基础牌型（固定支持）\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"单张（固定支持）\", \"value\": \"SINGLE\", \"disabled\": true}, {\"label\": \"对子（固定支持）\", \"value\": \"PAIR\", \"disabled\": true}, {\"label\": \"顺子（固定支持）\", \"value\": \"STRAIGHT\", \"disabled\": true}, {\"label\": \"连对（固定支持）\", \"value\": \"CONSECUTIVE_PAIRS\", \"disabled\": true}, {\"label\": \"炸弹（固定支持）\", \"value\": \"BOMB\", \"disabled\": true}, {\"label\": \"飞机（固定支持）\", \"value\": \"AIRPLANE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"optionalPatternCapabilities\", \"label\": \"可选牌型能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"三带一（公共支持）\", \"value\": \"TRIPLE_WITH_ONE\", \"disabled\": true}, {\"label\": \"三带二（当前玩法启用）\", \"value\": \"TRIPLE_WITH_PAIR\", \"disabled\": true}, {\"label\": \"四带一（需具体玩法开启）\", \"value\": \"FOUR_WITH_ONE\", \"disabled\": true}, {\"label\": \"四带二（当前玩法启用）\", \"value\": \"FOUR_WITH_TWO\", \"disabled\": true}, {\"label\": \"四带三（默认关闭，需具体玩法开启）\", \"value\": \"FOUR_WITH_THREE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"flowCapabilities\", \"label\": \"公共流程能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"准备与发牌\", \"value\": \"READY_DEAL\", \"disabled\": true}, {\"label\": \"轮转、提示、出牌与过牌\", \"value\": \"TURN_HINT_PLAY_PASS\", \"disabled\": true}, {\"label\": \"托管与超时处理\", \"value\": \"TRUSTEE_TIMEOUT\", \"disabled\": true}, {\"label\": \"断线重连与回放\", \"value\": \"RECONNECT_REPLAY\", \"disabled\": true}, {\"label\": \"小结算与大结算\", \"value\": \"SETTLEMENT\", \"disabled\": true}], \"disabled\": true}], \"playFamily\": \"poker:pao-de-kuai\", \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','d4fb5b8aaea6be171624229f21a2f2029361c14c35e657463c6bbda55aee294c','e0442cfa9278b83aa68055eee88bfa0117345812e3d1459b493cc017cc9e4fb8','RETIRED','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:20.023'),(8,'CN-51-01','1.0.0',2026091001,2034091001,'[\"com.aoo.bcg.poker.PdkGameProvider:CD201@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"basicPatternCapabilities\", \"label\": \"基础牌型（固定支持）\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"单张（固定支持）\", \"value\": \"SINGLE\", \"disabled\": true}, {\"label\": \"对子（固定支持）\", \"value\": \"PAIR\", \"disabled\": true}, {\"label\": \"顺子（固定支持）\", \"value\": \"STRAIGHT\", \"disabled\": true}, {\"label\": \"连对（固定支持）\", \"value\": \"CONSECUTIVE_PAIRS\", \"disabled\": true}, {\"label\": \"炸弹（固定支持）\", \"value\": \"BOMB\", \"disabled\": true}, {\"label\": \"飞机（固定支持）\", \"value\": \"AIRPLANE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"optionalPatternCapabilities\", \"label\": \"可选牌型能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"三带一（公共支持）\", \"value\": \"TRIPLE_WITH_ONE\", \"disabled\": true}, {\"label\": \"三带二（当前玩法启用）\", \"value\": \"TRIPLE_WITH_PAIR\", \"disabled\": true}, {\"label\": \"四带一（需具体玩法开启）\", \"value\": \"FOUR_WITH_ONE\", \"disabled\": true}, {\"label\": \"四带二（当前玩法启用）\", \"value\": \"FOUR_WITH_TWO\", \"disabled\": true}, {\"label\": \"四带三（默认关闭，需具体玩法开启）\", \"value\": \"FOUR_WITH_THREE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"flowCapabilities\", \"label\": \"公共流程能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"准备与发牌\", \"value\": \"READY_DEAL\", \"disabled\": true}, {\"label\": \"轮转、提示、出牌与过牌\", \"value\": \"TURN_HINT_PLAY_PASS\", \"disabled\": true}, {\"label\": \"托管与超时处理\", \"value\": \"TRUSTEE_TIMEOUT\", \"disabled\": true}, {\"label\": \"断线重连与回放\", \"value\": \"RECONNECT_REPLAY\", \"disabled\": true}, {\"label\": \"小结算与大结算\", \"value\": \"SETTLEMENT\", \"disabled\": true}], \"disabled\": true}], \"playFamily\": \"poker:pao-de-kuai\", \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','a98c2b9dc9186e92643fe718d729c31e6ed03a3b666c02075c02118652284837','a69b9b1d8d251df6fbf8b5a027299420d046a6ba75e087c3ee20ddf287a1bbec','RETIRED','2026-09-26 12:28:20.022','2026-09-26 12:28:20.022','2026-09-26 12:28:20.022','2026-09-26 12:28:20.040'),(8,'CN-51-01','1.0.0',2026091002,2034091002,'[\"com.aoo.bcg.poker.PdkGameProvider:CD201@1.0.0\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"paodekuai-common\", \"fields\": [{\"key\": \"basicPatternCapabilities\", \"label\": \"基础牌型（固定支持）\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"单张（固定支持）\", \"value\": \"SINGLE\", \"disabled\": true}, {\"label\": \"对子（固定支持）\", \"value\": \"PAIR\", \"disabled\": true}, {\"label\": \"顺子（固定支持）\", \"value\": \"STRAIGHT\", \"disabled\": true}, {\"label\": \"连对（固定支持）\", \"value\": \"CONSECUTIVE_PAIRS\", \"disabled\": true}, {\"label\": \"炸弹（固定支持）\", \"value\": \"BOMB\", \"disabled\": true}, {\"label\": \"飞机（固定支持）\", \"value\": \"AIRPLANE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"optionalPatternCapabilities\", \"label\": \"可选牌型能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"三带一（公共支持）\", \"value\": \"TRIPLE_WITH_ONE\", \"disabled\": true}, {\"label\": \"三带二（当前玩法启用）\", \"value\": \"TRIPLE_WITH_PAIR\", \"disabled\": true}, {\"label\": \"四带一（需具体玩法开启）\", \"value\": \"FOUR_WITH_ONE\", \"disabled\": true}, {\"label\": \"四带二（当前玩法启用）\", \"value\": \"FOUR_WITH_TWO\", \"disabled\": true}, {\"label\": \"四带三（默认关闭，需具体玩法开启）\", \"value\": \"FOUR_WITH_THREE\", \"disabled\": true}], \"disabled\": true}, {\"key\": \"flowCapabilities\", \"label\": \"公共流程能力\", \"control\": \"MULTI_SELECT\", \"options\": [{\"label\": \"准备与发牌\", \"value\": \"READY_DEAL\", \"disabled\": true}, {\"label\": \"轮转、提示、出牌与过牌\", \"value\": \"TURN_HINT_PLAY_PASS\", \"disabled\": true}, {\"label\": \"托管与超时处理\", \"value\": \"TRUSTEE_TIMEOUT\", \"disabled\": true}, {\"label\": \"断线重连与回放\", \"value\": \"RECONNECT_REPLAY\", \"disabled\": true}, {\"label\": \"小结算与大结算\", \"value\": \"SETTLEMENT\", \"disabled\": true}], \"disabled\": true}], \"playFamily\": \"poker:pao-de-kuai\", \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','958c429f27d78207e0d883853311a92189ad12d6792384723147d90a7cef5f80','0f7671ce8292eab8a14405e91530710e108ff9d210f64f3970fd7bbafcf0928a','ACTIVE','2026-09-26 12:28:20.039','2026-09-26 12:28:20.039','2026-09-26 12:28:20.039',NULL),(629,'CN-51','legacy-equivalent-1',3,629000003,'[\"business.global.pk.njpdk.NJPDKGameProvider@legacy-equivalent-1\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": []}','2349a4d30302c3ba257fca81f6e4eb8a88be03a530d6d81ed404e420326e0d7f','2bfe4532d2c877f70ba43cbb41da40b2ea920d9f8964dcae59c076843dbdfc2a','RETIRED','2026-09-26 12:28:19.441','2026-09-26 12:28:19.441','2026-09-26 12:28:19.441','2026-09-26 12:28:19.456'),(629,'CN-51','legacy-equivalent-1',4,629000004,'[\"business.global.pk.njpdk.NJPDKGameProvider@legacy-equivalent-1\"]','{\"seatLimit\": {\"max\": 4, \"min\": 2}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": []}','0a29b1ea3bc28b68d934f4976f9fc4f2a5694b7e8da6bc99563ec89be325c1f8','2bfe4532d2c877f70ba43cbb41da40b2ea920d9f8964dcae59c076843dbdfc2a','RETIRED','2026-09-26 12:28:19.455','2026-09-26 12:28:19.455','2026-09-26 12:28:19.455','2026-09-26 12:28:19.623'),(629,'CN-51-10','legacy-equivalent-1',8,629000008,'[\"com.aoo.bcg.poker.PdkGameProvider:njpdk@legacy-equivalent-1\"]','{\"roundCount\": {\"enum\": [8, 12, 16]}, \"playerCount\": {\"enum\": [2, 3]}, \"dependencies\": [{\"when\": {\"playRule\": \"remove_three_four\", \"playerCount\": 2}, \"deckMode\": \"CUT_40\"}, {\"when\": {\"playerCount\": 3}, \"deckMode\": \"STANDARD_48\"}], \"cardsPerPlayer\": {\"const\": 16}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"njpdk\"}','004313729e14778c2f0465ab8f5c7c7568c7530608ddec4a4c02417a09efc5ca','ffba94598268395e9b14cede44e34a7925da97d5233f58f1284f5431afcdb624','RETIRED','2026-09-26 12:28:19.762','2026-09-26 12:28:19.762','2026-09-26 12:28:19.762','2026-09-26 12:28:19.856'),(629,'CN-51-10','legacy-equivalent-1',2026090703,6292026090703,'[\"com.aoo.bcg.poker.PdkGameProvider:NJ201@legacy-equivalent-1\"]','{\"roundCount\": {\"enum\": [8, 12, 16]}, \"playerCount\": {\"enum\": [2, 3]}, \"dependencies\": [{\"when\": {\"playRule\": \"remove_three_four\", \"playerCount\": 2}, \"deckMode\": \"CUT_40\"}, {\"when\": {\"playerCount\": 3}, \"deckMode\": \"STANDARD_48\"}], \"cardsPerPlayer\": {\"const\": 16}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"NJ201\"}','f70b94e02428bb2cb704ff5724f9fca1763d98b5aafe30d48f348d6e5f4b7b25','bff0abe8da7334a1b6dd56e7e4acef36ee5cbad12abf5e554e2d5218c25ba778','RETIRED','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:19.877'),(629,'CN-51-10','legacy-equivalent-1',2026090704,6292026090704,'[\"com.aoo.bcg.poker.PdkGameProvider:NJ201@legacy-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"NJ201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"NJ201\"}','08f827c19ce5d9ba404f2b175a49c2c23c95693e337c5f6cc4773f7fa4d2d65d','0f3c96f1f26dce831feffa930385aab74642b55ea99646e098b79031911d5f60','RETIRED','2026-09-26 12:28:19.876','2026-09-26 12:28:19.876','2026-09-26 12:28:19.876','2026-09-26 12:28:19.906'),(629,'CN-51-10','legacy-equivalent-1',2026090706,6292026090706,'[\"com.aoo.bcg.poker.PdkGameProvider:NJ201@legacy-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"NJ201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"fields\": [], \"playerCounts\": [2, 3], \"regionalProfile\": \"NJ201\"}','53e28e9b612aeee532fd403c5e6cd4b9c282bdf79efd659174d50a5c262f8c81','08354915865c8e6410529d4a86e7ac31723ff5f2966d7b03d3d47a8ffcfeb4a6','ACTIVE','2026-09-26 12:28:19.906','2026-09-26 12:28:19.906','2026-09-26 12:28:19.906',NULL),(90005,'CN-51-34','xqp-equivalent-1',1,90005000001,'[\"com.aoo.bcg.poker.PdkGameProvider:lspdk@xqp-equivalent-1\"]','{\"roundCount\": {\"enum\": [8, 12, 16]}, \"playerCount\": {\"enum\": [2, 3, 4]}, \"dependencies\": [{\"when\": {\"dealCardCount\": 8}, \"deckMode\": \"LS_7_TO_ACE\", \"configuredFourRank\": 7}, {\"when\": {\"dealCardCount\": 10}, \"deckMode\": \"LS_5_TO_ACE\", \"configuredFourRank\": 5}, {\"when\": {\"robDealerRule\": \"dealer_last\"}, \"requires\": \"competeDealerEnabled\"}, {\"when\": {\"robDealerRule\": \"first_round_no_compete\"}, \"requires\": \"competeDealerEnabled\"}], \"dealCardCount\": {\"enum\": [8, 10]}, \"operationTime\": {\"enum\": [10, 15, 20]}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\"}], \"regionalProfile\": \"lspdk\"}','4cef0779199da2fb638b38fc826d41d63c62444e4510fc136a2a7335b36b0d86','61c924e651ac9478e00f7ca739b17f99faba6b39528875ef4ed3b169abc52016','RETIRED','2026-09-26 12:28:19.755','2026-09-26 12:28:19.755','2026-09-26 12:28:19.755','2026-09-26 12:28:19.856'),(90005,'CN-51-34','xqp-equivalent-1',2026090703,900052026090703,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"roundCount\": {\"enum\": [8, 12, 16]}, \"playerCount\": {\"enum\": [2, 3, 4]}, \"dependencies\": [{\"when\": {\"dealCardCount\": 8}, \"deckMode\": \"LS_7_TO_ACE\", \"configuredFourRank\": 7}, {\"when\": {\"dealCardCount\": 10}, \"deckMode\": \"LS_5_TO_ACE\", \"configuredFourRank\": 5}, {\"when\": {\"robDealerRule\": \"dealer_last\"}, \"requires\": \"competeDealerEnabled\"}, {\"when\": {\"robDealerRule\": \"first_round_no_compete\"}, \"requires\": \"competeDealerEnabled\"}], \"dealCardCount\": {\"enum\": [8, 10]}, \"operationTime\": {\"enum\": [10, 15, 20]}}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\"}], \"regionalProfile\": \"LS201\"}','c39a5cccea7efc2b1602b1a705851ea7333f76106000a27ff70bdc90fcf32f4a','385ae92eaae986933147d7a1f0f4299f69307d14290c5f37683987a8a06f067f','RETIRED','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:19.855','2026-09-26 12:28:19.877'),(90005,'CN-51-34','xqp-equivalent-1',2026090704,900052026090704,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\"}], \"regionalProfile\": \"LS201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\"}], \"regionalProfile\": \"LS201\"}','7136edcdbddf6a27965f28c62978ebd1ba07151af909762902913befd7e8bb3d','fc27080e691099e6b6193a7870ba1043c27289a937a6cb92fd125f2edd78422c','RETIRED','2026-09-26 12:28:19.876','2026-09-26 12:28:19.876','2026-09-26 12:28:19.876','2026-09-26 12:28:19.906'),(90005,'CN-51-34','xqp-equivalent-1',2026090706,900052026090706,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}], \"regionalProfile\": \"LS201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4]}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16]}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20]}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10]}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"]}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}], \"regionalProfile\": \"LS201\"}','ee5e9a0af312275c2c3a3a63ff81a03a2403688816309dd065c775ec65ef7285','3853bc470356687971e9ac6aec14483f1376def3e44b306ce4e98086df5191da','RETIRED','2026-09-26 12:28:19.906','2026-09-26 12:28:19.906','2026-09-26 12:28:19.906','2026-09-26 12:28:19.924'),(90005,'CN-51-34','xqp-equivalent-1',2026090707,900052026090707,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4], \"defaultValue\": 2}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16], \"defaultValue\": 8}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20], \"defaultValue\": 10}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10], \"defaultValue\": 8}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"], \"defaultValue\": \"\\\"no_compare\\\"\"}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"], \"defaultValue\": \"\\\"dealer_first\\\"\"}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}, {\"key\": \"payerMode\", \"title\": \"支付方式\", \"control\": \"RADIO\", \"options\": [\"OWNER\"], \"required\": true, \"defaultValue\": \"OWNER\"}], \"regionalProfile\": \"LS201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4], \"defaultValue\": 2}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16], \"defaultValue\": 8}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20], \"defaultValue\": 10}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10], \"defaultValue\": 8}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"], \"defaultValue\": \"\\\"no_compare\\\"\"}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"], \"defaultValue\": \"\\\"dealer_first\\\"\"}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}, {\"key\": \"payerMode\", \"title\": \"支付方式\", \"control\": \"RADIO\", \"options\": [\"OWNER\"], \"required\": true, \"defaultValue\": \"OWNER\"}], \"regionalProfile\": \"LS201\"}','4c59c7390cf9195532117f9fe162bdbc8adf2007084c1ac028876f62d5433c39','fd0064416955d756f9f5aa79a3aac3a7e2eae3886298ccc9e003a60edb8a0504','RETIRED','2026-09-26 12:28:19.924','2026-09-26 12:28:19.924','2026-09-26 12:28:19.924','2026-09-26 12:28:19.942'),(90005,'CN-51-34','xqp-equivalent-1',2026090708,900052026090708,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4], \"defaultValue\": 2}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16], \"defaultValue\": 8}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20], \"defaultValue\": 10}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10], \"defaultValue\": 8}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"], \"defaultValue\": \"no_compare\"}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"], \"defaultValue\": \"dealer_first\"}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}, {\"key\": \"payerMode\", \"title\": \"支付方式\", \"control\": \"RADIO\", \"options\": [\"OWNER\"], \"required\": true, \"defaultValue\": \"OWNER\"}], \"regionalProfile\": \"LS201\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"title\": \"人数\", \"control\": \"RADIO\", \"default\": 2, \"options\": [2, 3, 4], \"defaultValue\": 2}, {\"key\": \"roundCount\", \"title\": \"局数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 12, 16], \"defaultValue\": 8}, {\"key\": \"operationTime\", \"title\": \"操作时间\", \"control\": \"RADIO\", \"default\": 10, \"options\": [10, 15, 20], \"defaultValue\": 10}, {\"key\": \"dealCardCount\", \"title\": \"发牌张数\", \"control\": \"RADIO\", \"default\": 8, \"options\": [8, 10], \"defaultValue\": 8}, {\"key\": \"jinHuaScore\", \"title\": \"比金花\", \"control\": \"RADIO\", \"default\": \"no_compare\", \"options\": [1, 2, 3, 4, 5, \"no_compare\"], \"defaultValue\": \"no_compare\"}, {\"key\": \"robDealerRule\", \"title\": \"抢庄\", \"control\": \"RADIO\", \"default\": \"dealer_first\", \"options\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"], \"defaultValue\": \"dealer_first\"}, {\"key\": \"playRule\", \"title\": \"玩法\", \"control\": \"CHECKBOX\"}, {\"key\": \"roomRestriction\", \"title\": \"其他\", \"control\": \"CHECKBOX\", \"required\": false}, {\"key\": \"payerMode\", \"title\": \"支付方式\", \"control\": \"RADIO\", \"options\": [\"OWNER\"], \"required\": true, \"defaultValue\": \"OWNER\"}], \"regionalProfile\": \"LS201\"}','cf483805fd4102a164b3e6e7daf75c0d0e0f7cbb267b7c8504d95bfb3d255363','a7d4b4c1df6b4fdde7f98d00011242b1a3da9897cfd4b35c7b022ef1bf417c12','RETIRED','2026-09-26 12:28:19.941','2026-09-26 12:28:19.941','2026-09-26 12:28:19.941','2026-09-26 12:28:19.961'),(90005,'CN-51-34','xqp-equivalent-1',2026090709,900052026090709,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"10秒\", \"value\": 10}, {\"label\": \"15秒\", \"value\": 15}, {\"label\": \"20秒\", \"value\": 20}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 10, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A)\", \"value\": 8}, {\"label\": \"10张(5-A)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": \"no_compare\", \"defaultCandidateIndexes\": [6]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"dealer_first\", \"defaultCandidateIndexes\": [1]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二\", \"value\": \"four_with_two\"}, {\"label\": \"四张A,7\", \"value\": \"four_ace_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全大,全小,全红,全黑,全连,全对\", \"value\": \"all_special_patterns\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"compare_attachments\", \"triple_with_one\", \"four_ace_rank\", \"full_consecutive_pairs\"], \"defaultCandidateIndexes\": [1, 2, 4, 6]}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"ip_limit\", \"timeout_auto_play\", \"distance_warning\", \"chat_muted\"], \"defaultCandidateIndexes\": [1, 3, 4, 6]}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"lspdk\", \"roomRuleViewHash\": \"62b00dd3de701ea184289dda931dca8e937b147134ade8f857d000e6e75403d5\", \"roomRuleWorkbook\": \"开房规则表/跑得快/跑得快可配置规则总表.xlsx\", \"roomRuleSourceHash\": \"514b8f16c72ff048cb778d10b5a61ec4874cbbf148a8ab5a6df558d704236f66\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"10秒\", \"value\": 10}, {\"label\": \"15秒\", \"value\": 15}, {\"label\": \"20秒\", \"value\": 20}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 10, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A)\", \"value\": 8}, {\"label\": \"10张(5-A)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": \"no_compare\", \"defaultCandidateIndexes\": [6]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"dealer_first\", \"defaultCandidateIndexes\": [1]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二\", \"value\": \"four_with_two\"}, {\"label\": \"四张A,7\", \"value\": \"four_ace_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全大,全小,全红,全黑,全连,全对\", \"value\": \"all_special_patterns\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"compare_attachments\", \"triple_with_one\", \"four_ace_rank\", \"full_consecutive_pairs\"], \"defaultCandidateIndexes\": [1, 2, 4, 6]}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"ip_limit\", \"timeout_auto_play\", \"distance_warning\", \"chat_muted\"], \"defaultCandidateIndexes\": [1, 3, 4, 6]}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"lspdk\", \"roomRuleViewHash\": \"62b00dd3de701ea184289dda931dca8e937b147134ade8f857d000e6e75403d5\", \"roomRuleWorkbook\": \"开房规则表/跑得快/跑得快可配置规则总表.xlsx\", \"roomRuleSourceHash\": \"514b8f16c72ff048cb778d10b5a61ec4874cbbf148a8ab5a6df558d704236f66\"}','f0095dcfecece74e442a24bc1162b0e58fb057e876e11b976a03bb996201df94','930e2e4208fb1b6b4989572c21fd74d947fe9693567d1ffc113494f9e8c5f90f','RETIRED','2026-09-26 12:28:19.959','2026-09-26 12:28:19.959','2026-09-26 12:28:19.959','2026-09-26 12:28:19.981'),(90005,'CN-51-34','xqp-equivalent-1',2026090710,900052026090710,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','85031c3c2ad91e8f693a9e91434ce2a1df2b6e4537409e0b377a8c750879d37a','9b08da7ab1af6d260451cdb6c12c6a1e00a196b7befca27ef5c3af1ccc2c565a','RETIRED','2026-09-26 12:28:19.980','2026-09-26 12:28:19.980','2026-09-26 12:28:19.980','2026-09-26 12:28:20.005'),(90005,'CN-51-34','xqp-equivalent-1',2026090711,900052026090711,'[\"com.aoo.bcg.poker.PdkGameProvider:LS201@xqp-equivalent-1\"]','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','3490f23cf0b270309eebb861a4b8124ca13ec45bac5dbda3ab1dcab28d4f1631','c89ac8835699bf4b5376b43302ccd64495b02946dd27a5dddc25b2d7b217d1d9','ACTIVE','2026-09-26 12:28:20.005','2026-09-26 12:28:20.005','2026-09-26 12:28:20.005',NULL);
/*!40000 ALTER TABLE `aoo_compiled_room_create_index` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_compiled_index_immutable_content` BEFORE UPDATE ON `aoo_compiled_room_create_index` FOR EACH ROW BEGIN
    IF OLD.lifecycle_state<>'STAGED' AND (
        NOT (NEW.release_id <=> OLD.release_id)
        OR NOT (NEW.component_chain <=> OLD.component_chain)
        OR NOT (NEW.rule_validator <=> OLD.rule_validator)
        OR NOT (NEW.ui_schema <=> OLD.ui_schema)
        OR NOT (NEW.lookup_hash <=> OLD.lookup_hash)
        OR NOT (NEW.bundle_hash <=> OLD.bundle_hash)
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='validated compiled index content is immutable';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_component_conflict`
--

DROP TABLE IF EXISTS `aoo_component_conflict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_component_conflict` (
  `component_id` bigint unsigned NOT NULL,
  `conflicting_component_id` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`component_id`,`conflicting_component_id`),
  KEY `idx_component_conflict_reverse` (`conflicting_component_id`,`component_id`),
  CONSTRAINT `fk_component_conflict_source` FOREIGN KEY (`component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_component_conflict_target` FOREIGN KEY (`conflicting_component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_component_conflict_order` CHECK ((`component_id` < `conflicting_component_id`)),
  CONSTRAINT `chk_component_conflict_self` CHECK ((`component_id` <> `conflicting_component_id`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_component_conflict`
--

LOCK TABLES `aoo_component_conflict` WRITE;
/*!40000 ALTER TABLE `aoo_component_conflict` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_component_conflict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_component_dependency`
--

DROP TABLE IF EXISTS `aoo_component_dependency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_component_dependency` (
  `component_id` bigint unsigned NOT NULL,
  `required_component_id` bigint unsigned NOT NULL,
  `version_constraint` varchar(128) NOT NULL,
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  `optional_dependency` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`component_id`,`required_component_id`),
  KEY `idx_component_dependency_reverse` (`required_component_id`,`component_id`),
  CONSTRAINT `fk_component_dependency_source` FOREIGN KEY (`component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_component_dependency_target` FOREIGN KEY (`required_component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_component_dependency_optional` CHECK ((`optional_dependency` in (0,1))),
  CONSTRAINT `chk_component_dependency_self` CHECK ((`component_id` <> `required_component_id`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_component_dependency`
--

LOCK TABLES `aoo_component_dependency` WRITE;
/*!40000 ALTER TABLE `aoo_component_dependency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_component_dependency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_component_type`
--

DROP TABLE IF EXISTS `aoo_component_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_component_type` (
  `component_type` varchar(32) NOT NULL,
  `expected_spi_type` varchar(192) NOT NULL,
  `required_for_active_game` tinyint unsigned NOT NULL,
  `lifecycle_order` smallint unsigned NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`component_type`),
  UNIQUE KEY `uk_component_type_order` (`lifecycle_order`),
  CONSTRAINT `chk_component_type_code` CHECK (regexp_like(`component_type`,_utf8mb4'^[A-Z][A-Z0-9_]{0,31}$')),
  CONSTRAINT `chk_component_type_required` CHECK ((`required_for_active_game` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_component_type`
--

LOCK TABLES `aoo_component_type` WRITE;
/*!40000 ALTER TABLE `aoo_component_type` DISABLE KEYS */;
INSERT INTO `aoo_component_type` VALUES ('ACTION','com.aoo.bcg.gamespi.RuleComponent',1,40,'玩家动作处理'),('FLOW','com.aoo.bcg.gamespi.RuleComponent',1,50,'局/盘流程'),('LIFECYCLE','com.aoo.bcg.gamespi.RuleComponent',1,20,'房间生命周期'),('PROVIDER','com.aoo.bcg.gamespi.GameProvider',1,10,'玩法入口与实例化'),('REPLAY','com.aoo.bcg.gamespi.RuleComponent',1,90,'历史事件解释与回放'),('RULE','com.aoo.bcg.gamespi.RuleComponent',1,30,'规则与合法性判断'),('SCORING','com.aoo.bcg.gamespi.RuleComponent',1,60,'算分'),('SETTLEMENT','com.aoo.bcg.gamespi.RuleComponent',1,70,'结算'),('SNAPSHOT','com.aoo.bcg.gamespi.RuleComponent',1,80,'权威快照与恢复'),('UI','com.aoo.bcg.gamespi.RuleComponent',1,100,'创建界面与规则映射');
/*!40000 ALTER TABLE `aoo_component_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_concurrency_contract`
--

DROP TABLE IF EXISTS `aoo_concurrency_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_concurrency_contract` (
  `table_name` varchar(64) NOT NULL,
  `mutation_scope` varchar(128) NOT NULL,
  `concurrency_strategy` varchar(24) NOT NULL,
  `version_column` varchar(64) DEFAULT NULL,
  `update_time_column` varchar(64) DEFAULT NULL,
  `compare_and_set_predicate` varchar(512) NOT NULL,
  `retry_policy` varchar(128) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`table_name`,`mutation_scope`),
  CONSTRAINT `chk_concurrency_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED'))),
  CONSTRAINT `chk_concurrency_strategy` CHECK ((`concurrency_strategy` in (_utf8mb4'ROW_VERSION',_utf8mb4'FENCING_TOKEN',_utf8mb4'APPEND_ONLY',_utf8mb4'BUSINESS_IDEMPOTENCY',_utf8mb4'SERIALIZATION_LOCK',_utf8mb4'CLAIM_TOKEN'))),
  CONSTRAINT `chk_concurrency_version` CHECK (((`concurrency_strategy` not in (_utf8mb4'ROW_VERSION',_utf8mb4'FENCING_TOKEN',_utf8mb4'CLAIM_TOKEN')) or (`version_column` is not null)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_concurrency_contract`
--

LOCK TABLES `aoo_concurrency_contract` WRITE;
/*!40000 ALTER TABLE `aoo_concurrency_contract` DISABLE KEYS */;
INSERT INTO `aoo_concurrency_contract` VALUES ('aoo_business_idempotency','request result','BUSINESS_IDEMPOTENCY',NULL,'created_at','INSERT unique scope+request id','return recorded result','ACTIVE'),('aoo_club_guard','club aggregate','ROW_VERSION','row_version','updated_at','WHERE club_id=? AND row_version=?','bounded deadlock retry','ACTIVE'),('aoo_club_member','club member','ROW_VERSION','row_version','updated_at','WHERE club_id=? AND player_id=? AND row_version=?','club guard then retry','ACTIVE'),('aoo_compiled_index_active','game+region activation','SERIALIZATION_LOCK',NULL,'activated_at','catalog row SELECT FOR UPDATE then atomic upsert','aoo_activate_compiled_game_index','ACTIVE'),('aoo_consumed_event','consumer claim','CLAIM_TOKEN','claim_token','processed_at','WHERE consumer_name=? AND event_id=? AND claim_token=?','repeat stored result','ACTIVE'),('aoo_currency_balance','player currency scope','ROW_VERSION','version','updated_at','WHERE player_id=? AND currency=? AND currency_scope_id=? AND version=?','idempotent ledger transaction retry','ACTIVE'),('aoo_game_catalog','catalog row','ROW_VERSION','row_version','updated_at','WHERE game_id=? AND row_version=?','reject stale editor','ACTIVE'),('aoo_ledger','asset history','BUSINESS_IDEMPOTENCY',NULL,'created_at','INSERT unique business_id','return recorded result','ACTIVE'),('aoo_outbox','publisher claim','CLAIM_TOKEN','claim_token','created_at','WHERE event_id=? AND claim_token=? AND locked_until>?','reclaim after fenced lease expiry','ACTIVE'),('aoo_play_version','play version status','ROW_VERSION','row_version','updated_at','WHERE game_id=? AND play_version=? AND row_version=?','reject stale editor','ACTIVE'),('aoo_region','region row','ROW_VERSION','row_version','updated_at','WHERE region_code=? AND row_version=?','reject stale editor','ACTIVE'),('aoo_room_event','room history','APPEND_ONLY',NULL,'created_at','INSERT unique business identity','write compensation event','ACTIVE'),('aoo_room_lease','room ownership','FENCING_TOKEN','fencing_token','expires_at','WHERE room_id=? AND fencing_token=?','new owner uses larger fencing token','ACTIVE'),('aoo_room_snapshot','room state','FENCING_TOKEN','fencing_token','captured_at','WHERE room_id=? AND fencing_token=? AND state_version=?','reject stale writer','ACTIVE'),('aoo_room_template','template version','ROW_VERSION','row_version','updated_at','WHERE club_id=? AND template_code=? AND template_version=? AND row_version=?','retry from latest immutable version','ACTIVE'),('aoo_settlement','room settlement','BUSINESS_IDEMPOTENCY',NULL,'created_at','INSERT unique business_id','return recorded result','ACTIVE');
/*!40000 ALTER TABLE `aoo_concurrency_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_configuration_cache_epoch`
--

DROP TABLE IF EXISTS `aoo_configuration_cache_epoch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_configuration_cache_epoch` (
  `game_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `cache_epoch` bigint unsigned NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `invalidation_event_id` varchar(64) NOT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`,`region_code`),
  UNIQUE KEY `uk_cache_epoch_event` (`invalidation_event_id`),
  KEY `idx_cache_epoch_release` (`release_id`,`game_id`,`region_code`),
  CONSTRAINT `fk_cache_epoch_active` FOREIGN KEY (`game_id`, `region_code`) REFERENCES `aoo_compiled_index_active` (`game_id`, `region_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_cache_epoch_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_cache_epoch_value` CHECK ((`cache_epoch` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_configuration_cache_epoch`
--

LOCK TABLES `aoo_configuration_cache_epoch` WRITE;
/*!40000 ALTER TABLE `aoo_configuration_cache_epoch` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_configuration_cache_epoch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_connection_generation`
--

DROP TABLE IF EXISTS `aoo_connection_generation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_connection_generation` (
  `user_id` varchar(128) NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `seat_id` int NOT NULL,
  `generation` bigint NOT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`user_id`,`room_id`,`seat_id`),
  CONSTRAINT `chk_connection_generation_positive` CHECK ((`generation` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_connection_generation`
--

LOCK TABLES `aoo_connection_generation` WRITE;
/*!40000 ALTER TABLE `aoo_connection_generation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_connection_generation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_connection_pool_observation`
--

DROP TABLE IF EXISTS `aoo_connection_pool_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_connection_pool_observation` (
  `observation_id` bigint unsigned NOT NULL,
  `service_code` varchar(64) NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `test_scenario` varchar(128) NOT NULL,
  `concurrency` int unsigned NOT NULL,
  `iteration_count` bigint unsigned NOT NULL,
  `connections_before` int unsigned NOT NULL,
  `connections_after` int unsigned NOT NULL,
  `abandoned_connections` int unsigned NOT NULL,
  `open_transactions` int unsigned NOT NULL,
  `stream_cancellations` bigint unsigned NOT NULL,
  `exception_paths` bigint unsigned NOT NULL,
  `duration_ms` bigint unsigned NOT NULL,
  `passed` tinyint unsigned NOT NULL,
  `evidence_uri` varchar(512) NOT NULL,
  `observed_at` datetime(3) NOT NULL,
  PRIMARY KEY (`observation_id`),
  KEY `idx_connection_pool_result` (`passed`,`service_code`,`observed_at`),
  CONSTRAINT `chk_connection_pool_counts` CHECK (((`concurrency` > 0) and (`iteration_count` > 0) and (`duration_ms` > 0))),
  CONSTRAINT `chk_connection_pool_passed` CHECK ((`passed` in (0,1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_connection_pool_observation`
--

LOCK TABLES `aoo_connection_pool_observation` WRITE;
/*!40000 ALTER TABLE `aoo_connection_pool_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_connection_pool_observation` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_connection_pool_score_insert` BEFORE INSERT ON `aoo_connection_pool_observation` FOR EACH ROW BEGIN
    SET NEW.passed=(NEW.connections_after<=NEW.connections_before AND NEW.abandoned_connections=0 AND NEW.open_transactions=0);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_consumed_event`
--

DROP TABLE IF EXISTS `aoo_consumed_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_consumed_event` (
  `consumer_name` varchar(128) NOT NULL,
  `event_id` varchar(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'PROCESSED',
  `claimed_at` datetime(3) DEFAULT NULL,
  `claim_token` char(36) DEFAULT NULL,
  `failure_count` int NOT NULL DEFAULT '0',
  `last_error` varchar(500) DEFAULT NULL,
  `dead_payload` json DEFAULT NULL,
  `dead_at` datetime(3) DEFAULT NULL,
  `replay_count` int NOT NULL DEFAULT '0',
  `processed_at` datetime(3) DEFAULT NULL,
  `result_code` int DEFAULT NULL,
  `result_schema_version` int DEFAULT NULL,
  `result_payload` json DEFAULT NULL,
  PRIMARY KEY (`consumer_name`,`event_id`),
  KEY `idx_consumed_event_retention` (`processed_at`),
  KEY `idx_consumed_event_claim` (`status`,`claimed_at`),
  KEY `idx_consumed_dead_letter` (`status`,`dead_at`),
  KEY `idx_consumed_event_cleanup` (`consumer_name`,`status`,`processed_at`,`event_id`),
  CONSTRAINT `chk_edge_consumer_result` CHECK ((((`status` = _utf8mb4'PROCESSED') and (`processed_at` is not null) and (`result_code` is not null)) or (`status` <> _utf8mb4'PROCESSED'))),
  CONSTRAINT `chk_edge_consumer_status` CHECK ((`status` in (_utf8mb4'PROCESSING',_utf8mb4'RETRY',_utf8mb4'PROCESSED',_utf8mb4'DEAD')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_consumed_event`
--

LOCK TABLES `aoo_consumed_event` WRITE;
/*!40000 ALTER TABLE `aoo_consumed_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_consumed_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_create_ui_choice`
--

DROP TABLE IF EXISTS `aoo_create_ui_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_create_ui_choice` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `option_key` varchar(96) NOT NULL,
  `choice_key` varchar(96) NOT NULL,
  `wire_value` json NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `visible_expression` json DEFAULT NULL,
  PRIMARY KEY (`game_id`,`play_version`,`option_key`,`choice_key`),
  UNIQUE KEY `uk_create_ui_choice_ordinal` (`game_id`,`play_version`,`option_key`,`ordinal`),
  CONSTRAINT `fk_create_ui_choice_option` FOREIGN KEY (`game_id`, `play_version`, `option_key`) REFERENCES `aoo_create_ui_option` (`game_id`, `play_version`, `option_key`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_create_ui_choice`
--

LOCK TABLES `aoo_create_ui_choice` WRITE;
/*!40000 ALTER TABLE `aoo_create_ui_choice` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_create_ui_choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_create_ui_option`
--

DROP TABLE IF EXISTS `aoo_create_ui_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_create_ui_option` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `option_key` varchar(96) NOT NULL,
  `control_type` varchar(24) NOT NULL,
  `title` varchar(128) NOT NULL,
  `default_value` json DEFAULT NULL,
  `required_value` tinyint unsigned NOT NULL DEFAULT '0',
  `visible_expression` json DEFAULT NULL,
  `enabled_expression` json DEFAULT NULL,
  `mutual_exclusion_group` varchar(96) DEFAULT NULL,
  `ordinal` int unsigned NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`game_id`,`play_version`,`option_key`),
  UNIQUE KEY `uk_create_ui_option_ordinal` (`game_id`,`play_version`,`ordinal`),
  CONSTRAINT `fk_create_ui_option_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_create_ui_control` CHECK ((`control_type` in (_utf8mb4'RADIO',_utf8mb4'CHECKBOX',_utf8mb4'SELECT',_utf8mb4'NUMBER',_utf8mb4'TEXT',_utf8mb4'SLIDER',_utf8mb4'HIDDEN'))),
  CONSTRAINT `chk_create_ui_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_create_ui_option_key` CHECK (regexp_like(`option_key`,_utf8mb4'^[a-z][a-zA-Z0-9_.-]{0,95}$')),
  CONSTRAINT `chk_create_ui_required` CHECK ((`required_value` in (0,1))),
  CONSTRAINT `chk_create_ui_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DEPRECATED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_create_ui_option`
--

LOCK TABLES `aoo_create_ui_option` WRITE;
/*!40000 ALTER TABLE `aoo_create_ui_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_create_ui_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_currency_balance`
--

DROP TABLE IF EXISTS `aoo_currency_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_currency_balance` (
  `player_id` bigint unsigned NOT NULL,
  `currency` varchar(32) NOT NULL,
  `currency_scope_id` bigint unsigned NOT NULL DEFAULT '0',
  `balance` bigint NOT NULL DEFAULT '0',
  `version` bigint NOT NULL DEFAULT '0',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`player_id`,`currency`,`currency_scope_id`),
  KEY `idx_currency_balance_catalog` (`currency`,`player_id`,`currency_scope_id`),
  CONSTRAINT `fk_currency_balance_catalog` FOREIGN KEY (`currency`) REFERENCES `aoo_currency_catalog` (`currency_code`),
  CONSTRAINT `chk_currency_balance_non_negative` CHECK ((`balance` >= 0)),
  CONSTRAINT `chk_currency_balance_scope` CHECK ((((`currency` in (_utf8mb4'ROOM_CARD',_utf8mb4'GOLD',_utf8mb4'CRYSTAL')) and (`currency_scope_id` = 0)) or ((`currency` in (_utf8mb4'CITY_ROOM_CARD',_utf8mb4'SPORTS_POINT')) and (`currency_scope_id` > 0))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_currency_balance`
--

LOCK TABLES `aoo_currency_balance` WRITE;
/*!40000 ALTER TABLE `aoo_currency_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_currency_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_currency_catalog`
--

DROP TABLE IF EXISTS `aoo_currency_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_currency_catalog` (
  `currency_code` varchar(32) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `scope_type` varchar(16) NOT NULL,
  `scale_digits` tinyint unsigned NOT NULL DEFAULT '0',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`currency_code`),
  CONSTRAINT `chk_currency_catalog_scale` CHECK ((`scale_digits` <= 6)),
  CONSTRAINT `chk_currency_catalog_scope` CHECK ((`scope_type` in (_utf8mb4'GLOBAL',_utf8mb4'CITY',_utf8mb4'CLUB',_utf8mb4'UNION'))),
  CONSTRAINT `chk_currency_catalog_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_currency_catalog`
--

LOCK TABLES `aoo_currency_catalog` WRITE;
/*!40000 ALTER TABLE `aoo_currency_catalog` DISABLE KEYS */;
INSERT INTO `aoo_currency_catalog` VALUES ('CRYSTAL','水晶','GLOBAL',0,'ACTIVE','2026-09-26 12:28:16.641'),('GOLD','乐豆','GLOBAL',0,'ACTIVE','2026-09-26 12:28:16.641'),('ROOM_CARD','公共房卡','GLOBAL',0,'ACTIVE','2026-09-26 12:28:16.641'),('SPORTS_POINT','赛事积分','UNION',2,'ACTIVE','2026-09-26 12:28:16.641');
/*!40000 ALTER TABLE `aoo_currency_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_lifecycle_policy`
--

DROP TABLE IF EXISTS `aoo_data_lifecycle_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_lifecycle_policy` (
  `data_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hot_days` int NOT NULL,
  `archive_days` int NOT NULL,
  `legal_hold_supported` tinyint(1) NOT NULL,
  `anonymize_on_delete` tinyint(1) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`data_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_lifecycle_policy`
--

LOCK TABLES `aoo_data_lifecycle_policy` WRITE;
/*!40000 ALTER TABLE `aoo_data_lifecycle_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_lifecycle_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_owner`
--

DROP TABLE IF EXISTS `aoo_data_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_owner` (
  `owner_code` varchar(64) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `contact_uri` varchar(256) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`owner_code`),
  CONSTRAINT `chk_data_owner_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_owner`
--

LOCK TABLES `aoo_data_owner` WRITE;
/*!40000 ALTER TABLE `aoo_data_owner` DISABLE KEYS */;
INSERT INTO `aoo_data_owner` VALUES ('CLUB','亲友圈与模板','owner://club','ACTIVE'),('GAME_CATALOG','玩法目录与发布','owner://game-platform','ACTIVE'),('GAME_RUNTIME','房间、事件与回放','owner://game-runtime','ACTIVE'),('PLATFORM_DATA','迁移、治理与运维','owner://data-platform','ACTIVE'),('PLAYER_ASSET','玩家资产与账务','owner://billing','ACTIVE'),('SECURITY_PRIVACY','隐私、留存与审计','owner://security-privacy','ACTIVE');
/*!40000 ALTER TABLE `aoo_data_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_quality_issue`
--

DROP TABLE IF EXISTS `aoo_data_quality_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_quality_issue` (
  `issue_id` bigint unsigned NOT NULL,
  `detector_code` varchar(128) NOT NULL,
  `issue_type` varchar(32) NOT NULL,
  `object_type` varchar(64) NOT NULL,
  `object_key` varchar(256) NOT NULL,
  `evidence` json NOT NULL,
  `evidence_hash` char(64) NOT NULL,
  `severity` varchar(16) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'OPEN',
  `detected_at` datetime(3) NOT NULL,
  `resolved_at` datetime(3) DEFAULT NULL,
  `repair_job_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  UNIQUE KEY `uk_data_quality_evidence` (`detector_code`,`object_type`,`object_key`,`evidence_hash`),
  KEY `idx_data_quality_queue` (`status`,`severity`,`detected_at`,`issue_id`),
  KEY `fk_data_quality_repair` (`repair_job_id`),
  CONSTRAINT `fk_data_quality_repair` FOREIGN KEY (`repair_job_id`) REFERENCES `aoo_data_repair_job` (`repair_job_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_data_quality_hash` CHECK (regexp_like(`evidence_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_data_quality_severity` CHECK ((`severity` in (_utf8mb4'LOW',_utf8mb4'MEDIUM',_utf8mb4'HIGH',_utf8mb4'CRITICAL'))),
  CONSTRAINT `chk_data_quality_status` CHECK ((`status` in (_utf8mb4'OPEN',_utf8mb4'ACKNOWLEDGED',_utf8mb4'REPAIRING',_utf8mb4'RESOLVED',_utf8mb4'FALSE_POSITIVE'))),
  CONSTRAINT `chk_data_quality_type` CHECK ((`issue_type` in (_utf8mb4'INVALID_GAME',_utf8mb4'MISSING_REGION',_utf8mb4'DUPLICATE_TEMPLATE',_utf8mb4'ORPHAN_ROOM',_utf8mb4'BALANCE_MISMATCH',_utf8mb4'BROKEN_REFERENCE',_utf8mb4'INVALID_ENUM',_utf8mb4'INVALID_JSON')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_quality_issue`
--

LOCK TABLES `aoo_data_quality_issue` WRITE;
/*!40000 ALTER TABLE `aoo_data_quality_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_quality_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_repair_approval`
--

DROP TABLE IF EXISTS `aoo_data_repair_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_repair_approval` (
  `repair_job_id` bigint unsigned NOT NULL,
  `approval_role` varchar(24) NOT NULL,
  `approver_id` bigint unsigned NOT NULL,
  `scope_hash` char(64) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `decided_at` datetime(3) NOT NULL,
  PRIMARY KEY (`repair_job_id`,`approval_role`),
  UNIQUE KEY `uk_repair_approval_actor` (`repair_job_id`,`approver_id`),
  CONSTRAINT `fk_repair_approval_job` FOREIGN KEY (`repair_job_id`) REFERENCES `aoo_data_repair_job` (`repair_job_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_repair_approval_decision` CHECK ((`decision` in (_utf8mb4'APPROVED',_utf8mb4'REJECTED'))),
  CONSTRAINT `chk_repair_approval_hash` CHECK (regexp_like(`scope_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_repair_approval_role` CHECK ((`approval_role` in (_utf8mb4'DATA_OWNER',_utf8mb4'DBA',_utf8mb4'SECURITY')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_repair_approval`
--

LOCK TABLES `aoo_data_repair_approval` WRITE;
/*!40000 ALTER TABLE `aoo_data_repair_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_repair_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_repair_audit`
--

DROP TABLE IF EXISTS `aoo_data_repair_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_repair_audit` (
  `repair_job_id` bigint unsigned NOT NULL,
  `audit_sequence` bigint unsigned NOT NULL,
  `action` varchar(24) NOT NULL,
  `actor_id` bigint unsigned NOT NULL,
  `checkpoint` json DEFAULT NULL,
  `affected_rows` bigint unsigned NOT NULL,
  `result_hash` char(64) NOT NULL,
  `detail` json NOT NULL,
  `occurred_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`repair_job_id`,`audit_sequence`),
  CONSTRAINT `fk_data_repair_audit_job` FOREIGN KEY (`repair_job_id`) REFERENCES `aoo_data_repair_job` (`repair_job_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_data_repair_audit_action` CHECK ((`action` in (_utf8mb4'CREATE',_utf8mb4'DRY_RUN',_utf8mb4'APPROVE',_utf8mb4'START',_utf8mb4'CHUNK',_utf8mb4'PAUSE',_utf8mb4'RESUME',_utf8mb4'COMPLETE',_utf8mb4'FAIL',_utf8mb4'ROLLBACK'))),
  CONSTRAINT `chk_data_repair_audit_hash` CHECK (regexp_like(`result_hash`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_repair_audit`
--

LOCK TABLES `aoo_data_repair_audit` WRITE;
/*!40000 ALTER TABLE `aoo_data_repair_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_repair_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_repair_job`
--

DROP TABLE IF EXISTS `aoo_data_repair_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_repair_job` (
  `repair_job_id` bigint unsigned NOT NULL,
  `repair_code` varchar(128) NOT NULL,
  `target_table` varchar(64) NOT NULL,
  `predicate_hash` char(64) NOT NULL,
  `operation_hash` char(64) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `dry_run` tinyint unsigned NOT NULL DEFAULT '1',
  `maximum_rows` bigint unsigned NOT NULL,
  `rows_per_second` int unsigned NOT NULL,
  `chunk_size` int unsigned NOT NULL,
  `resume_checkpoint` json DEFAULT NULL,
  `before_image_location` varchar(512) NOT NULL,
  `rollback_manifest` json NOT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'DRAFT',
  `affected_rows` bigint unsigned NOT NULL DEFAULT '0',
  `started_at` datetime(3) DEFAULT NULL,
  `completed_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`repair_job_id`),
  UNIQUE KEY `uk_data_repair_idempotency` (`idempotency_key`),
  KEY `idx_data_repair_status` (`status`,`target_table`,`repair_job_id`),
  CONSTRAINT `chk_data_repair_approval` CHECK (((`status` not in (_utf8mb4'APPROVED',_utf8mb4'RUNNING',_utf8mb4'SUCCEEDED')) or (`approved_by` is not null))),
  CONSTRAINT `chk_data_repair_dry_run` CHECK ((`dry_run` in (0,1))),
  CONSTRAINT `chk_data_repair_hashes` CHECK ((regexp_like(`predicate_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`operation_hash`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_data_repair_rate` CHECK (((`maximum_rows` > 0) and (`rows_per_second` > 0) and (`chunk_size` > 0) and (`chunk_size` <= `maximum_rows`))),
  CONSTRAINT `chk_data_repair_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'DRY_RUN',_utf8mb4'AWAITING_APPROVAL',_utf8mb4'APPROVED',_utf8mb4'RUNNING',_utf8mb4'PAUSED',_utf8mb4'SUCCEEDED',_utf8mb4'FAILED',_utf8mb4'ROLLED_BACK')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_repair_job`
--

LOCK TABLES `aoo_data_repair_job` WRITE;
/*!40000 ALTER TABLE `aoo_data_repair_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_repair_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_rights_audit`
--

DROP TABLE IF EXISTS `aoo_data_rights_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_rights_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `request_id` char(36) DEFAULT NULL,
  `account_id` bigint NOT NULL,
  `action_name` varchar(64) NOT NULL,
  `actor_type` varchar(16) NOT NULL,
  `actor_ref` varchar(128) NOT NULL,
  `detail_json` json NOT NULL,
  `occurred_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_rights_audit_account` (`account_id`,`occurred_at`),
  KEY `fk_rights_audit_request` (`request_id`),
  CONSTRAINT `fk_rights_audit_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `fk_rights_audit_request` FOREIGN KEY (`request_id`) REFERENCES `aoo_data_rights_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_rights_audit`
--

LOCK TABLES `aoo_data_rights_audit` WRITE;
/*!40000 ALTER TABLE `aoo_data_rights_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_rights_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_data_rights_request`
--

DROP TABLE IF EXISTS `aoo_data_rights_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_data_rights_request` (
  `request_id` char(36) NOT NULL,
  `account_id` bigint NOT NULL,
  `request_type` varchar(16) NOT NULL,
  `status` varchar(24) NOT NULL,
  `requested_at` timestamp(3) NOT NULL,
  `cooling_off_until` timestamp(3) NULL DEFAULT NULL,
  `cancelled_at` timestamp(3) NULL DEFAULT NULL,
  `completed_at` timestamp(3) NULL DEFAULT NULL,
  `result_manifest` json DEFAULT NULL,
  `failure_reason` varchar(255) DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`request_id`),
  KEY `idx_data_rights_owner` (`account_id`,`requested_at`),
  KEY `idx_data_rights_due` (`status`,`cooling_off_until`),
  CONSTRAINT `fk_data_rights_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `chk_data_rights_status` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'COOLING_OFF',_utf8mb4'ON_HOLD',_utf8mb4'RUNNING',_utf8mb4'COMPLETED',_utf8mb4'CANCELLED',_utf8mb4'FAILED'))),
  CONSTRAINT `chk_data_rights_type` CHECK ((`request_type` in (_utf8mb4'EXPORT',_utf8mb4'DELETE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_data_rights_request`
--

LOCK TABLES `aoo_data_rights_request` WRITE;
/*!40000 ALTER TABLE `aoo_data_rights_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_data_rights_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_dead_letter_replay_audit`
--

DROP TABLE IF EXISTS `aoo_dead_letter_replay_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_dead_letter_replay_audit` (
  `replay_id` varchar(64) NOT NULL,
  `consumer_name` varchar(128) NOT NULL,
  `event_id` varchar(64) NOT NULL,
  `payload_sha256` char(64) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `replayed_at` datetime(3) NOT NULL,
  PRIMARY KEY (`replay_id`),
  KEY `idx_dlq_replay_event` (`consumer_name`,`event_id`,`replayed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_dead_letter_replay_audit`
--

LOCK TABLES `aoo_dead_letter_replay_audit` WRITE;
/*!40000 ALTER TABLE `aoo_dead_letter_replay_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_dead_letter_replay_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_deadlock_incident`
--

DROP TABLE IF EXISTS `aoo_deadlock_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_deadlock_incident` (
  `incident_id` bigint unsigned NOT NULL,
  `transaction_code` varchar(128) NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `trace_id` varchar(128) NOT NULL,
  `attempt_count` int unsigned NOT NULL,
  `victim_statement_hash` char(64) NOT NULL,
  `blocker_statement_hash` char(64) NOT NULL,
  `innodb_deadlock_snapshot` json NOT NULL,
  `idempotent_result_preserved` tinyint unsigned NOT NULL,
  `recovered` tinyint unsigned NOT NULL,
  `occurred_at` datetime(3) NOT NULL,
  PRIMARY KEY (`incident_id`),
  KEY `idx_deadlock_incident_transaction` (`transaction_code`,`occurred_at`,`incident_id`),
  CONSTRAINT `fk_deadlock_incident_policy` FOREIGN KEY (`transaction_code`) REFERENCES `aoo_deadlock_retry_policy` (`transaction_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_deadlock_incident_flags` CHECK (((`idempotent_result_preserved` in (0,1)) and (`recovered` in (0,1)))),
  CONSTRAINT `chk_deadlock_incident_hashes` CHECK ((regexp_like(`victim_statement_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`blocker_statement_hash`,_utf8mb4'^[0-9a-f]{64}$')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_deadlock_incident`
--

LOCK TABLES `aoo_deadlock_incident` WRITE;
/*!40000 ALTER TABLE `aoo_deadlock_incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_deadlock_incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_deadlock_retry_policy`
--

DROP TABLE IF EXISTS `aoo_deadlock_retry_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_deadlock_retry_policy` (
  `transaction_code` varchar(128) NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `lock_order` varchar(1000) NOT NULL,
  `idempotency_key_required` tinyint unsigned NOT NULL,
  `maximum_attempts` int unsigned NOT NULL,
  `initial_backoff_ms` int unsigned NOT NULL,
  `maximum_backoff_ms` int unsigned NOT NULL,
  `jitter_percent` decimal(5,2) NOT NULL,
  `retryable_sqlstates` varchar(256) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`transaction_code`),
  KEY `fk_deadlock_policy_owner` (`owner_code`),
  CONSTRAINT `fk_deadlock_policy_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_deadlock_policy_attempts` CHECK (((`maximum_attempts` between 1 and 20) and (`maximum_backoff_ms` >= `initial_backoff_ms`))),
  CONSTRAINT `chk_deadlock_policy_idempotency` CHECK ((`idempotency_key_required` in (0,1))),
  CONSTRAINT `chk_deadlock_policy_jitter` CHECK (((`jitter_percent` >= 0) and (`jitter_percent` <= 100))),
  CONSTRAINT `chk_deadlock_policy_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_deadlock_retry_policy`
--

LOCK TABLES `aoo_deadlock_retry_policy` WRITE;
/*!40000 ALTER TABLE `aoo_deadlock_retry_policy` DISABLE KEYS */;
INSERT INTO `aoo_deadlock_retry_policy` VALUES ('ASSET_DEBIT_AND_LEDGER','PLAYER_ASSET','currency_balance(player_id,currency,scope)->ledger(business_id)->outbox(event_id)',1,5,20,500,25.00,'40001,41000,1213','ACTIVE'),('CLUB_MEMBER_UPDATE','CLUB','club_guard(club_id)->club_member(club_id,player_id)',1,4,25,400,25.00,'40001,41000,1213','ACTIVE'),('CLUB_TEMPLATE_UPDATE','CLUB','club_guard(club_id)->room_template(club_id,template_code,version)',1,4,25,400,25.00,'40001,41000,1213','ACTIVE'),('ROOM_SETTLEMENT','GAME_RUNTIME','room_snapshot(room_id)->settlement(room_id,round_no)->ledger(player_id asc)->outbox(event_id)',1,5,20,500,25.00,'40001,41000,1213','ACTIVE');
/*!40000 ALTER TABLE `aoo_deadlock_retry_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_device_challenge`
--

DROP TABLE IF EXISTS `aoo_device_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_device_challenge` (
  `challenge_id` char(36) NOT NULL,
  `account_id` bigint NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `challenge_hash` char(64) NOT NULL,
  `request_sequence` bigint NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `consumed_at` timestamp(3) NULL DEFAULT NULL,
  `source_ip` varchar(64) NOT NULL,
  PRIMARY KEY (`challenge_id`),
  UNIQUE KEY `uk_device_challenge_sequence` (`account_id`,`device_id`,`request_sequence`),
  CONSTRAINT `fk_device_challenge_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_device_challenge`
--

LOCK TABLES `aoo_device_challenge` WRITE;
/*!40000 ALTER TABLE `aoo_device_challenge` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_device_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_device_pin`
--

DROP TABLE IF EXISTS `aoo_device_pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_device_pin` (
  `account_id` bigint NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `pin_hash` varchar(255) NOT NULL,
  `public_key_pem` text NOT NULL,
  `failed_attempts` int NOT NULL DEFAULT '0',
  `frozen_at` timestamp(3) NULL DEFAULT NULL,
  `credential_version` bigint NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`account_id`,`device_id`),
  CONSTRAINT `fk_device_pin_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_device_pin`
--

LOCK TABLES `aoo_device_pin` WRITE;
/*!40000 ALTER TABLE `aoo_device_pin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_device_pin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_display_id_history`
--

DROP TABLE IF EXISTS `aoo_display_id_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_display_id_history` (
  `history_id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` bigint NOT NULL,
  `old_display_id` varchar(65) DEFAULT NULL,
  `new_display_id` varchar(65) NOT NULL,
  `valid_from` timestamp(3) NOT NULL,
  `valid_until` timestamp(3) NULL DEFAULT NULL,
  `operator_id` bigint DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `source_ip` varchar(64) NOT NULL,
  `trace_id` varchar(128) NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `idx_display_history_value_time` (`new_display_id`,`valid_from`,`valid_until`),
  KEY `idx_display_history_owner_time` (`account_id`,`valid_from`),
  CONSTRAINT `fk_display_history_owner` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_display_id_history`
--

LOCK TABLES `aoo_display_id_history` WRITE;
/*!40000 ALTER TABLE `aoo_display_id_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_display_id_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_display_id_segment`
--

DROP TABLE IF EXISTS `aoo_display_id_segment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_display_id_segment` (
  `digit_length` int NOT NULL,
  `range_start` decimal(65,0) NOT NULL,
  `range_end` decimal(65,0) NOT NULL,
  `capacity` decimal(65,0) NOT NULL,
  `occupied_count` decimal(65,0) NOT NULL DEFAULT '0',
  `allocation_threshold_bps` int NOT NULL DEFAULT '8500',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`digit_length`),
  CONSTRAINT `ck_display_segment_digits` CHECK ((`digit_length` >= 6)),
  CONSTRAINT `ck_display_segment_threshold` CHECK ((`allocation_threshold_bps` between 1 and 10000))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_display_id_segment`
--

LOCK TABLES `aoo_display_id_segment` WRITE;
/*!40000 ALTER TABLE `aoo_display_id_segment` DISABLE KEYS */;
INSERT INTO `aoo_display_id_segment` VALUES (6,100000,999999,900000,0,8500,'ACTIVE','2026-09-26 12:28:19.231');
/*!40000 ALTER TABLE `aoo_display_id_segment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_dual_write_control`
--

DROP TABLE IF EXISTS `aoo_dual_write_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_dual_write_control` (
  `domain_code` varchar(64) NOT NULL,
  `legacy_target` varchar(128) NOT NULL,
  `aoo_target` varchar(128) NOT NULL,
  `authoritative_side` varchar(16) NOT NULL,
  `comparison_window_minutes` int unsigned NOT NULL,
  `max_mismatch_count` bigint unsigned NOT NULL,
  `max_mismatch_ratio` decimal(9,8) NOT NULL,
  `stop_condition` json NOT NULL,
  `rollback_procedure` json NOT NULL,
  `last_reconciled_at` datetime(3) DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'DISABLED',
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`domain_code`),
  CONSTRAINT `chk_dual_write_authority` CHECK ((`authoritative_side` in (_utf8mb4'LEGACY',_utf8mb4'AOO'))),
  CONSTRAINT `chk_dual_write_ratio` CHECK (((`max_mismatch_ratio` >= 0) and (`max_mismatch_ratio` <= 1))),
  CONSTRAINT `chk_dual_write_status` CHECK ((`status` in (_utf8mb4'DISABLED',_utf8mb4'SHADOW',_utf8mb4'DUAL_WRITE',_utf8mb4'AOO_PRIMARY',_utf8mb4'ROLLBACK',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_dual_write_control`
--

LOCK TABLES `aoo_dual_write_control` WRITE;
/*!40000 ALTER TABLE `aoo_dual_write_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_dual_write_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_enum_contract`
--

DROP TABLE IF EXISTS `aoo_enum_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_enum_contract` (
  `enum_code` varchar(64) NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `java_type` varchar(256) DEFAULT NULL,
  `protocol_type` varchar(256) DEFAULT NULL,
  `frontend_type` varchar(256) DEFAULT NULL,
  `compatibility_mode` varchar(16) NOT NULL DEFAULT 'STRICT',
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`enum_code`,`schema_version`),
  KEY `idx_enum_contract_owner` (`owner_code`,`status`,`enum_code`),
  CONSTRAINT `fk_enum_contract_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_enum_contract_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_enum_contract_mode` CHECK ((`compatibility_mode` in (_utf8mb4'STRICT',_utf8mb4'EXPAND_ONLY'))),
  CONSTRAINT `chk_enum_contract_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_enum_contract`
--

LOCK TABLES `aoo_enum_contract` WRITE;
/*!40000 ALTER TABLE `aoo_enum_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_enum_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_enum_value_contract`
--

DROP TABLE IF EXISTS `aoo_enum_value_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_enum_value_contract` (
  `enum_code` varchar(64) NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `wire_value` varchar(64) NOT NULL,
  `numeric_value` bigint DEFAULT NULL,
  `display_name` varchar(128) NOT NULL,
  `deprecated_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`enum_code`,`schema_version`,`wire_value`),
  UNIQUE KEY `uk_enum_numeric_value` (`enum_code`,`schema_version`,`numeric_value`),
  CONSTRAINT `fk_enum_value_contract` FOREIGN KEY (`enum_code`, `schema_version`) REFERENCES `aoo_enum_contract` (`enum_code`, `schema_version`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_enum_value_contract`
--

LOCK TABLES `aoo_enum_value_contract` WRITE;
/*!40000 ALTER TABLE `aoo_enum_value_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_enum_value_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_external_callback_receipt`
--

DROP TABLE IF EXISTS `aoo_external_callback_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_external_callback_receipt` (
  `provider` varchar(32) NOT NULL,
  `event_id` varchar(191) NOT NULL,
  `payload_sha256` char(64) NOT NULL,
  `schema_version` varchar(32) NOT NULL,
  `received_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `processed_at` timestamp(3) NULL DEFAULT NULL,
  `result_code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`provider`,`event_id`),
  CONSTRAINT `ck_callback_payload_sha256` CHECK (regexp_like(`payload_sha256`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_external_callback_receipt`
--

LOCK TABLES `aoo_external_callback_receipt` WRITE;
/*!40000 ALTER TABLE `aoo_external_callback_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_external_callback_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_external_identity`
--

DROP TABLE IF EXISTS `aoo_external_identity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_external_identity` (
  `account_id` bigint NOT NULL,
  `provider` varchar(32) NOT NULL,
  `provider_subject` varchar(191) NOT NULL,
  `union_subject` varchar(191) DEFAULT NULL,
  `credential_version` bigint NOT NULL DEFAULT '1',
  `bound_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`account_id`,`provider`),
  UNIQUE KEY `uk_external_identity_subject` (`provider`,`provider_subject`),
  CONSTRAINT `ck_external_identity_version` CHECK ((`credential_version` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_external_identity`
--

LOCK TABLES `aoo_external_identity` WRITE;
/*!40000 ALTER TABLE `aoo_external_identity` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_external_identity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_catalog`
--

DROP TABLE IF EXISTS `aoo_game_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_catalog` (
  `game_id` bigint unsigned NOT NULL,
  `game_code` varchar(64) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `category_code` varchar(32) NOT NULL,
  `family_code` varchar(64) NOT NULL,
  `provider_key` varchar(192) NOT NULL,
  `catalog_schema_version` int unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'DRAFT',
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`),
  UNIQUE KEY `uk_game_catalog_code` (`game_code`),
  UNIQUE KEY `uk_game_catalog_provider` (`provider_key`),
  KEY `idx_game_catalog_classification` (`category_code`,`family_code`,`status`,`game_id`),
  KEY `fk_game_catalog_family` (`family_code`),
  CONSTRAINT `fk_game_catalog_category` FOREIGN KEY (`category_code`) REFERENCES `aoo_card_category` (`category_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_game_catalog_family` FOREIGN KEY (`family_code`) REFERENCES `aoo_game_family` (`family_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_catalog_code` CHECK ((regexp_like(`game_code`,_utf8mb4'^[a-z][a-z0-9_]{0,63}$') or regexp_like(`game_code`,_utf8mb4'^[A-Z]{2}[1-5][0-9]{2}$'))),
  CONSTRAINT `chk_game_catalog_id` CHECK ((`game_id` > 0)),
  CONSTRAINT `chk_game_catalog_schema_version` CHECK ((`catalog_schema_version` > 0)),
  CONSTRAINT `chk_game_catalog_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'SUSPENDED',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_catalog`
--

LOCK TABLES `aoo_game_catalog` WRITE;
/*!40000 ALTER TABLE `aoo_game_catalog` DISABLE KEYS */;
INSERT INTO `aoo_game_catalog` VALUES (8,'CD201','成都跑得快','POKER','poker:pao-de-kuai','com.aoo.bcg.poker.PdkGameProvider:CD201',1,'ACTIVE',3,'2026-09-26 12:28:19.428','2026-09-26 12:28:19.852'),(629,'NJ201','内江跑得快','POKER','poker:pao-de-kuai','com.aoo.bcg.poker.PdkGameProvider:NJ201',1,'ACTIVE',4,'2026-09-26 12:28:19.426','2026-09-26 12:28:19.853'),(90005,'LS201','凉山跑得快','POKER','poker:pao-de-kuai','com.aoo.bcg.poker.PdkGameProvider:LS201',1,'ACTIVE',2,'2026-09-26 12:28:19.750','2026-09-26 12:28:19.853');
/*!40000 ALTER TABLE `aoo_game_catalog` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_pdk_business_code_insert` BEFORE INSERT ON `aoo_game_catalog` FOR EACH ROW BEGIN
    IF (NEW.game_id=8 AND NEW.game_code<>'CD201')
       OR (NEW.game_id=629 AND NEW.game_code<>'NJ201')
       OR (NEW.game_id=90005 AND NEW.game_code<>'LS201') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='PDK catalog rows require CD201/NJ201/LS201';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_game_catalog_row_version` BEFORE UPDATE ON `aoo_game_catalog` FOR EACH ROW BEGIN
    SET NEW.row_version=OLD.row_version+1;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_pdk_business_code_update` BEFORE UPDATE ON `aoo_game_catalog` FOR EACH ROW BEGIN
    IF (NEW.game_id=8 AND NEW.game_code<>'CD201')
       OR (NEW.game_id=629 AND NEW.game_code<>'NJ201')
       OR (NEW.game_id=90005 AND NEW.game_code<>'LS201') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='PDK catalog rows require CD201/NJ201/LS201';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_game_component`
--

DROP TABLE IF EXISTS `aoo_game_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_component` (
  `component_id` bigint unsigned NOT NULL,
  `component_key` varchar(192) NOT NULL,
  `component_version` varchar(64) NOT NULL,
  `game_id` bigint unsigned DEFAULT NULL,
  `component_type` varchar(32) NOT NULL,
  `spi_type` varchar(192) NOT NULL,
  `implementation_locator` varchar(512) NOT NULL,
  `artifact_digest` char(64) NOT NULL,
  `parameter_schema` json NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'DRAFT',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`component_id`),
  UNIQUE KEY `uk_game_component_key_version` (`component_key`,`component_version`),
  KEY `idx_game_component_lookup` (`game_id`,`component_type`,`status`,`component_version`),
  KEY `fk_game_component_type` (`component_type`),
  CONSTRAINT `fk_game_component_game` FOREIGN KEY (`game_id`) REFERENCES `aoo_game_catalog` (`game_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_game_component_type` FOREIGN KEY (`component_type`) REFERENCES `aoo_component_type` (`component_type`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_component_digest` CHECK (regexp_like(`artifact_digest`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_game_component_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_game_component_id` CHECK ((`component_id` > 0)),
  CONSTRAINT `chk_game_component_key` CHECK (regexp_like(`component_key`,_utf8mb4'^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,191}$')),
  CONSTRAINT `chk_game_component_schema` CHECK ((`schema_version` > 0)),
  CONSTRAINT `chk_game_component_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'VALIDATED',_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_component`
--

LOCK TABLES `aoo_game_component` WRITE;
/*!40000 ALTER TABLE `aoo_game_component` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_game_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_family`
--

DROP TABLE IF EXISTS `aoo_game_family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_family` (
  `family_code` varchar(64) NOT NULL,
  `category_code` varchar(32) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`family_code`),
  KEY `idx_game_family_category` (`category_code`,`status`,`family_code`),
  CONSTRAINT `fk_game_family_category` FOREIGN KEY (`category_code`) REFERENCES `aoo_card_category` (`category_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_family_code` CHECK (regexp_like(`family_code`,_utf8mb4'^[A-Za-z][A-Za-z0-9:_-]{0,63}$')),
  CONSTRAINT `chk_game_family_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_family`
--

LOCK TABLES `aoo_game_family` WRITE;
/*!40000 ALTER TABLE `aoo_game_family` DISABLE KEYS */;
INSERT INTO `aoo_game_family` VALUES ('LONG_CARD_UNCLASSIFIED','LONG_CARD','长牌·待细分','ACTIVE','2026-09-26 12:28:16.820'),('MAHJONG_UNCLASSIFIED','MAHJONG','麻将·待细分','ACTIVE','2026-09-26 12:28:16.820'),('OTHER_UNCLASSIFIED','OTHER','其他·待细分','ACTIVE','2026-09-26 12:28:16.820'),('POKER_UNCLASSIFIED','POKER','扑克·待细分','ACTIVE','2026-09-26 12:28:16.820'),('poker:compare-hand','POKER','比牌','ACTIVE','2026-09-26 12:28:19.565'),('poker:generic-card-round','POKER','通用扑克局','ACTIVE','2026-09-26 12:28:19.565'),('poker:pao-de-kuai','POKER','跑得快','ACTIVE','2026-09-26 12:28:19.565'),('WORD_CARD_UNCLASSIFIED','WORD_CARD','字牌·待细分','ACTIVE','2026-09-26 12:28:16.820');
/*!40000 ALTER TABLE `aoo_game_family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_help_content`
--

DROP TABLE IF EXISTS `aoo_game_help_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_help_content` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `locale_code` varchar(16) NOT NULL,
  `block_ordinal` int unsigned NOT NULL,
  `block_type` varchar(16) NOT NULL,
  `title` varchar(256) DEFAULT NULL,
  `body` text,
  `image_uri` varchar(512) DEFAULT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`game_id`,`play_version`,`locale_code`,`block_ordinal`),
  KEY `idx_game_help_lookup` (`game_id`,`play_version`,`locale_code`,`status`,`block_ordinal`),
  CONSTRAINT `fk_game_help_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_help_block_type` CHECK ((`block_type` in (_utf8mb4'TITLE',_utf8mb4'PARAGRAPH',_utf8mb4'IMAGE',_utf8mb4'LIST'))),
  CONSTRAINT `chk_game_help_content` CHECK (((`title` is not null) or (`body` is not null) or (`image_uri` is not null))),
  CONSTRAINT `chk_game_help_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_game_help_locale` CHECK (regexp_like(`locale_code`,_utf8mb4'^[a-z]{2}(-[A-Z]{2})?$')),
  CONSTRAINT `chk_game_help_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_help_content`
--

LOCK TABLES `aoo_game_help_content` WRITE;
/*!40000 ALTER TABLE `aoo_game_help_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_game_help_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_profile_version`
--

DROP TABLE IF EXISTS `aoo_game_profile_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_profile_version` (
  `profile_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  `profile_version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_payload` json NOT NULL,
  `content_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `uk_game_profile_version` (`game_id`,`profile_version`),
  KEY `idx_game_profile_scope` (`scope_type`,`province_code`,`city_code`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_profile_version`
--

LOCK TABLES `aoo_game_profile_version` WRITE;
/*!40000 ALTER TABLE `aoo_game_profile_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_game_profile_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_region`
--

DROP TABLE IF EXISTS `aoo_game_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_region` (
  `game_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `availability` varchar(16) NOT NULL DEFAULT 'AVAILABLE',
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  `available_from` datetime(3) DEFAULT NULL,
  `available_until` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`,`region_code`),
  KEY `idx_game_region_lookup` (`region_code`,`availability`,`priority`,`game_id`),
  CONSTRAINT `fk_game_region_game` FOREIGN KEY (`game_id`) REFERENCES `aoo_game_catalog` (`game_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_game_region_region` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_region_availability` CHECK ((`availability` in (_utf8mb4'AVAILABLE',_utf8mb4'HIDDEN',_utf8mb4'BLOCKED',_utf8mb4'RETIRED'))),
  CONSTRAINT `chk_game_region_window` CHECK (((`available_until` is null) or (`available_from` is null) or (`available_until` > `available_from`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_region`
--

LOCK TABLES `aoo_game_region` WRITE;
/*!40000 ALTER TABLE `aoo_game_region` DISABLE KEYS */;
INSERT INTO `aoo_game_region` VALUES (8,'CN-51-01','AVAILABLE',10,NULL,NULL,'2026-09-26 12:28:19.597'),(8,'GLOBAL','RETIRED',100,NULL,NULL,'2026-09-26 12:28:19.428'),(629,'CN-51','RETIRED',1,NULL,NULL,'2026-09-26 12:28:19.427'),(629,'CN-51-10','AVAILABLE',1,NULL,NULL,'2026-09-26 12:28:19.585'),(90005,'CN-51-34','AVAILABLE',1,NULL,NULL,'2026-09-26 12:28:19.751');
/*!40000 ALTER TABLE `aoo_game_region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_release`
--

DROP TABLE IF EXISTS `aoo_game_release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_release` (
  `release_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `release_version` bigint unsigned NOT NULL,
  `release_scope` varchar(16) NOT NULL,
  `catalog_snapshot` json NOT NULL,
  `rule_snapshot` json NOT NULL,
  `ui_snapshot` json NOT NULL,
  `component_snapshot` json NOT NULL,
  `catalog_hash` char(64) NOT NULL,
  `rule_hash` char(64) NOT NULL,
  `ui_hash` char(64) NOT NULL,
  `component_hash` char(64) NOT NULL,
  `bundle_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'STAGED',
  `rollout_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `created_by` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `validated_at` datetime(3) DEFAULT NULL,
  `activated_at` datetime(3) DEFAULT NULL,
  `retired_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`release_id`),
  UNIQUE KEY `uk_game_release_version` (`game_id`,`play_version`,`release_version`),
  UNIQUE KEY `uk_game_release_bundle` (`game_id`,`bundle_hash`),
  UNIQUE KEY `uk_game_release_identity` (`release_id`,`game_id`,`play_version`),
  KEY `idx_game_release_status` (`status`,`game_id`,`created_at`),
  CONSTRAINT `fk_game_release_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_release_hashes` CHECK ((regexp_like(`catalog_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`rule_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`ui_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`component_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`bundle_hash`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_game_release_id` CHECK ((`release_id` > 0)),
  CONSTRAINT `chk_game_release_rollout` CHECK (((`rollout_percent` >= 0.00) and (`rollout_percent` <= 100.00))),
  CONSTRAINT `chk_game_release_scope` CHECK ((`release_scope` in (_utf8mb4'GLOBAL',_utf8mb4'REGIONAL',_utf8mb4'CANARY'))),
  CONSTRAINT `chk_game_release_status` CHECK ((`status` in (_utf8mb4'STAGED',_utf8mb4'VALIDATED',_utf8mb4'ACTIVE',_utf8mb4'RETIRED',_utf8mb4'ROLLED_BACK',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_release`
--

LOCK TABLES `aoo_game_release` WRITE;
/*!40000 ALTER TABLE `aoo_game_release` DISABLE KEYS */;
INSERT INTO `aoo_game_release` VALUES (8000003,8,'1.0.0',3,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"provider\": \"com.aoo.bcg.poker.PdkGameProvider\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"1.0.0\"}','e7c0b15d7eb5d9a4a1be8d3961a5236d24163c908e457cc147e5d1d704fc1f80','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','c37846aa2b51ebaa5ada0cbe9837258088b1498857b39ac46476d5006fd3e8d1','7b6ef99244fdfcc413d4a19c780c4be0c1fe85b603036b34dbf360e7fa3460a6','d30e2bd2130fda98ae928609c7f7219147376f91bbeb52d458d8a1d7a1f4b515','RETIRED',100.00,1,'Publish authoritative PDK_CommonRoom bundle','2026-09-26 12:28:19.645','2026-09-26 12:28:19.645','2026-09-26 12:28:19.645','2026-09-26 12:28:19.856'),(629000003,629,'legacy-equivalent-1',3,'REGIONAL','{\"gameId\": 629, \"provider\": \"business.global.pk.njpdk.NJPDKGameProvider\"}','{\"family\": \"poker-pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\"}','{\"providerVersion\": \"legacy-equivalent-1\"}','7f699d9f5c499cc1efcdbac25627c3aa8162c3697c04bca51805a623135e3c14','70c64f5f69562c7538ae1d3cdbc680d66a3d603b75f5116da41724265692a666','d1f2456b88bd698e34f42de321d0abe179b0669bc4d56ce903008f415da5b9f7','fdd12ff34ecdf5adb345745286d11fcdc159a93702fdbcb3b91acd8bac12b56b','2bfe4532d2c877f70ba43cbb41da40b2ea920d9f8964dcae59c076843dbdfc2a','RETIRED',100.00,1,'Creator 3.8.8 native resource route publication','2026-09-26 12:28:19.440','2026-09-26 12:28:19.440','2026-09-26 12:28:19.440','2026-09-26 12:28:19.457'),(629000004,629,'legacy-equivalent-1',4,'REGIONAL','{\"gameId\": 629, \"provider\": \"business.global.pk.njpdk.NJPDKGameProvider\"}','{\"family\": \"poker-pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playerCounts\": [2, 3, 4]}','{\"providerVersion\": \"legacy-equivalent-1\"}','7f699d9f5c499cc1efcdbac25627c3aa8162c3697c04bca51805a623135e3c14','70c64f5f69562c7538ae1d3cdbc680d66a3d603b75f5116da41724265692a666','a9e2f277348be0e89f60f84f95ce05328163d737a6c97582f9c61e80686d9d99','fdd12ff34ecdf5adb345745286d11fcdc159a93702fdbcb3b91acd8bac12b56b','48a3960d76826952b7939728a9cc803ab7bdb7d11924e7ff145fcac7a5ef4e4e','RETIRED',100.00,1,'Publish authoritative 2/3/4-player NJPDK layouts','2026-09-26 12:28:19.454','2026-09-26 12:28:19.454','2026-09-26 12:28:19.454','2026-09-26 12:28:19.572'),(629000005,629,'legacy-equivalent-1',5,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"provider\": \"business.global.pk.njpdk.NJPDKGameProvider\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"bigSettleTemplate\": \"BigSettleTpl_110\"}','{\"providerVersion\": \"legacy-equivalent-1\"}','2411740fb7971877cf4d07686d7a0ff22cdd2927cdc4eb834da4b3a0add60f18','46d2c5c6c36a2ea0deb5d0fcf9863a9abf15baa68e66157c4a25f2ba99798cf5','a09d46bd585821de8106efc006d33ae17df88e51cfb3ff993301cfd654feddbc','fdd12ff34ecdf5adb345745286d11fcdc159a93702fdbcb3b91acd8bac12b56b','445abea1e3f1186b6a85dd6c1a5dba3a63569a82b22d758049ba42fa4350e731','RETIRED',100.00,1,'Versioned canonical Poker family and settlement defaults','2026-09-26 12:28:19.571','2026-09-26 12:28:19.571','2026-09-26 12:28:19.571','2026-09-26 12:28:19.624'),(629000006,629,'legacy-equivalent-1',6,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"provider\": \"business.global.pk.njpdk.NJPDKGameProvider\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"bigSettleTemplate\": \"BigSettleTpl_110\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"legacy-equivalent-1\"}','2411740fb7971877cf4d07686d7a0ff22cdd2927cdc4eb834da4b3a0add60f18','46d2c5c6c36a2ea0deb5d0fcf9863a9abf15baa68e66157c4a25f2ba99798cf5','2d07f0f3c2c35733bdf35daf15c5e9cfd28ac25ae98b64abd927008e267ac3cb','fdd12ff34ecdf5adb345745286d11fcdc159a93702fdbcb3b91acd8bac12b56b','ed53a31fb3805029f92dbc6023ab89f12cfad701ab0c8854caee982b99321dc3','RETIRED',100.00,1,'Inherit PDK public room capabilities without regional UI rules','2026-09-26 12:28:19.621','2026-09-26 12:28:19.621','2026-09-26 12:28:19.621','2026-09-26 12:28:19.764'),(629000008,629,'legacy-equivalent-1',8,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"xqpArea\": 6, \"gameCode\": \"njpdk\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:njpdk\", \"regionCode\": \"CN-51-10\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\", \"profile\": \"neijiang\", \"deckModes\": [\"CUT_40\", \"STANDARD_48\"], \"playerCounts\": [2, 3], \"cardsPerPlayer\": 16}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"PDK/NJPDK/Code/NeijiangPdkRoomProfile\", \"bigSettleTemplate\": \"BigSettleTpl_110\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"legacy-equivalent-1\", \"regionalProvider\": \"native-pdk-neijiang\"}','b82c2030ddb08818312ae8b71a70d3aeeeaa0648c2bbbec38554453acac2018f','ff338d817db3090b045d77991e3ef2dfcbf077cf51d643be702eb31390d05a42','88aca29ef4a9ce548de46a384401d507a6d72320a89950f3400026b792ab3314','250ed2914ad8540af162160d4a01bf9fc2f730ec7f33ab77f8078d34c0b9e515','ffba94598268395e9b14cede44e34a7925da97d5233f58f1284f5431afcdb624','RETIRED',100.00,1,'Publish Neijiang regional profile on common PDK','2026-09-26 12:28:19.760','2026-09-26 12:28:19.760','2026-09-26 12:28:19.760','2026-09-26 12:28:19.856'),(800000001,8,'1.0.0',1,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"provider\": \"com.aoo.bcg.poker.PdkGameProvider\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\"}','{\"providerVersion\": \"1.0.0\"}','e7c0b15d7eb5d9a4a1be8d3961a5236d24163c908e457cc147e5d1d704fc1f80','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','23b88fd21473ba099cd6102deda550eddda86989af854c7d5d4e0b125d90a268','7b6ef99244fdfcc413d4a19c780c4be0c1fe85b603036b34dbf360e7fa3460a6','8477b021f049503a743bac8496d92aed8da1ff4b6f9198628faadd77c6fcef33','RETIRED',100.00,1,'Publish existing native PDK as Chengdu catalog play','2026-09-26 12:28:19.597','2026-09-26 12:28:19.597','2026-09-26 12:28:19.597','2026-09-26 12:28:19.612'),(800000002,8,'1.0.0',2,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"provider\": \"com.aoo.bcg.poker.PdkGameProvider\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"1.0.0\"}','e7c0b15d7eb5d9a4a1be8d3961a5236d24163c908e457cc147e5d1d704fc1f80','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','99ab60f27218feb18ba7165123f9311a83c5b1b53b01a772860ee8756b363785','7b6ef99244fdfcc413d4a19c780c4be0c1fe85b603036b34dbf360e7fa3460a6','aa0c19508472795dce40e720a5875b878c3681c56a4b66e8144f092ff36752b7','RETIRED',100.00,1,'Publish PDK public room rules and fail-closed optional capabilities','2026-09-26 12:28:19.609','2026-09-26 12:28:19.609','2026-09-26 12:28:19.609','2026-09-26 12:28:19.647'),(2034091001,8,'1.0.0',2026091001,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"gameCode\": \"CD201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:CD201\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"1.0.0\", \"regionalProvider\": \"native-pdk-CD201\"}','9b75dc8af434668759236ea4c9a6db8ce8d6cf229798541fb2215fcf1d559f5a','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','7a7a131de8e1050da50e5be70b6007a2f729b30927f478cec1538d71ec8231a4','49300edf4ecd4d22a066f160be552bd9fcfad10b096216a7f59f0b79618b22f4','a69b9b1d8d251df6fbf8b5a027299420d046a6ba75e087c3ee20ddf287a1bbec','RETIRED',100.00,1,'Publish CD201 PDK common-room bundle','2026-09-26 12:28:20.021','2026-09-26 12:28:20.021','2026-09-26 12:28:20.021','2026-09-26 12:28:20.040'),(2034091002,8,'1.0.0',2026091002,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"gameCode\": \"CD201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:CD201\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"paodekuai-common\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"1.0.0\", \"regionalProvider\": \"native-pdk-CD201\"}','9b75dc8af434668759236ea4c9a6db8ce8d6cf229798541fb2215fcf1d559f5a','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','dc14e9ae5ed3e95b50022ac415021de112c1f0d8611f77f1585215229ee1a1d4','49300edf4ecd4d22a066f160be552bd9fcfad10b096216a7f59f0b79618b22f4','0f7671ce8292eab8a14405e91530710e108ff9d210f64f3970fd7bbafcf0928a','ACTIVE',100.00,1,'Publish CD201 PDK common bundle','2026-09-26 12:28:20.038','2026-09-26 12:28:20.038','2026-09-26 12:28:20.038',NULL),(82026090703,8,'1.0.0',2026090703,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 8, \"gameCode\": \"CD201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:CD201\"}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"CD201\", \"bigSettleTemplate\": \"BigSettleTpl_00\", \"smallSettleTemplate\": \"SmallSettleTpl_pdk_00\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"1.0.0\", \"regionalProvider\": \"native-pdk-CD201\"}','9b75dc8af434668759236ea4c9a6db8ce8d6cf229798541fb2215fcf1d559f5a','a1045a2e5bf537afb20debe6d1946ed8c115f37c85bcfce3ad9b9014d9e29772','2cc7dec53408824987318aee6aa36cee66035201f4a05465483dc04cd6357a08','49300edf4ecd4d22a066f160be552bd9fcfad10b096216a7f59f0b79618b22f4','e0442cfa9278b83aa68055eee88bfa0117345812e3d1459b493cc017cc9e4fb8','RETIRED',100.00,1,'Activate stable PDK business code after authorized room-history reset','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:20.024'),(90005000001,90005,'xqp-equivalent-1',1,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"lspdk\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:lspdk\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"PDK/LSPDK/Code/LiangshanPdkRoomProfile\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-liangshan\"}','611b19374c2704bf4a0edf67fef12a24e5eb860f99e610a05833b55bf20d0f3d','bebe73171de181c3428f558b3b45a544b09b17a76f0ff5095aab851bbab10630','6e5f888fbb183be264b8461a1dcc07ada39095237bccfb8d8e8b3baccb8e098f','7cda7fd0dcf53db290db05f4c3a65d648b70596018a2d9a872ee291c94eab575','61c924e651ac9478e00f7ca739b17f99faba6b39528875ef4ed3b169abc52016','RETIRED',100.00,1,'Publish XQP-equivalent Liangshan profile on common PDK','2026-09-26 12:28:19.753','2026-09-26 12:28:19.753','2026-09-26 12:28:19.753','2026-09-26 12:28:19.856'),(6292026090703,629,'legacy-equivalent-1',2026090703,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"xqpArea\": 6, \"gameCode\": \"NJ201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:NJ201\", \"regionCode\": \"CN-51-10\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\", \"profile\": \"neijiang\", \"deckModes\": [\"CUT_40\", \"STANDARD_48\"], \"playerCounts\": [2, 3], \"cardsPerPlayer\": 16}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"NJ201\", \"bigSettleTemplate\": \"BigSettleTpl_110\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"legacy-equivalent-1\", \"regionalProvider\": \"native-pdk-NJ201\"}','42fb64f169d07222222394e735f61b0838edf4e9b912a8224e55521dba6cf4f8','ff338d817db3090b045d77991e3ef2dfcbf077cf51d643be702eb31390d05a42','3faa3f0923a679472dc3a4283742218338a73505168bdb7a42eae6722df535b5','3c3178307f3594ab64d8256e2e266dd63a452eb760d7fe30209d582c484a6b39','bff0abe8da7334a1b6dd56e7e4acef36ee5cbad12abf5e554e2d5218c25ba778','RETIRED',100.00,1,'Activate stable PDK business code after authorized room-history reset','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:19.878'),(6292026090704,629,'legacy-equivalent-1',2026090704,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"xqpArea\": 6, \"gameCode\": \"NJ201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:NJ201\", \"regionCode\": \"CN-51-10\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\", \"profile\": \"neijiang\", \"deckModes\": [\"CUT_40\", \"STANDARD_48\"], \"playerCounts\": [2, 3], \"cardsPerPlayer\": 16}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"NJ201\", \"bigSettleTemplate\": \"BigSettleTpl_110\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"legacy-equivalent-1\", \"regionalProvider\": \"native-pdk-NJ201\"}','42fb64f169d07222222394e735f61b0838edf4e9b912a8224e55521dba6cf4f8','601149690da42dab12c6cedef07843f86c9d308d134035e51c0b373e29b84ba0','3faa3f0923a679472dc3a4283742218338a73505168bdb7a42eae6722df535b5','3c3178307f3594ab64d8256e2e266dd63a452eb760d7fe30209d582c484a6b39','0f3c96f1f26dce831feffa930385aab74642b55ea99646e098b79031911d5f60','RETIRED',100.00,1,'Repair regional PDK Hall rule validator shape','2026-09-26 12:28:19.875','2026-09-26 12:28:19.875','2026-09-26 12:28:19.875','2026-09-26 12:28:19.907'),(6292026090706,629,'legacy-equivalent-1',2026090706,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 629, \"xqpArea\": 6, \"gameCode\": \"NJ201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:NJ201\", \"regionCode\": \"CN-51-10\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"schema\": \"canonical-room-v2\", \"profile\": \"neijiang\", \"deckModes\": [\"CUT_40\", \"STANDARD_48\"], \"playerCounts\": [2, 3], \"cardsPerPlayer\": 16}','{\"scene\": \"GameRoom2D\", \"bundle\": \"poker01-prefab\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"NJ201\", \"bigSettleTemplate\": \"BigSettleTpl_110\", \"publicRoomRuleSchemaVersion\": 2}','{\"providerVersion\": \"legacy-equivalent-1\", \"regionalProvider\": \"native-pdk-NJ201\"}','42fb64f169d07222222394e735f61b0838edf4e9b912a8224e55521dba6cf4f8','7c0044a27c15f0fbb13032b69cc485953b18aad53280c35aedb48efc1d2b8eda','fd9ab0444154ee5d08fa1b169daa84f089fd3f0bc96965759d50843f73b4c00b','3c3178307f3594ab64d8256e2e266dd63a452eb760d7fe30209d582c484a6b39','08354915865c8e6410529d4a86e7ac31723ff5f2966d7b03d3d47a8ffcfeb4a6','ACTIVE',100.00,1,'Make regional PDK room restrictions optional','2026-09-26 12:28:19.903','2026-09-26 12:28:19.903','2026-09-26 12:28:19.903',NULL),(900052026090703,90005,'xqp-equivalent-1',2026090703,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"LS201\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','bebe73171de181c3428f558b3b45a544b09b17a76f0ff5095aab851bbab10630','47034d92e3c685722a73613ea34594b930838cef20286de59aa6b2953a046aab','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','385ae92eaae986933147d7a1f0f4299f69307d14290c5f37683987a8a06f067f','RETIRED',100.00,1,'Activate stable PDK business code after authorized room-history reset','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:19.854','2026-09-26 12:28:19.878'),(900052026090704,90005,'xqp-equivalent-1',2026090704,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"LS201\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','a118139495e37e28d06f419bbdf7093b0f88c3f5fd40fc75bec6e3cf76b16b9f','47034d92e3c685722a73613ea34594b930838cef20286de59aa6b2953a046aab','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','fc27080e691099e6b6193a7870ba1043c27289a937a6cb92fd125f2edd78422c','RETIRED',100.00,1,'Repair regional PDK Hall rule validator shape','2026-09-26 12:28:19.875','2026-09-26 12:28:19.875','2026-09-26 12:28:19.875','2026-09-26 12:28:19.907'),(900052026090706,90005,'xqp-equivalent-1',2026090706,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"LS201\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','a5f46e5311855298c99bd1e36494fcb2d016a7a03ca34da06dda76b823932a9a','620422353af2d2e60c6944bc15ab4bbc49e8fa0ec9172b2eafcc1167e8e219d2','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','3853bc470356687971e9ac6aec14483f1376def3e44b306ce4e98086df5191da','RETIRED',100.00,1,'Make regional PDK room restrictions optional','2026-09-26 12:28:19.903','2026-09-26 12:28:19.903','2026-09-26 12:28:19.903','2026-09-26 12:28:19.925'),(900052026090707,90005,'xqp-equivalent-1',2026090707,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"LS201\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','55c09c3b807a105296319df83e37cebeac00660dc6283fe260b27965a0444de3','30642f6a5809066ec97a21d8c224fd3f80a072336e7707d2dcc7c472ef6300cd','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','fd0064416955d756f9f5aa79a3aac3a7e2eae3886298ccc9e003a60edb8a0504','RETIRED',100.00,1,'Canonicalize LS201 create defaults and payer mode','2026-09-26 12:28:19.922','2026-09-26 12:28:19.922','2026-09-26 12:28:19.922','2026-09-26 12:28:19.943'),(900052026090708,90005,'xqp-equivalent-1',2026090708,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"family\": \"poker:pao-de-kuai\", \"profile\": \"liangshan\", \"deckModes\": [\"LS_7_TO_ACE\", \"LS_5_TO_ACE\"], \"roundCounts\": [8, 12, 16], \"jinHuaScores\": [1, 2, 3, 4, 5, \"no_compare\"], \"playerCounts\": [2, 3, 4], \"dealCardCounts\": [8, 10], \"operationTimes\": [10, 15, 20], \"robDealerRules\": [\"dealer_first\", \"dealer_last\", \"first_round_no_compete\", \"no_compete\"]}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"playFamily\": \"poker:pao-de-kuai\", \"playerCounts\": [2, 3, 4], \"regionalProfile\": \"LS201\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','7eaaeed0ec5cc93a07ca7376c654250fe0a2da42f57dbae52114cbab6597dacb','0fe8af6881fc05156afa051a2a3435610623c80ca12d5fd96c4916b13f4e4bc4','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','a7d4b4c1df6b4fdde7f98d00011242b1a3da9897cfd4b35c7b022ef1bf417c12','RETIRED',100.00,1,'Fix LS201 enum defaults','2026-09-26 12:28:19.940','2026-09-26 12:28:19.940','2026-09-26 12:28:19.940','2026-09-26 12:28:19.962'),(900052026090709,90005,'xqp-equivalent-1',2026090709,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"10秒\", \"value\": 10}, {\"label\": \"15秒\", \"value\": 15}, {\"label\": \"20秒\", \"value\": 20}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 10, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A)\", \"value\": 8}, {\"label\": \"10张(5-A)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": \"no_compare\", \"defaultCandidateIndexes\": [6]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"dealer_first\", \"defaultCandidateIndexes\": [1]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二\", \"value\": \"four_with_two\"}, {\"label\": \"四张A,7\", \"value\": \"four_ace_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全大,全小,全红,全黑,全连,全对\", \"value\": \"all_special_patterns\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"compare_attachments\", \"triple_with_one\", \"four_ace_rank\", \"full_consecutive_pairs\"], \"defaultCandidateIndexes\": [1, 2, 4, 6]}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"ip_limit\", \"timeout_auto_play\", \"distance_warning\", \"chat_muted\"], \"defaultCandidateIndexes\": [1, 3, 4, 6]}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"lspdk\", \"roomRuleViewHash\": \"62b00dd3de701ea184289dda931dca8e937b147134ade8f857d000e6e75403d5\", \"roomRuleWorkbook\": \"开房规则表/跑得快/跑得快可配置规则总表.xlsx\", \"roomRuleSourceHash\": \"514b8f16c72ff048cb778d10b5a61ec4874cbbf148a8ab5a6df558d704236f66\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"10秒\", \"value\": 10}, {\"label\": \"15秒\", \"value\": 15}, {\"label\": \"20秒\", \"value\": 20}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 10, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A)\", \"value\": 8}, {\"label\": \"10张(5-A)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": \"no_compare\", \"defaultCandidateIndexes\": [6]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"dealer_first\", \"defaultCandidateIndexes\": [1]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二\", \"value\": \"four_with_two\"}, {\"label\": \"四张A,7\", \"value\": \"four_ace_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全大,全小,全红,全黑,全连,全对\", \"value\": \"all_special_patterns\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"compare_attachments\", \"triple_with_one\", \"four_ace_rank\", \"full_consecutive_pairs\"], \"defaultCandidateIndexes\": [1, 2, 4, 6]}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [\"ip_limit\", \"timeout_auto_play\", \"distance_warning\", \"chat_muted\"], \"defaultCandidateIndexes\": [1, 3, 4, 6]}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"lspdk\", \"roomRuleViewHash\": \"62b00dd3de701ea184289dda931dca8e937b147134ade8f857d000e6e75403d5\", \"roomRuleWorkbook\": \"开房规则表/跑得快/跑得快可配置规则总表.xlsx\", \"roomRuleSourceHash\": \"514b8f16c72ff048cb778d10b5a61ec4874cbbf148a8ab5a6df558d704236f66\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','202d5fb10306831192be85c0a7eb072c25e396738f8c12fe0ae9ce407b139205','b693cf3e8549d4ff81a497de9eb6b0514dd1798ffd02c4bcda8372f5ef5ceafd','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','930e2e4208fb1b6b4989572c21fd74d947fe9693567d1ffc113494f9e8c5f90f','RETIRED',100.00,1,'Publish authoritative Chinese LS201 room-rule UI','2026-09-26 12:28:19.957','2026-09-26 12:28:19.957','2026-09-26 12:28:19.957','2026-09-26 12:28:19.982'),(900052026090710,90005,'xqp-equivalent-1',2026090710,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','6760121881d51021bbe779710c63afa3ed46fbec0202ffdb474546d1d3a20044','8c843f6e20e68b6e8389543aca7bd7dcc6efc46c17c298a684555764443d058e','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','9b08da7ab1af6d260451cdb6c12c6a1e00a196b7befca27ef5c3af1ccc2c565a','RETIRED',100.00,1,'Correct LS201 XQP deck, deal and rule defaults','2026-09-26 12:28:19.977','2026-09-26 12:28:19.977','2026-09-26 12:28:19.977','2026-09-26 12:28:20.007'),(900052026090711,90005,'xqp-equivalent-1',2026090711,'REGIONAL','{\"family\": \"poker:pao-de-kuai\", \"gameId\": 90005, \"xqpArea\": 9, \"gameCode\": \"LS201\", \"provider\": \"com.aoo.bcg.poker.PdkGameProvider:LS201\", \"regionCode\": \"CN-51-34\", \"displayName\": \"凉山跑得快\", \"xqpGameType\": 5}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"scene\": \"GameRoom2D\", \"bundle\": \"pdk-common-room\", \"fields\": [{\"key\": \"playerCount\", \"label\": \"人数\", \"order\": 10, \"control\": \"RADIO\", \"options\": [{\"label\": \"2人\", \"value\": 2}, {\"label\": \"3人\", \"value\": 3}, {\"label\": \"4人\", \"value\": 4}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 2, \"defaultCandidateIndexes\": [1]}, {\"key\": \"roundCount\", \"label\": \"局数\", \"order\": 20, \"control\": \"RADIO\", \"options\": [{\"label\": \"8局\", \"value\": 8}, {\"label\": \"12局\", \"value\": 12}, {\"label\": \"16局\", \"value\": 16}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"operationTime\", \"label\": \"操作时间\", \"order\": 30, \"control\": \"RADIO\", \"options\": [{\"label\": \"15秒\", \"value\": 15}], \"visible\": true, \"disabled\": true, \"required\": true, \"defaultValue\": 15, \"defaultCandidateIndexes\": [1]}, {\"key\": \"dealCardCount\", \"label\": \"发牌张数\", \"order\": 40, \"control\": \"RADIO\", \"options\": [{\"label\": \"8张(7-A，无2/王)\", \"value\": 8}, {\"label\": \"10张(5-A，无2/王)\", \"value\": 10}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 8, \"defaultCandidateIndexes\": [1]}, {\"key\": \"jinHuaScore\", \"label\": \"比金花\", \"order\": 50, \"control\": \"RADIO\", \"options\": [{\"label\": \"1分\", \"value\": 1}, {\"label\": \"2分\", \"value\": 2}, {\"label\": \"3分\", \"value\": 3}, {\"label\": \"4分\", \"value\": 4}, {\"label\": \"5分\", \"value\": 5}, {\"label\": \"不比\", \"value\": \"no_compare\"}], \"visible\": true, \"disabled\": false, \"required\": true, \"defaultValue\": 1, \"defaultCandidateIndexes\": [1]}, {\"key\": \"robDealerRule\", \"label\": \"抢庄\", \"order\": 60, \"control\": \"RADIO\", \"options\": [{\"label\": \"庄家先抢\", \"value\": \"dealer_first\"}, {\"label\": \"庄家后抢\", \"value\": \"dealer_last\"}, {\"label\": \"首局不抢\", \"value\": \"first_round_no_compete\"}, {\"label\": \"不抢庄\", \"value\": \"no_compete\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": \"no_compete\", \"defaultCandidateIndexes\": [4]}, {\"key\": \"playRule\", \"label\": \"玩法\", \"order\": 70, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"三带比带\", \"value\": \"compare_attachments\"}, {\"label\": \"三带一(单或对)\", \"value\": \"triple_with_one\"}, {\"label\": \"四带二(两张或两对)\", \"value\": \"four_with_two\"}, {\"label\": \"四张A\", \"value\": \"four_aces\"}, {\"label\": \"四张7/5\", \"value\": \"four_configured_rank\"}, {\"label\": \"全单\", \"value\": \"all_single\"}, {\"label\": \"全顺子\", \"value\": \"full_straight\"}, {\"label\": \"全连对\", \"value\": \"full_consecutive_pairs\"}, {\"label\": \"全对\", \"value\": \"all_pair\"}, {\"label\": \"全黑\", \"value\": \"all_black\"}, {\"label\": \"全红\", \"value\": \"all_red\"}, {\"label\": \"全大\", \"value\": \"all_big\"}, {\"label\": \"全小\", \"value\": \"all_small\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"roomRestriction\", \"label\": \"其他\", \"order\": 80, \"control\": \"CHECKBOX\", \"options\": [{\"label\": \"IP限制\", \"value\": \"ip_limit\"}, {\"label\": \"GPS限制\", \"value\": \"gps_limit\"}, {\"label\": \"超时托管\", \"value\": \"timeout_auto_play\"}, {\"label\": \"距离过近警告\", \"value\": \"distance_warning\"}, {\"label\": \"禁止互动\", \"value\": \"interaction_forbidden\"}, {\"label\": \"禁言\", \"value\": \"chat_muted\"}], \"visible\": true, \"disabled\": false, \"required\": false, \"defaultValue\": [], \"defaultCandidateIndexes\": []}, {\"key\": \"payerMode\", \"label\": \"支付方式\", \"order\": 90, \"control\": \"RADIO\", \"options\": [{\"label\": \"房主支付\", \"value\": \"OWNER\"}], \"visible\": false, \"disabled\": false, \"required\": true, \"defaultValue\": \"OWNER\", \"defaultCandidateIndexes\": [1]}], \"regionalProfile\": \"LS201\", \"roomRuleViewHash\": \"11d1cc8d47ed609f3c4f664e1865442bbcb3ca99c4e2fcf060d72b52dd443a3a\", \"roomRuleWorkbook\": \"开房规则表/跑得快/凉山跑得快.xlsx\", \"roomRuleSourceHash\": \"948467e4e7d526f23ecdc4db6f53058d1bd56722a334d9ef2653a778dbe7db77\"}','{\"providerVersion\": \"xqp-equivalent-1\", \"regionalProvider\": \"native-pdk-LS201\"}','379bd57cffaa1a953bb33b357d5422cc8bc1caecb29b42c62d88b7deac22999f','3490f23cf0b270309eebb861a4b8124ca13ec45bac5dbda3ab1dcab28d4f1631','ffa3c75b96f3cc3953343c6ce76fc37de22251997dafd605947ed58ee57ac60b','8dbf7ebe664a69ca41acb7ebe9a6abaf4c611e92eb39df761faab786574b31a6','c89ac8835699bf4b5376b43302ccd64495b02946dd27a5dddc25b2d7b217d1d9','ACTIVE',100.00,1,'Repair LS201 UTF-8 publication boundary','2026-09-26 12:28:20.003','2026-09-26 12:28:20.003','2026-09-26 12:28:20.003',NULL);
/*!40000 ALTER TABLE `aoo_game_release` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_game_release_immutable_content` BEFORE UPDATE ON `aoo_game_release` FOR EACH ROW BEGIN
    IF OLD.status<>'STAGED' AND (
        NOT (NEW.game_id <=> OLD.game_id)
        OR NOT (NEW.play_version <=> OLD.play_version)
        OR NOT (NEW.release_version <=> OLD.release_version)
        OR NOT (NEW.catalog_snapshot <=> OLD.catalog_snapshot)
        OR NOT (NEW.rule_snapshot <=> OLD.rule_snapshot)
        OR NOT (NEW.ui_snapshot <=> OLD.ui_snapshot)
        OR NOT (NEW.component_snapshot <=> OLD.component_snapshot)
        OR NOT (NEW.bundle_hash <=> OLD.bundle_hash)
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='validated game release content is immutable';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_game_release_no_delete` BEFORE DELETE ON `aoo_game_release` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='game release history cannot be deleted';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_game_release_audit`
--

DROP TABLE IF EXISTS `aoo_game_release_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_release_audit` (
  `audit_id` bigint unsigned NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `action` varchar(32) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `request_id` varchar(64) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `before_status` varchar(16) DEFAULT NULL,
  `after_status` varchar(16) NOT NULL,
  `before_active_release_id` bigint unsigned DEFAULT NULL,
  `after_active_release_id` bigint unsigned DEFAULT NULL,
  `occurred_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`audit_id`),
  UNIQUE KEY `uk_game_release_audit_request` (`request_id`),
  KEY `idx_game_release_audit_release` (`release_id`,`occurred_at`,`audit_id`),
  CONSTRAINT `fk_game_release_audit_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_release_audit_action` CHECK ((`action` in (_utf8mb4'VALIDATE',_utf8mb4'ACTIVATE',_utf8mb4'CANARY',_utf8mb4'ROLLBACK',_utf8mb4'RETIRE',_utf8mb4'FAIL')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_release_audit`
--

LOCK TABLES `aoo_game_release_audit` WRITE;
/*!40000 ALTER TABLE `aoo_game_release_audit` DISABLE KEYS */;
INSERT INTO `aoo_game_release_audit` VALUES (629000005,629000005,'ACTIVATE',1,'migration-20260826.06-629','Versioned canonical Poker family and settlement defaults','ACTIVE','ACTIVE',629000004,629000005,'2026-09-26 12:28:19.572');
/*!40000 ALTER TABLE `aoo_game_release_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_release_component`
--

DROP TABLE IF EXISTS `aoo_game_release_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_release_component` (
  `release_id` bigint unsigned NOT NULL,
  `component_type` varchar(32) NOT NULL,
  `ordinal` smallint unsigned NOT NULL,
  `component_id` bigint unsigned NOT NULL,
  `component_key` varchar(192) NOT NULL,
  `component_version` varchar(64) NOT NULL,
  `spi_type` varchar(192) NOT NULL,
  `implementation_locator` varchar(512) NOT NULL,
  `artifact_digest` char(64) NOT NULL,
  `parameter_snapshot` json NOT NULL,
  `content_hash` char(64) NOT NULL,
  PRIMARY KEY (`release_id`,`component_type`,`ordinal`),
  UNIQUE KEY `uk_release_component_instance` (`release_id`,`component_id`),
  KEY `idx_release_component_reverse` (`component_id`,`release_id`),
  KEY `fk_release_component_type` (`component_type`),
  CONSTRAINT `fk_release_component_component` FOREIGN KEY (`component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_release_component_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_release_component_type` FOREIGN KEY (`component_type`) REFERENCES `aoo_component_type` (`component_type`) ON DELETE RESTRICT,
  CONSTRAINT `chk_release_component_digest` CHECK (regexp_like(`artifact_digest`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_release_component_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_release_component`
--

LOCK TABLES `aoo_game_release_component` WRITE;
/*!40000 ALTER TABLE `aoo_game_release_component` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_game_release_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_release_region`
--

DROP TABLE IF EXISTS `aoo_game_release_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_release_region` (
  `release_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `rollout_percent` decimal(5,2) NOT NULL DEFAULT '100.00',
  `status` varchar(16) NOT NULL DEFAULT 'STAGED',
  PRIMARY KEY (`release_id`,`region_code`),
  KEY `idx_game_release_region_lookup` (`region_code`,`status`,`release_id`),
  CONSTRAINT `fk_game_release_region_region` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_game_release_region_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_release_region_rollout` CHECK (((`rollout_percent` >= 0.00) and (`rollout_percent` <= 100.00))),
  CONSTRAINT `chk_game_release_region_status` CHECK ((`status` in (_utf8mb4'STAGED',_utf8mb4'VALIDATED',_utf8mb4'ACTIVE',_utf8mb4'RETIRED',_utf8mb4'ROLLED_BACK')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_release_region`
--

LOCK TABLES `aoo_game_release_region` WRITE;
/*!40000 ALTER TABLE `aoo_game_release_region` DISABLE KEYS */;
INSERT INTO `aoo_game_release_region` VALUES (8000003,'CN-51-01',100.00,'RETIRED'),(629000003,'CN-51',100.00,'RETIRED'),(629000004,'CN-51',100.00,'RETIRED'),(629000005,'CN-51',100.00,'RETIRED'),(629000006,'CN-51',100.00,'RETIRED'),(629000008,'CN-51-10',100.00,'RETIRED'),(800000001,'CN-51-01',100.00,'RETIRED'),(800000002,'CN-51-01',100.00,'RETIRED'),(2034091001,'CN-51-01',100.00,'RETIRED'),(2034091002,'CN-51-01',100.00,'ACTIVE'),(82026090703,'CN-51-01',100.00,'RETIRED'),(90005000001,'CN-51-34',100.00,'RETIRED'),(6292026090703,'CN-51-10',100.00,'RETIRED'),(6292026090704,'CN-51-10',100.00,'RETIRED'),(6292026090706,'CN-51-10',100.00,'ACTIVE'),(900052026090703,'CN-51-34',100.00,'RETIRED'),(900052026090704,'CN-51-34',100.00,'RETIRED'),(900052026090706,'CN-51-34',100.00,'RETIRED'),(900052026090707,'CN-51-34',100.00,'RETIRED'),(900052026090708,'CN-51-34',100.00,'RETIRED'),(900052026090709,'CN-51-34',100.00,'RETIRED'),(900052026090710,'CN-51-34',100.00,'RETIRED'),(900052026090711,'CN-51-34',100.00,'ACTIVE');
/*!40000 ALTER TABLE `aoo_game_release_region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_service_route`
--

DROP TABLE IF EXISTS `aoo_game_service_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_service_route` (
  `route_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `endpoint` varchar(512) NOT NULL,
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`route_id`),
  UNIQUE KEY `uk_game_route_endpoint` (`game_id`,`play_version`,`endpoint`),
  KEY `idx_game_route_lookup` (`game_id`,`play_version`,`status`,`priority`,`route_id`),
  CONSTRAINT `fk_game_route_play` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_route_endpoint` CHECK (regexp_like(`endpoint`,_utf8mb4'^wss?://')),
  CONSTRAINT `chk_game_route_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DRAINING',_utf8mb4'OFFLINE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_service_route`
--

LOCK TABLES `aoo_game_service_route` WRITE;
/*!40000 ALTER TABLE `aoo_game_service_route` DISABLE KEYS */;
INSERT INTO `aoo_game_service_route` VALUES (800000001,8,'1.0.0','ws://127.0.0.1:8080/api/v2/gateway/ws',100,'ACTIVE','2026-09-26 12:28:19.599'),(90005000001,90005,'xqp-equivalent-1','ws://127.0.0.1:8080/api/v2/gateway/ws',1,'ACTIVE','2026-09-26 12:28:19.758');
/*!40000 ALTER TABLE `aoo_game_service_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_game_share`
--

DROP TABLE IF EXISTS `aoo_game_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_game_share` (
  `share_hash` char(64) NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `revoked_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`share_hash`),
  KEY `idx_game_share_expiry` (`expires_at`,`revoked_at`),
  KEY `idx_game_share_room` (`room_id`,`created_at`),
  CONSTRAINT `fk_game_share_room` FOREIGN KEY (`room_id`) REFERENCES `aoo_hall_room` (`room_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_game_share_expiry` CHECK ((`expires_at` > `created_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_game_share`
--

LOCK TABLES `aoo_game_share` WRITE;
/*!40000 ALTER TABLE `aoo_game_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_game_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_hall_game_ticket`
--

DROP TABLE IF EXISTS `aoo_hall_game_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_hall_game_ticket` (
  `ticket_hash` char(64) NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `device_fingerprint` varchar(128) NOT NULL,
  `route_endpoint` varchar(512) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `consumed_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`ticket_hash`),
  KEY `idx_hall_ticket_expiry` (`expires_at`,`consumed_at`),
  KEY `idx_hall_ticket_subject` (`room_id`,`account_id`,`expires_at`),
  CONSTRAINT `fk_hall_ticket_member` FOREIGN KEY (`room_id`, `account_id`) REFERENCES `aoo_hall_room_member` (`room_id`, `account_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_hall_game_ticket`
--

LOCK TABLES `aoo_hall_game_ticket` WRITE;
/*!40000 ALTER TABLE `aoo_hall_game_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_hall_game_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_hall_idempotency`
--

DROP TABLE IF EXISTS `aoo_hall_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_hall_idempotency` (
  `account_id` bigint unsigned NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `operation` varchar(16) NOT NULL,
  `response_json` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`account_id`,`idempotency_key`),
  KEY `idx_hall_idempotency_retention` (`created_at`),
  CONSTRAINT `chk_hall_idempotency_operation` CHECK ((`operation` in (_utf8mb4'CREATE',_utf8mb4'JOIN',_utf8mb4'LEAVE',_utf8mb4'TICKET')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_hall_idempotency`
--

LOCK TABLES `aoo_hall_idempotency` WRITE;
/*!40000 ALTER TABLE `aoo_hall_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_hall_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_hall_room`
--

DROP TABLE IF EXISTS `aoo_hall_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_hall_room` (
  `room_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `classification_region_code` varchar(32) NOT NULL COMMENT 'Gameplay classification provenance; server-derived; never an account, asset, club, room-number or service-route partition key',
  `play_version` varchar(64) NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `index_generation` bigint unsigned NOT NULL,
  `owner_account_id` bigint unsigned NOT NULL,
  `scope_type` varchar(16) NOT NULL DEFAULT 'PERSONAL',
  `club_id` bigint unsigned DEFAULT NULL,
  `club_template_code` varchar(64) DEFAULT NULL,
  `state` varchar(16) NOT NULL,
  `route_endpoint` varchar(512) NOT NULL,
  `rules_json` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `idx_hall_room_owner` (`owner_account_id`,`state`,`updated_at`,`room_id`),
  KEY `idx_hall_room_route` (`game_id`,`play_version`,`state`,`room_id`),
  KEY `fk_hall_room_index` (`game_id`,`classification_region_code`,`play_version`,`index_generation`),
  KEY `fk_hall_room_release` (`release_id`),
  KEY `idx_hall_room_club` (`club_id`,`state`,`updated_at`,`room_id`),
  CONSTRAINT `fk_hall_room_index` FOREIGN KEY (`game_id`, `classification_region_code`, `play_version`, `index_generation`) REFERENCES `aoo_compiled_room_create_index` (`game_id`, `region_code`, `play_version`, `index_generation`) ON DELETE RESTRICT,
  CONSTRAINT `fk_hall_room_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_hall_room_scope` CHECK ((((`scope_type` = _utf8mb4'PERSONAL') and (`club_id` is null) and (`club_template_code` is null)) or ((`scope_type` = _utf8mb4'CLUB') and (`club_id` is not null) and (`club_id` > 0) and (`club_template_code` is not null)))),
  CONSTRAINT `chk_hall_room_state` CHECK ((`state` in (_utf8mb4'CREATING',_utf8mb4'OPEN',_utf8mb4'PLAYING',_utf8mb4'FINISHED',_utf8mb4'DISSOLVED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_hall_room`
--

LOCK TABLES `aoo_hall_room` WRITE;
/*!40000 ALTER TABLE `aoo_hall_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_hall_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_hall_room_member`
--

DROP TABLE IF EXISTS `aoo_hall_room_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_hall_room_member` (
  `room_id` bigint unsigned NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `seat_no` smallint unsigned NOT NULL,
  `status` varchar(16) NOT NULL,
  `joined_at` datetime(3) NOT NULL,
  `left_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`room_id`,`account_id`),
  UNIQUE KEY `uk_hall_room_seat` (`room_id`,`seat_no`),
  KEY `idx_hall_member_account` (`account_id`,`status`,`room_id`),
  CONSTRAINT `fk_hall_member_room` FOREIGN KEY (`room_id`) REFERENCES `aoo_hall_room` (`room_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_hall_member_status` CHECK ((`status` in (_utf8mb4'JOINING',_utf8mb4'JOINED',_utf8mb4'LEFT',_utf8mb4'KICKED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_hall_room_member`
--

LOCK TABLES `aoo_hall_room_member` WRITE;
/*!40000 ALTER TABLE `aoo_hall_room_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_hall_room_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_admin_request`
--

DROP TABLE IF EXISTS `aoo_identity_admin_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_admin_request` (
  `request_id` varchar(128) NOT NULL,
  `result_json` text NOT NULL,
  `completed_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_admin_request`
--

LOCK TABLES `aoo_identity_admin_request` WRITE;
/*!40000 ALTER TABLE `aoo_identity_admin_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_admin_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_audit`
--

DROP TABLE IF EXISTS `aoo_identity_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_audit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` bigint NOT NULL,
  `action` varchar(48) NOT NULL,
  `ip_token` varchar(64) NOT NULL,
  `details_json` text NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_identity_audit_account_time` (`account_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_audit`
--

LOCK TABLES `aoo_identity_audit` WRITE;
/*!40000 ALTER TABLE `aoo_identity_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_credential`
--

DROP TABLE IF EXISTS `aoo_identity_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_credential` (
  `credential_token` varchar(64) NOT NULL,
  `account_id` bigint NOT NULL,
  `purpose` varchar(32) NOT NULL,
  `expires_at` timestamp(6) NOT NULL,
  `consumed_at` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`credential_token`),
  KEY `ix_identity_credential_account` (`account_id`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_credential`
--

LOCK TABLES `aoo_identity_credential` WRITE;
/*!40000 ALTER TABLE `aoo_identity_credential` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_credential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_idempotency`
--

DROP TABLE IF EXISTS `aoo_identity_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_idempotency` (
  `account_id` bigint NOT NULL,
  `operation_scope` varchar(32) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `request_fingerprint` varchar(64) NOT NULL,
  `response_cipher` text NOT NULL,
  `created_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`account_id`,`operation_scope`,`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_idempotency`
--

LOCK TABLES `aoo_identity_idempotency` WRITE;
/*!40000 ALTER TABLE `aoo_identity_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_migration`
--

DROP TABLE IF EXISTS `aoo_identity_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_migration` (
  `migration_id` char(36) NOT NULL,
  `source_account_id` bigint NOT NULL,
  `target_account_id` bigint NOT NULL,
  `identity_type` varchar(24) NOT NULL,
  `value_hash` char(64) NOT NULL,
  `source_proof_hash` char(64) NOT NULL,
  `target_proof_hash` char(64) NOT NULL,
  `operator_id` bigint NOT NULL,
  `reason` varchar(255) NOT NULL,
  `trace_id` varchar(128) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`migration_id`),
  CONSTRAINT `ck_identity_migration_accounts` CHECK ((`source_account_id` <> `target_account_id`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_migration`
--

LOCK TABLES `aoo_identity_migration` WRITE;
/*!40000 ALTER TABLE `aoo_identity_migration` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_identity_verification`
--

DROP TABLE IF EXISTS `aoo_identity_verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_identity_verification` (
  `account_id` bigint NOT NULL,
  `real_name_status` varchar(24) NOT NULL DEFAULT 'UNSUBMITTED',
  `legal_name_cipher` text,
  `id_number_cipher` text,
  `id_token` varchar(64) DEFAULT NULL,
  `masked_name` varchar(64) DEFAULT NULL,
  `masked_id_number` varchar(32) DEFAULT NULL,
  `phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  `phone_token` varchar(64) DEFAULT NULL,
  `masked_phone` varchar(32) DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `uq_identity_document_token` (`id_token`),
  KEY `ix_identity_phone_token` (`phone_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_identity_verification`
--

LOCK TABLES `aoo_identity_verification` WRITE;
/*!40000 ALTER TABLE `aoo_identity_verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_identity_verification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_inventory_command`
--

DROP TABLE IF EXISTS `aoo_inventory_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_inventory_command` (
  `command_id` varchar(128) NOT NULL,
  `command_kind` varchar(24) NOT NULL,
  `command_state` varchar(32) NOT NULL,
  `player_id` bigint NOT NULL,
  `reference_code` varchar(128) NOT NULL,
  `error_message` varchar(500) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`command_id`),
  KEY `ix_inventory_command_player` (`player_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_inventory_command`
--

LOCK TABLES `aoo_inventory_command` WRITE;
/*!40000 ALTER TABLE `aoo_inventory_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_inventory_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_inventory_lot`
--

DROP TABLE IF EXISTS `aoo_inventory_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_inventory_lot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `item_code` varchar(64) NOT NULL,
  `quantity` bigint NOT NULL,
  `expires_at` timestamp(3) NULL DEFAULT NULL,
  `row_version` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_code` (`item_code`),
  KEY `ix_inventory_lot_consume` (`player_id`,`item_code`,`expires_at`,`id`),
  CONSTRAINT `aoo_inventory_lot_ibfk_1` FOREIGN KEY (`item_code`) REFERENCES `aoo_item_catalog` (`item_code`),
  CONSTRAINT `aoo_inventory_lot_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_inventory_lot`
--

LOCK TABLES `aoo_inventory_lot` WRITE;
/*!40000 ALTER TABLE `aoo_inventory_lot` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_inventory_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_inventory_movement`
--

DROP TABLE IF EXISTS `aoo_inventory_movement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_inventory_movement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `command_id` varchar(128) NOT NULL,
  `player_id` bigint NOT NULL,
  `item_code` varchar(64) NOT NULL,
  `quantity_delta` bigint NOT NULL,
  `movement_type` varchar(24) NOT NULL,
  `source_reference` varchar(128) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `command_id` (`command_id`),
  KEY `item_code` (`item_code`),
  KEY `ix_inventory_movement_player` (`player_id`,`id`),
  CONSTRAINT `aoo_inventory_movement_ibfk_1` FOREIGN KEY (`command_id`) REFERENCES `aoo_inventory_command` (`command_id`),
  CONSTRAINT `aoo_inventory_movement_ibfk_2` FOREIGN KEY (`item_code`) REFERENCES `aoo_item_catalog` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_inventory_movement`
--

LOCK TABLES `aoo_inventory_movement` WRITE;
/*!40000 ALTER TABLE `aoo_inventory_movement` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_inventory_movement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_invite_consumption`
--

DROP TABLE IF EXISTS `aoo_invite_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_invite_consumption` (
  `consumption_id` bigint NOT NULL AUTO_INCREMENT,
  `idempotency_key` varchar(128) NOT NULL,
  `invite_id` bigint NOT NULL,
  `consumer_account_id` bigint NOT NULL,
  `reward_state` enum('PENDING','GRANTED') NOT NULL,
  `reward_reference` varchar(160) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`consumption_id`),
  UNIQUE KEY `uk_invite_consumption_key` (`idempotency_key`),
  UNIQUE KEY `uk_invite_consumer` (`invite_id`,`consumer_account_id`),
  CONSTRAINT `fk_invite_consumption_link` FOREIGN KEY (`invite_id`) REFERENCES `aoo_invite_link` (`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_invite_consumption`
--

LOCK TABLES `aoo_invite_consumption` WRITE;
/*!40000 ALTER TABLE `aoo_invite_consumption` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_invite_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_invite_link`
--

DROP TABLE IF EXISTS `aoo_invite_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_invite_link` (
  `invite_id` bigint NOT NULL AUTO_INCREMENT,
  `token_hash` binary(32) NOT NULL,
  `kind` enum('ROOM','CLUB') NOT NULL,
  `target_id` bigint NOT NULL,
  `issuer_account_id` bigint NOT NULL,
  `max_uses` int unsigned NOT NULL,
  `use_count` int unsigned NOT NULL DEFAULT '0',
  `expires_at` datetime(3) NOT NULL,
  `status` enum('ACTIVE','EXHAUSTED','REVOKED') NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `last_used_at` datetime(3) DEFAULT NULL,
  `revoked_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`invite_id`),
  UNIQUE KEY `uk_invite_token_hash` (`token_hash`),
  KEY `ix_invite_issuer` (`issuer_account_id`,`created_at`),
  KEY `ix_invite_target` (`kind`,`target_id`,`status`),
  CONSTRAINT `ck_invite_usage` CHECK (((`max_uses` between 1 and 10000) and (`use_count` <= `max_uses`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_invite_link`
--

LOCK TABLES `aoo_invite_link` WRITE;
/*!40000 ALTER TABLE `aoo_invite_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_invite_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_invite_link_audit`
--

DROP TABLE IF EXISTS `aoo_invite_link_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_invite_link_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `invite_id` bigint NOT NULL,
  `event_type` enum('CREATED','PREVIEWED','CONSUMED','REVOKED') NOT NULL,
  `actor_account_id` bigint DEFAULT NULL,
  `source_channel` varchar(64) NOT NULL,
  `source_hash` binary(32) DEFAULT NULL,
  `outcome` enum('SUCCESS','REJECTED') NOT NULL,
  `occurred_at` datetime(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `ix_invite_audit` (`invite_id`,`occurred_at`),
  CONSTRAINT `fk_invite_audit_link` FOREIGN KEY (`invite_id`) REFERENCES `aoo_invite_link` (`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_invite_link_audit`
--

LOCK TABLES `aoo_invite_link_audit` WRITE;
/*!40000 ALTER TABLE `aoo_invite_link_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_invite_link_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_item_catalog`
--

DROP TABLE IF EXISTS `aoo_item_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_item_catalog` (
  `item_code` varchar(64) NOT NULL,
  `item_name` varchar(120) NOT NULL,
  `item_type` varchar(32) NOT NULL,
  `consumable` tinyint(1) NOT NULL DEFAULT '0',
  `active_from` timestamp(3) NOT NULL,
  `active_until` timestamp(3) NULL DEFAULT NULL,
  `attributes_json` json NOT NULL,
  PRIMARY KEY (`item_code`),
  CONSTRAINT `aoo_item_catalog_chk_1` CHECK (((`active_until` is null) or (`active_until` > `active_from`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_item_catalog`
--

LOCK TABLES `aoo_item_catalog` WRITE;
/*!40000 ALTER TABLE `aoo_item_catalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_item_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_json_schema_registry`
--

DROP TABLE IF EXISTS `aoo_json_schema_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_json_schema_registry` (
  `schema_code` varchar(128) NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `json_schema` json NOT NULL,
  `content_hash` char(64) NOT NULL,
  `compatibility_floor` int unsigned DEFAULT NULL,
  `migration_component_key` varchar(192) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'DRAFT',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`schema_code`,`schema_version`),
  UNIQUE KEY `uk_json_schema_hash` (`schema_code`,`content_hash`),
  KEY `idx_json_schema_status` (`status`,`schema_code`,`schema_version`),
  KEY `fk_json_schema_owner` (`owner_code`),
  CONSTRAINT `fk_json_schema_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_json_schema_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_json_schema_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_json_schema_registry`
--

LOCK TABLES `aoo_json_schema_registry` WRITE;
/*!40000 ALTER TABLE `aoo_json_schema_registry` DISABLE KEYS */;
INSERT INTO `aoo_json_schema_registry` VALUES ('GAME_RELEASE_CATALOG',1,'GAME_CATALOG','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('GAME_RELEASE_RULES',1,'GAME_CATALOG','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('GAME_RELEASE_UI',1,'GAME_CATALOG','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('OUTBOX_EVENT',1,'PLATFORM_DATA','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('ROOM_EVENT_PAYLOAD',1,'GAME_RUNTIME','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('ROOM_RULE_LOCK',1,'GAME_RUNTIME','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471'),('SETTLEMENT_RESULT',1,'GAME_RUNTIME','{\"type\": \"object\"}','a2c799262a3ce3c19ef5cdd983bf3d12b43ab3c426227091b909dcb7054738c0',NULL,NULL,'ACTIVE','2026-09-26 12:28:17.471');
/*!40000 ALTER TABLE `aoo_json_schema_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_ledger`
--

DROP TABLE IF EXISTS `aoo_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_ledger` (
  `ledger_id` bigint unsigned NOT NULL,
  `business_id` varchar(128) NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `currency` varchar(32) NOT NULL,
  `currency_scope_id` bigint unsigned NOT NULL DEFAULT '0',
  `delta` bigint NOT NULL,
  `balance_after` bigint NOT NULL,
  `reason_code` varchar(64) NOT NULL,
  `entry_status` varchar(16) NOT NULL DEFAULT 'POSTED',
  `channel_code` varchar(32) NOT NULL DEFAULT 'GAME',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`ledger_id`),
  UNIQUE KEY `uk_ledger_business` (`business_id`),
  KEY `idx_ledger_player_time` (`player_id`,`created_at`),
  KEY `idx_ledger_business_date` (`created_at`,`business_id`),
  KEY `idx_ledger_balance_chain` (`player_id`,`currency`,`created_at`,`ledger_id`),
  KEY `idx_ledger_reconcile_window` (`entry_status`,`channel_code`,`created_at`,`ledger_id`),
  KEY `idx_ledger_status_window` (`entry_status`,`created_at`,`ledger_id`),
  KEY `idx_ledger_channel_window` (`channel_code`,`created_at`,`ledger_id`),
  KEY `idx_ledger_player_scope_time` (`player_id`,`currency`,`currency_scope_id`,`created_at`,`ledger_id`),
  KEY `fk_ledger_currency_catalog` (`currency`),
  CONSTRAINT `fk_ledger_currency_catalog` FOREIGN KEY (`currency`) REFERENCES `aoo_currency_catalog` (`currency_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_ledger_currency_scope` CHECK ((((`currency` in (_utf8mb4'ROOM_CARD',_utf8mb4'GOLD',_utf8mb4'CRYSTAL')) and (`currency_scope_id` = 0)) or ((`currency` in (_utf8mb4'CITY_ROOM_CARD',_utf8mb4'SPORTS_POINT')) and (`currency_scope_id` > 0)))),
  CONSTRAINT `chk_ledger_identity` CHECK (((`ledger_id` > 0) and (`player_id` > 0) and (`delta` <> 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_ledger`
--

LOCK TABLES `aoo_ledger` WRITE;
/*!40000 ALTER TABLE `aoo_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_legacy_field_mapping`
--

DROP TABLE IF EXISTS `aoo_legacy_field_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_legacy_field_mapping` (
  `mapping_id` bigint unsigned NOT NULL,
  `domain_code` varchar(64) NOT NULL,
  `source_system` varchar(64) NOT NULL,
  `source_object` varchar(128) NOT NULL,
  `source_field` varchar(128) NOT NULL,
  `target_table` varchar(64) NOT NULL,
  `target_column` varchar(64) NOT NULL,
  `transform_expression` text NOT NULL,
  `null_policy` varchar(16) NOT NULL,
  `default_policy` varchar(256) DEFAULT NULL,
  `validation_rule` text NOT NULL,
  `reversibility` varchar(16) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'DRAFT',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`mapping_id`),
  UNIQUE KEY `uk_legacy_field_mapping` (`source_system`,`source_object`,`source_field`,`target_table`,`target_column`),
  KEY `idx_legacy_mapping_target` (`target_table`,`target_column`,`status`),
  CONSTRAINT `chk_legacy_mapping_null` CHECK ((`null_policy` in (_utf8mb4'REJECT',_utf8mb4'PRESERVE',_utf8mb4'DEFAULT',_utf8mb4'QUARANTINE'))),
  CONSTRAINT `chk_legacy_mapping_reversibility` CHECK ((`reversibility` in (_utf8mb4'REVERSIBLE',_utf8mb4'LOSSY_DOCUMENTED',_utf8mb4'NOT_REVERSIBLE'))),
  CONSTRAINT `chk_legacy_mapping_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'APPROVED',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_legacy_field_mapping`
--

LOCK TABLES `aoo_legacy_field_mapping` WRITE;
/*!40000 ALTER TABLE `aoo_legacy_field_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_legacy_field_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_legacy_record_envelope`
--

DROP TABLE IF EXISTS `aoo_legacy_record_envelope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_legacy_record_envelope` (
  `source_system` varchar(64) NOT NULL,
  `source_object` varchar(128) NOT NULL,
  `source_primary_key` varchar(512) NOT NULL,
  `source_snapshot_hash` char(64) NOT NULL,
  `source_record_hash` char(64) NOT NULL,
  `payload_json` json NOT NULL,
  `target_table` varchar(64) DEFAULT NULL,
  `target_business_key` varchar(512) DEFAULT NULL,
  `migration_run_id` bigint unsigned DEFAULT NULL,
  `migration_status` varchar(24) NOT NULL DEFAULT 'EXTRACTED',
  `extracted_at` datetime(3) NOT NULL,
  `migrated_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`source_system`,`source_object`,`source_primary_key`,`source_snapshot_hash`),
  UNIQUE KEY `uk_legacy_record_hash` (`source_system`,`source_object`,`source_record_hash`),
  KEY `idx_legacy_record_migration` (`migration_status`,`source_system`,`source_object`),
  KEY `fk_legacy_record_migration_run` (`migration_run_id`),
  CONSTRAINT `fk_legacy_record_migration_run` FOREIGN KEY (`migration_run_id`) REFERENCES `aoo_migration_run` (`migration_run_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_legacy_record_hashes` CHECK ((regexp_like(`source_snapshot_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`source_record_hash`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_legacy_record_status` CHECK ((`migration_status` in (_utf8mb4'EXTRACTED',_utf8mb4'VALIDATED',_utf8mb4'MAPPED',_utf8mb4'MIGRATED',_utf8mb4'QUARANTINED',_utf8mb4'REJECTED'))),
  CONSTRAINT `chk_legacy_record_target` CHECK ((((`migration_status` in (_utf8mb4'MAPPED',_utf8mb4'MIGRATED')) and (`target_table` is not null) and (`target_business_key` is not null)) or (`migration_status` not in (_utf8mb4'MAPPED',_utf8mb4'MIGRATED'))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_legacy_record_envelope`
--

LOCK TABLES `aoo_legacy_record_envelope` WRITE;
/*!40000 ALTER TABLE `aoo_legacy_record_envelope` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_legacy_record_envelope` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_legacy_source_object`
--

DROP TABLE IF EXISTS `aoo_legacy_source_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_legacy_source_object` (
  `source_system` varchar(64) NOT NULL,
  `source_object` varchar(128) NOT NULL,
  `source_kind` varchar(16) NOT NULL,
  `source_hash` char(64) NOT NULL,
  `record_count` bigint unsigned NOT NULL,
  `extraction_status` varchar(16) NOT NULL,
  `extracted_at` datetime(3) NOT NULL,
  PRIMARY KEY (`source_system`,`source_object`,`source_hash`),
  CONSTRAINT `chk_legacy_source_hash` CHECK (regexp_like(`source_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_legacy_source_kind` CHECK ((`source_kind` in (_utf8mb4'TABLE',_utf8mb4'JSON',_utf8mb4'CSV',_utf8mb4'EVENT',_utf8mb4'BLOB'))),
  CONSTRAINT `chk_legacy_source_status` CHECK ((`extraction_status` in (_utf8mb4'DISCOVERED',_utf8mb4'EXTRACTED',_utf8mb4'QUARANTINED',_utf8mb4'MIGRATED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_legacy_source_object`
--

LOCK TABLES `aoo_legacy_source_object` WRITE;
/*!40000 ALTER TABLE `aoo_legacy_source_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_legacy_source_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_legal_hold`
--

DROP TABLE IF EXISTS `aoo_legal_hold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_legal_hold` (
  `legal_hold_id` bigint unsigned NOT NULL,
  `scope_type` varchar(32) NOT NULL,
  `scope_key_hash` char(64) NOT NULL,
  `authority_reference` varchar(256) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `placed_by` bigint unsigned NOT NULL,
  `placed_at` datetime(3) NOT NULL,
  `released_by` bigint unsigned DEFAULT NULL,
  `released_at` datetime(3) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`legal_hold_id`),
  KEY `idx_legal_hold_scope` (`scope_key_hash`,`status`,`placed_at`),
  CONSTRAINT `chk_legal_hold_hash` CHECK (regexp_like(`scope_key_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_legal_hold_release` CHECK ((((`status` = _utf8mb4'ACTIVE') and (`released_at` is null)) or ((`status` = _utf8mb4'RELEASED') and (`released_at` is not null) and (`released_by` is not null)))),
  CONSTRAINT `chk_legal_hold_scope` CHECK ((`scope_type` in (_utf8mb4'PLAYER',_utf8mb4'ROOM',_utf8mb4'CLUB',_utf8mb4'TIME_RANGE',_utf8mb4'DATASET'))),
  CONSTRAINT `chk_legal_hold_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RELEASED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_legal_hold`
--

LOCK TABLES `aoo_legal_hold` WRITE;
/*!40000 ALTER TABLE `aoo_legal_hold` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_legal_hold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_luck_draw`
--

DROP TABLE IF EXISTS `aoo_luck_draw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_luck_draw` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `request_id` varchar(128) NOT NULL,
  `request_fingerprint` varchar(160) NOT NULL,
  `player_id` bigint NOT NULL,
  `campaign_id` bigint NOT NULL,
  `campaign_code` varchar(64) NOT NULL,
  `prize_id` bigint NOT NULL,
  `prize_code` varchar(64) NOT NULL,
  `prize_name` varchar(128) NOT NULL,
  `reward_kind` varchar(16) NOT NULL,
  `reward_code` varchar(64) NOT NULL,
  `reward_amount` bigint NOT NULL,
  `remaining_count` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_luck_draw_request` (`request_id`),
  KEY `idx_luck_draw_player_time` (`player_id`,`created_at`),
  KEY `fk_luck_draw_campaign` (`campaign_id`),
  KEY `fk_luck_draw_prize` (`prize_id`),
  CONSTRAINT `fk_luck_draw_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `aoo_luck_draw_campaign` (`id`),
  CONSTRAINT `fk_luck_draw_prize` FOREIGN KEY (`prize_id`) REFERENCES `aoo_luck_draw_prize` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_luck_draw`
--

LOCK TABLES `aoo_luck_draw` WRITE;
/*!40000 ALTER TABLE `aoo_luck_draw` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_luck_draw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_luck_draw_campaign`
--

DROP TABLE IF EXISTS `aoo_luck_draw_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_luck_draw_campaign` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(64) NOT NULL,
  `campaign_name` varchar(128) NOT NULL,
  `starts_at` timestamp(3) NOT NULL,
  `ends_at` timestamp(3) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `daily_free_count` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_luck_draw_campaign_code` (`campaign_code`),
  CONSTRAINT `chk_luck_draw_daily` CHECK ((`daily_free_count` >= 0)),
  CONSTRAINT `chk_luck_draw_window` CHECK ((`ends_at` > `starts_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_luck_draw_campaign`
--

LOCK TABLES `aoo_luck_draw_campaign` WRITE;
/*!40000 ALTER TABLE `aoo_luck_draw_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_luck_draw_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_luck_draw_chance`
--

DROP TABLE IF EXISTS `aoo_luck_draw_chance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_luck_draw_chance` (
  `player_id` bigint NOT NULL,
  `campaign_id` bigint NOT NULL,
  `business_date` date NOT NULL,
  `remaining_count` bigint NOT NULL,
  `version` bigint NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`player_id`,`campaign_id`,`business_date`),
  KEY `fk_luck_draw_chance_campaign` (`campaign_id`),
  CONSTRAINT `fk_luck_draw_chance_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `aoo_luck_draw_campaign` (`id`),
  CONSTRAINT `chk_luck_draw_remaining` CHECK ((`remaining_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_luck_draw_chance`
--

LOCK TABLES `aoo_luck_draw_chance` WRITE;
/*!40000 ALTER TABLE `aoo_luck_draw_chance` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_luck_draw_chance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_luck_draw_outbox`
--

DROP TABLE IF EXISTS `aoo_luck_draw_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_luck_draw_outbox` (
  `draw_id` bigint NOT NULL,
  `event_key` varchar(160) NOT NULL,
  `event_type` varchar(64) NOT NULL,
  `payload_json` json NOT NULL,
  `status` varchar(16) NOT NULL,
  `attempt_count` int NOT NULL,
  `next_attempt_at` timestamp(3) NOT NULL,
  `last_error` varchar(500) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`draw_id`),
  UNIQUE KEY `uk_luck_draw_outbox_event` (`event_key`),
  KEY `idx_luck_draw_outbox_dispatch` (`status`,`next_attempt_at`),
  CONSTRAINT `fk_luck_draw_outbox_draw` FOREIGN KEY (`draw_id`) REFERENCES `aoo_luck_draw` (`id`),
  CONSTRAINT `chk_luck_draw_outbox_status` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'DELIVERED',_utf8mb4'DEAD')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_luck_draw_outbox`
--

LOCK TABLES `aoo_luck_draw_outbox` WRITE;
/*!40000 ALTER TABLE `aoo_luck_draw_outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_luck_draw_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_luck_draw_prize`
--

DROP TABLE IF EXISTS `aoo_luck_draw_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_luck_draw_prize` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint NOT NULL,
  `prize_code` varchar(64) NOT NULL,
  `prize_name` varchar(128) NOT NULL,
  `reward_kind` varchar(16) NOT NULL,
  `reward_code` varchar(64) NOT NULL,
  `reward_amount` bigint NOT NULL,
  `weight` bigint NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_luck_draw_prize` (`campaign_id`,`prize_code`),
  CONSTRAINT `fk_luck_draw_prize_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `aoo_luck_draw_campaign` (`id`),
  CONSTRAINT `chk_luck_draw_reward_amount` CHECK ((`reward_amount` > 0)),
  CONSTRAINT `chk_luck_draw_reward_kind` CHECK ((`reward_kind` in (_utf8mb4'CURRENCY',_utf8mb4'ITEM'))),
  CONSTRAINT `chk_luck_draw_weight` CHECK ((`weight` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_luck_draw_prize`
--

LOCK TABLES `aoo_luck_draw_prize` WRITE;
/*!40000 ALTER TABLE `aoo_luck_draw_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_luck_draw_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_maintenance_window`
--

DROP TABLE IF EXISTS `aoo_maintenance_window`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_maintenance_window` (
  `id` bigint NOT NULL,
  `platform` varchar(32) NOT NULL DEFAULT '*',
  `channel` varchar(64) NOT NULL DEFAULT '*',
  `starts_at` timestamp(3) NOT NULL,
  `ends_at` timestamp(3) NOT NULL,
  `message` varchar(500) NOT NULL,
  `login_blocked` tinyint(1) NOT NULL DEFAULT '1',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `ix_maintenance_active` (`enabled`,`starts_at`,`ends_at`),
  CONSTRAINT `ck_maintenance_time` CHECK ((`ends_at` > `starts_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_maintenance_window`
--

LOCK TABLES `aoo_maintenance_window` WRITE;
/*!40000 ALTER TABLE `aoo_maintenance_window` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_maintenance_window` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_match`
--

DROP TABLE IF EXISTS `aoo_match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_match` (
  `match_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  `room_id` bigint NOT NULL,
  `room_route` varchar(1024) NOT NULL,
  `state` varchar(24) NOT NULL,
  `confirm_deadline` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`match_id`),
  UNIQUE KEY `room_id` (`room_id`),
  KEY `idx_match_confirm_expiry` (`state`,`confirm_deadline`),
  CONSTRAINT `chk_match_state` CHECK ((`state` in (_utf8mb4'PENDING_CONFIRM',_utf8mb4'CONFIRMED',_utf8mb4'EXPIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_match`
--

LOCK TABLES `aoo_match` WRITE;
/*!40000 ALTER TABLE `aoo_match` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_match_member`
--

DROP TABLE IF EXISTS `aoo_match_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_match_member` (
  `match_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `confirmed_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`match_id`,`player_id`),
  CONSTRAINT `fk_match_member_match` FOREIGN KEY (`match_id`) REFERENCES `aoo_match` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_match_member`
--

LOCK TABLES `aoo_match_member` WRITE;
/*!40000 ALTER TABLE `aoo_match_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_match_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_match_queue`
--

DROP TABLE IF EXISTS `aoo_match_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_match_queue` (
  `player_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `state` varchar(24) NOT NULL,
  `enqueued_at` timestamp(3) NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `match_id` bigint DEFAULT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`player_id`,`game_id`),
  KEY `idx_match_queue_expiry` (`state`,`expires_at`),
  KEY `idx_match_queue_candidate` (`game_id`,`play_version`,`state`,`enqueued_at`,`player_id`),
  CONSTRAINT `chk_match_queue_state` CHECK ((`state` in (_utf8mb4'WAITING',_utf8mb4'MATCHED',_utf8mb4'COMPLETED',_utf8mb4'CANCELLED',_utf8mb4'TIMED_OUT')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_match_queue`
--

LOCK TABLES `aoo_match_queue` WRITE;
/*!40000 ALTER TABLE `aoo_match_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_match_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_migration_run`
--

DROP TABLE IF EXISTS `aoo_migration_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_migration_run` (
  `migration_run_id` bigint unsigned NOT NULL,
  `migration_code` varchar(128) NOT NULL,
  `source_system` varchar(64) NOT NULL,
  `authority_mode` varchar(24) NOT NULL,
  `schema_phase` varchar(16) NOT NULL,
  `source_snapshot_hash` char(64) NOT NULL,
  `source_count` bigint unsigned NOT NULL,
  `target_count` bigint unsigned DEFAULT NULL,
  `source_business_hash` char(64) DEFAULT NULL,
  `target_business_hash` char(64) DEFAULT NULL,
  `source_balance` decimal(38,9) DEFAULT NULL,
  `target_balance` decimal(38,9) DEFAULT NULL,
  `orphan_count` bigint unsigned DEFAULT NULL,
  `mismatch_count` bigint unsigned DEFAULT NULL,
  `checkpoint` json DEFAULT NULL,
  `rollback_manifest` json NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'PLANNED',
  `started_at` datetime(3) DEFAULT NULL,
  `completed_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`migration_run_id`),
  UNIQUE KEY `uk_migration_run_code_snapshot` (`migration_code`,`source_snapshot_hash`),
  KEY `idx_migration_run_status` (`status`,`started_at`,`migration_run_id`),
  CONSTRAINT `chk_migration_authority` CHECK ((`authority_mode` in (_utf8mb4'LEGACY',_utf8mb4'DUAL_WRITE',_utf8mb4'AOO',_utf8mb4'READ_ONLY_VERIFY'))),
  CONSTRAINT `chk_migration_counts` CHECK (((`target_count` is null) or (`target_count` <= 18446744073709551615))),
  CONSTRAINT `chk_migration_run_status` CHECK ((`status` in (_utf8mb4'PLANNED',_utf8mb4'DRY_RUN',_utf8mb4'RUNNING',_utf8mb4'PAUSED',_utf8mb4'VALIDATING',_utf8mb4'PASSED',_utf8mb4'FAILED',_utf8mb4'ROLLED_BACK'))),
  CONSTRAINT `chk_migration_schema_phase` CHECK ((`schema_phase` in (_utf8mb4'EXPAND',_utf8mb4'MIGRATE',_utf8mb4'CONTRACT'))),
  CONSTRAINT `chk_migration_source_hash` CHECK (regexp_like(`source_snapshot_hash`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_migration_run`
--

LOCK TABLES `aoo_migration_run` WRITE;
/*!40000 ALTER TABLE `aoo_migration_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_migration_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_migration_validation`
--

DROP TABLE IF EXISTS `aoo_migration_validation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_migration_validation` (
  `migration_run_id` bigint unsigned NOT NULL,
  `validation_code` varchar(64) NOT NULL,
  `validation_type` varchar(24) NOT NULL,
  `expected_value` varchar(512) NOT NULL,
  `actual_value` varchar(512) NOT NULL,
  `sample_evidence` json DEFAULT NULL,
  `passed` tinyint unsigned NOT NULL,
  `validated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`migration_run_id`,`validation_code`),
  KEY `idx_migration_validation_failure` (`passed`,`validation_type`,`migration_run_id`),
  CONSTRAINT `fk_migration_validation_run` FOREIGN KEY (`migration_run_id`) REFERENCES `aoo_migration_run` (`migration_run_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_migration_validation_passed` CHECK ((`passed` in (0,1))),
  CONSTRAINT `chk_migration_validation_type` CHECK ((`validation_type` in (_utf8mb4'COUNT',_utf8mb4'HASH',_utf8mb4'BALANCE',_utf8mb4'FOREIGN_KEY',_utf8mb4'UNIQUENESS',_utf8mb4'ENUM',_utf8mb4'SAMPLE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_migration_validation`
--

LOCK TABLES `aoo_migration_validation` WRITE;
/*!40000 ALTER TABLE `aoo_migration_validation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_migration_validation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_online_ddl_observation`
--

DROP TABLE IF EXISTS `aoo_online_ddl_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_online_ddl_observation` (
  `observation_id` bigint unsigned NOT NULL,
  `change_id` bigint unsigned NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `mysql_version` varchar(64) NOT NULL,
  `table_rows_before` bigint unsigned NOT NULL,
  `table_bytes_before` bigint unsigned NOT NULL,
  `lock_wait_ms` bigint unsigned NOT NULL,
  `replica_lag_peak_ms` bigint unsigned NOT NULL,
  `rows_copied` bigint unsigned NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) NOT NULL,
  `passed` tinyint unsigned NOT NULL,
  `evidence_uri` varchar(512) NOT NULL,
  PRIMARY KEY (`observation_id`),
  UNIQUE KEY `uk_online_ddl_observation` (`change_id`,`environment_code`,`started_at`),
  KEY `idx_online_ddl_result` (`passed`,`completed_at`,`change_id`),
  CONSTRAINT `fk_online_ddl_change` FOREIGN KEY (`change_id`) REFERENCES `aoo_schema_change_plan` (`change_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_online_ddl_passed` CHECK ((`passed` in (0,1))),
  CONSTRAINT `chk_online_ddl_time` CHECK ((`completed_at` >= `started_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_online_ddl_observation`
--

LOCK TABLES `aoo_online_ddl_observation` WRITE;
/*!40000 ALTER TABLE `aoo_online_ddl_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_online_ddl_observation` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_online_ddl_score_insert` BEFORE INSERT ON `aoo_online_ddl_observation` FOR EACH ROW BEGIN
    DECLARE v_max_lock BIGINT UNSIGNED;
    DECLARE v_max_lag BIGINT UNSIGNED;
    SELECT maximum_lock_ms,maximum_replica_lag_ms
      INTO v_max_lock,v_max_lag
      FROM aoo_schema_change_plan WHERE change_id=NEW.change_id;
    SET NEW.passed=(NEW.completed_at>=NEW.started_at AND NEW.lock_wait_ms<=v_max_lock AND NEW.replica_lag_peak_ms<=v_max_lag);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_outbox`
--

DROP TABLE IF EXISTS `aoo_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_outbox` (
  `event_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `event_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_version` int NOT NULL DEFAULT '1',
  `payload` json NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` datetime(3) NOT NULL,
  `published_at` datetime(3) DEFAULT NULL,
  `retry_count` int NOT NULL DEFAULT '0',
  `locked_by` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `claim_token` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locked_until` datetime(3) DEFAULT NULL,
  `dead_at` datetime(3) DEFAULT NULL,
  `next_attempt_at` datetime(3) DEFAULT NULL,
  `last_error` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `idx_outbox_unpublished` (`published_at`,`created_at`),
  KEY `idx_outbox_retry` (`published_at`,`next_attempt_at`,`created_at`),
  KEY `idx_outbox_claim` (`status`,`next_attempt_at`,`locked_until`,`created_at`),
  KEY `idx_outbox_cleanup` (`status`,`published_at`),
  KEY `idx_outbox_event_schema` (`event_type`,`schema_version`,`created_at`),
  KEY `idx_outbox_dead_cleanup` (`status`,`dead_at`),
  CONSTRAINT `chk_edge_outbox_claim` CHECK ((((`status` = _utf8mb4'PROCESSING') and (`locked_by` is not null) and (`claim_token` is not null) and (`locked_until` is not null)) or (`status` <> _utf8mb4'PROCESSING'))),
  CONSTRAINT `chk_edge_outbox_status` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'PROCESSING',_utf8mb4'PUBLISHED',_utf8mb4'DEAD')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_outbox`
--

LOCK TABLES `aoo_outbox` WRITE;
/*!40000 ALTER TABLE `aoo_outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_pagination_contract`
--

DROP TABLE IF EXISTS `aoo_pagination_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_pagination_contract` (
  `query_code` varchar(128) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `filter_columns` varchar(512) NOT NULL,
  `order_columns` varchar(512) NOT NULL,
  `cursor_columns` varchar(512) NOT NULL,
  `maximum_page_size` int unsigned NOT NULL,
  `offset_allowed` tinyint unsigned NOT NULL DEFAULT '0',
  `covering_index_name` varchar(64) NOT NULL,
  PRIMARY KEY (`query_code`),
  KEY `idx_pagination_table` (`table_name`,`query_code`),
  CONSTRAINT `chk_pagination_offset` CHECK ((`offset_allowed` in (0,1))),
  CONSTRAINT `chk_pagination_size` CHECK (((`maximum_page_size` > 0) and (`maximum_page_size` <= 1000)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_pagination_contract`
--

LOCK TABLES `aoo_pagination_contract` WRITE;
/*!40000 ALTER TABLE `aoo_pagination_contract` DISABLE KEYS */;
INSERT INTO `aoo_pagination_contract` VALUES ('CLUB_MEMBER_DIRECTORY','aoo_club_member','club_id,member_status','player_id ASC','player_id',200,0,'idx_club_member_page'),('LEDGER_PLAYER_HISTORY','aoo_ledger','player_id,currency,currency_scope_id','created_at DESC,ledger_id DESC','created_at,ledger_id',200,0,'idx_ledger_player_scope_time'),('REPLAY_PLAYER_VIEW','perspective_replay_event','owner_player_id,room_id,set_id','event_sequence ASC','event_sequence',500,0,'idx_replay_player_view'),('ROOM_EVENT_FORWARD','aoo_room_event','room_id','event_sequence ASC','room_id,event_sequence',500,0,'PRIMARY'),('ROOM_TEMPLATE_ACTIVE','aoo_room_template','club_id,status','updated_at DESC,template_code ASC','updated_at,template_code',100,0,'idx_template_catalog');
/*!40000 ALTER TABLE `aoo_pagination_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_payment_order`
--

DROP TABLE IF EXISTS `aoo_payment_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_payment_order` (
  `order_id` varchar(128) NOT NULL,
  `buyer_player_id` bigint unsigned NOT NULL,
  `asset_currency` varchar(32) NOT NULL,
  `asset_scope_id` bigint unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(64) NOT NULL,
  `product_version` bigint unsigned NOT NULL,
  `asset_units` bigint unsigned NOT NULL,
  `fiat_currency` char(3) NOT NULL,
  `amount_minor` bigint unsigned NOT NULL,
  `channel_code` varchar(32) NOT NULL,
  `product_locked_at` datetime(3) NOT NULL,
  `product_fingerprint` char(64) NOT NULL,
  `state` varchar(24) NOT NULL,
  `provider_transaction_id` varchar(128) DEFAULT NULL,
  `callback_digests` mediumtext NOT NULL,
  `failure_code` varchar(64) DEFAULT NULL,
  `version` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `paid_at` datetime(3) DEFAULT NULL,
  `delivered_at` datetime(3) DEFAULT NULL,
  `refunded_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `uk_payment_provider_transaction` (`provider_transaction_id`),
  KEY `idx_payment_reconcile` (`channel_code`,`state`,`created_at`),
  CONSTRAINT `chk_payment_order_state` CHECK ((`state` in (_utf8mb4'CREATED',_utf8mb4'PAID',_utf8mb4'DELIVERED',_utf8mb4'REFUND_PENDING',_utf8mb4'REFUNDED',_utf8mb4'CLOSED',_utf8mb4'REVIEW')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_payment_order`
--

LOCK TABLES `aoo_payment_order` WRITE;
/*!40000 ALTER TABLE `aoo_payment_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_payment_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_payment_product`
--

DROP TABLE IF EXISTS `aoo_payment_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_payment_product` (
  `product_code` varchar(64) NOT NULL,
  `channel_code` varchar(32) NOT NULL,
  `product_version` bigint unsigned NOT NULL,
  `asset_currency` varchar(32) NOT NULL,
  `asset_units` bigint unsigned NOT NULL,
  `fiat_currency` char(3) NOT NULL,
  `amount_minor` bigint unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `valid_from` datetime(3) NOT NULL,
  `valid_until` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`product_code`,`channel_code`,`product_version`),
  KEY `idx_payment_product_active` (`product_code`,`channel_code`,`status`,`valid_from`,`valid_until`),
  KEY `fk_payment_product_currency` (`asset_currency`),
  CONSTRAINT `fk_payment_product_currency` FOREIGN KEY (`asset_currency`) REFERENCES `aoo_currency_catalog` (`currency_code`),
  CONSTRAINT `chk_payment_product_amounts` CHECK (((`asset_units` > 0) and (`amount_minor` > 0))),
  CONSTRAINT `chk_payment_product_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_payment_product`
--

LOCK TABLES `aoo_payment_product` WRITE;
/*!40000 ALTER TABLE `aoo_payment_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_payment_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_payment_transaction_claim`
--

DROP TABLE IF EXISTS `aoo_payment_transaction_claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_payment_transaction_claim` (
  `provider_transaction_id` varchar(128) NOT NULL,
  `order_id` varchar(128) NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`provider_transaction_id`),
  KEY `idx_payment_claim_order` (`order_id`),
  CONSTRAINT `fk_payment_claim_order` FOREIGN KEY (`order_id`) REFERENCES `aoo_payment_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_payment_transaction_claim`
--

LOCK TABLES `aoo_payment_transaction_claim` WRITE;
/*!40000 ALTER TABLE `aoo_payment_transaction_claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_payment_transaction_claim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_phone_challenge`
--

DROP TABLE IF EXISTS `aoo_phone_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_phone_challenge` (
  `challenge_id` char(36) NOT NULL,
  `account_id` bigint NOT NULL,
  `phone_cipher` text NOT NULL,
  `phone_token` varchar(64) NOT NULL,
  `masked_phone` varchar(32) NOT NULL,
  `code_hash` varchar(64) NOT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `expires_at` timestamp(6) NOT NULL,
  `verified_at` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`challenge_id`),
  KEY `ix_phone_challenge_account_time` (`account_id`,`created_at`),
  KEY `ix_phone_challenge_token_time` (`phone_token`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_phone_challenge`
--

LOCK TABLES `aoo_phone_challenge` WRITE;
/*!40000 ALTER TABLE `aoo_phone_challenge` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_phone_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_play_component_binding`
--

DROP TABLE IF EXISTS `aoo_play_component_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_play_component_binding` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `component_type` varchar(32) NOT NULL,
  `ordinal` smallint unsigned NOT NULL,
  `component_id` bigint unsigned NOT NULL,
  `parameters` json NOT NULL,
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`game_id`,`play_version`,`component_type`,`ordinal`),
  UNIQUE KEY `uk_play_component_instance` (`game_id`,`play_version`,`component_id`),
  KEY `idx_play_component_component` (`component_id`,`game_id`,`play_version`),
  KEY `fk_play_component_type` (`component_type`),
  CONSTRAINT `fk_play_component_component` FOREIGN KEY (`component_id`) REFERENCES `aoo_game_component` (`component_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_play_component_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_play_component_type` FOREIGN KEY (`component_type`) REFERENCES `aoo_component_type` (`component_type`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_play_component_binding`
--

LOCK TABLES `aoo_play_component_binding` WRITE;
/*!40000 ALTER TABLE `aoo_play_component_binding` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_play_component_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_play_variant`
--

DROP TABLE IF EXISTS `aoo_play_variant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_play_variant` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `component_version` varchar(64) NOT NULL,
  `rule_schema_version` int unsigned NOT NULL,
  `status` varchar(16) NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`game_id`,`play_version`,`region_code`),
  UNIQUE KEY `uk_play_component_region` (`component_version`,`game_id`,`region_code`),
  KEY `idx_play_region_status` (`region_code`,`status`,`game_id`),
  KEY `idx_play_active_region` (`region_code`,`status`,`game_id`,`play_version`),
  CONSTRAINT `chk_play_variant` CHECK (((`game_id` > 0) and (`rule_schema_version` > 0) and (`status` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'RETIRED'))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_play_variant`
--

LOCK TABLES `aoo_play_variant` WRITE;
/*!40000 ALTER TABLE `aoo_play_variant` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_play_variant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_play_version`
--

DROP TABLE IF EXISTS `aoo_play_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_play_version` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `default_region_code` varchar(32) NOT NULL,
  `rule_schema_version` int unsigned NOT NULL,
  `ui_schema_version` int unsigned NOT NULL,
  `component_schema_version` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'DRAFT',
  `compatibility_floor` varchar(64) DEFAULT NULL,
  `activated_at` datetime(3) DEFAULT NULL,
  `retired_at` datetime(3) DEFAULT NULL,
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`,`play_version`),
  UNIQUE KEY `uk_play_version_content` (`game_id`,`content_hash`),
  KEY `idx_play_version_status` (`status`,`game_id`,`activated_at`),
  KEY `idx_play_version_region` (`default_region_code`,`status`,`game_id`),
  CONSTRAINT `fk_play_version_game` FOREIGN KEY (`game_id`) REFERENCES `aoo_game_catalog` (`game_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_play_version_region` FOREIGN KEY (`default_region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_play_version_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_play_version_lifecycle` CHECK (((`retired_at` is null) or (`activated_at` is not null))),
  CONSTRAINT `chk_play_version_name` CHECK (regexp_like(`play_version`,_utf8mb4'^[a-z0-9][a-z0-9._-]{0,63}$')),
  CONSTRAINT `chk_play_version_schemas` CHECK (((`rule_schema_version` > 0) and (`ui_schema_version` > 0) and (`component_schema_version` > 0))),
  CONSTRAINT `chk_play_version_status` CHECK ((`status` in (_utf8mb4'DRAFT',_utf8mb4'VALIDATED',_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_play_version`
--

LOCK TABLES `aoo_play_version` WRITE;
/*!40000 ALTER TABLE `aoo_play_version` DISABLE KEYS */;
INSERT INTO `aoo_play_version` VALUES (8,'1.0.0','CN-51-01',1,1,1,'feffc37edab03e162b786483bffadf3badb07677ab55ffdcf97d02499925509c','ACTIVE',NULL,'2026-09-26 12:28:19.429',NULL,2,1,'2026-09-26 12:28:19.429','2026-09-26 12:28:19.596'),(629,'legacy-equivalent-1','CN-51',1,1,1,'3c0682ac1a5673f1d8d158e12a81fc80f9b5f40cb659fcd4adf13cb4d4e6c37c','ACTIVE',NULL,'2026-09-26 12:28:19.427',NULL,1,1,'2026-09-26 12:28:19.427','2026-09-26 12:28:19.427'),(90005,'xqp-equivalent-1','CN-51-34',3,3,1,'1d82c74410f4f92292b27dd563e03c4b6d47848a35fed0722a18c2c9eab2bf32','ACTIVE',NULL,'2026-09-26 12:28:19.751',NULL,3,1,'2026-09-26 12:28:19.751','2026-09-26 12:28:19.985');
/*!40000 ALTER TABLE `aoo_play_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_play_version_row_version` BEFORE UPDATE ON `aoo_play_version` FOR EACH ROW BEGIN
    SET NEW.row_version=OLD.row_version+1;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_player_risk_observation`
--

DROP TABLE IF EXISTS `aoo_player_risk_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_player_risk_observation` (
  `observation_id` varchar(64) NOT NULL,
  `player_id` bigint NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `signal_type` varchar(32) NOT NULL,
  `authorization_state` varchar(32) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `accuracy_meters` decimal(10,2) DEFAULT NULL,
  `ip_address` varbinary(16) DEFAULT NULL,
  `device_hash` char(64) DEFAULT NULL,
  `observed_at` timestamp(3) NOT NULL,
  `schema_version` varchar(32) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`observation_id`),
  KEY `idx_player_risk_room_time` (`room_id`,`observed_at`),
  KEY `idx_player_risk_player_time` (`player_id`,`observed_at`),
  KEY `idx_player_risk_device_time` (`device_hash`,`observed_at`),
  CONSTRAINT `ck_player_risk_accuracy` CHECK (((`accuracy_meters` is null) or (`accuracy_meters` >= 0))),
  CONSTRAINT `ck_player_risk_coordinates` CHECK ((((`latitude` is null) and (`longitude` is null)) or ((`latitude` between -(90) and 90) and (`longitude` between -(180) and 180)))),
  CONSTRAINT `ck_player_risk_device_hash` CHECK (((`device_hash` is null) or regexp_like(`device_hash`,_utf8mb4'^[0-9a-f]{64}$')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_player_risk_observation`
--

LOCK TABLES `aoo_player_risk_observation` WRITE;
/*!40000 ALTER TABLE `aoo_player_risk_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_player_risk_observation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_privacy_request`
--

DROP TABLE IF EXISTS `aoo_privacy_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_privacy_request` (
  `privacy_request_id` bigint unsigned NOT NULL,
  `subject_type` varchar(16) NOT NULL,
  `subject_id_hash` char(64) NOT NULL,
  `request_type` varchar(24) NOT NULL,
  `identity_verification_ref` varchar(256) NOT NULL,
  `legal_basis` varchar(128) NOT NULL,
  `requested_at` datetime(3) NOT NULL,
  `due_at` datetime(3) NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'RECEIVED',
  `completed_at` datetime(3) DEFAULT NULL,
  `result_manifest` json DEFAULT NULL,
  PRIMARY KEY (`privacy_request_id`),
  UNIQUE KEY `uk_privacy_request_subject` (`subject_id_hash`,`request_type`,`requested_at`),
  KEY `idx_privacy_request_due` (`status`,`due_at`,`privacy_request_id`),
  CONSTRAINT `chk_privacy_request_due` CHECK ((`due_at` > `requested_at`)),
  CONSTRAINT `chk_privacy_request_status` CHECK ((`status` in (_utf8mb4'RECEIVED',_utf8mb4'VERIFIED',_utf8mb4'ON_HOLD',_utf8mb4'RUNNING',_utf8mb4'COMPLETED',_utf8mb4'REJECTED'))),
  CONSTRAINT `chk_privacy_request_type` CHECK ((`request_type` in (_utf8mb4'ACCESS',_utf8mb4'EXPORT',_utf8mb4'ANONYMIZE',_utf8mb4'DELETE',_utf8mb4'RESTRICT'))),
  CONSTRAINT `chk_privacy_subject` CHECK ((`subject_type` in (_utf8mb4'PLAYER',_utf8mb4'OPERATOR'))),
  CONSTRAINT `chk_privacy_subject_hash` CHECK (regexp_like(`subject_id_hash`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_privacy_request`
--

LOCK TABLES `aoo_privacy_request` WRITE;
/*!40000 ALTER TABLE `aoo_privacy_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_privacy_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_published_game_configuration`
--

DROP TABLE IF EXISTS `aoo_published_game_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_published_game_configuration` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `release_id` bigint unsigned DEFAULT NULL,
  `configuration_payload` json NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`game_id`,`play_version`),
  KEY `idx_published_configuration_release` (`release_id`,`game_id`,`play_version`),
  CONSTRAINT `fk_published_configuration_play` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_published_configuration_release_identity` FOREIGN KEY (`release_id`, `game_id`, `play_version`) REFERENCES `aoo_game_release` (`release_id`, `game_id`, `play_version`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_published_game_configuration`
--

LOCK TABLES `aoo_published_game_configuration` WRITE;
/*!40000 ALTER TABLE `aoo_published_game_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_published_game_configuration` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_published_configuration_release_required` BEFORE INSERT ON `aoo_published_game_configuration` FOR EACH ROW BEGIN
    DECLARE v_release_status VARCHAR(16) DEFAULT NULL;
    IF NEW.release_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='published configuration requires an immutable release';
    END IF;
    SELECT MAX(status) INTO v_release_status
      FROM aoo_game_release
     WHERE release_id=NEW.release_id
       AND game_id=NEW.game_id
       AND play_version=NEW.play_version;
    IF v_release_status IS NULL OR v_release_status NOT IN ('VALIDATED','ACTIVE') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='configuration release is not publishable';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_query_baseline`
--

DROP TABLE IF EXISTS `aoo_query_baseline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_query_baseline` (
  `query_code` varchar(128) NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `sql_template` text NOT NULL,
  `sql_hash` char(64) NOT NULL,
  `expected_index` varchar(64) NOT NULL,
  `maximum_examined_rows` bigint unsigned NOT NULL,
  `maximum_result_rows` bigint unsigned NOT NULL,
  `maximum_p95_ms` decimal(12,3) NOT NULL,
  `maximum_p99_ms` decimal(12,3) NOT NULL,
  `full_scan_allowed` tinyint unsigned NOT NULL DEFAULT '0',
  `filesort_allowed` tinyint unsigned NOT NULL DEFAULT '0',
  `temporary_table_allowed` tinyint unsigned NOT NULL DEFAULT '0',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`query_code`),
  KEY `fk_query_baseline_owner` (`owner_code`),
  CONSTRAINT `fk_query_baseline_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_query_baseline_flags` CHECK (((`full_scan_allowed` in (0,1)) and (`filesort_allowed` in (0,1)) and (`temporary_table_allowed` in (0,1)))),
  CONSTRAINT `chk_query_baseline_hash` CHECK (regexp_like(`sql_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_query_baseline_limits` CHECK (((`maximum_result_rows` > 0) and (`maximum_examined_rows` >= `maximum_result_rows`) and (`maximum_p99_ms` >= `maximum_p95_ms`))),
  CONSTRAINT `chk_query_baseline_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_query_baseline`
--

LOCK TABLES `aoo_query_baseline` WRITE;
/*!40000 ALTER TABLE `aoo_query_baseline` DISABLE KEYS */;
INSERT INTO `aoo_query_baseline` VALUES ('CLUB_MEMBER_KEYSET','CLUB','SELECT * FROM aoo_club_member WHERE club_id=? AND member_status=? AND player_id>? ORDER BY player_id LIMIT ?','20554d44a1b29f4daeb3453c1cfd38cea385a5d117cb7d566242a0bdb014c82a','idx_club_member_page',200,200,30.000,75.000,0,0,0,'ACTIVE'),('LEDGER_PLAYER_HISTORY','PLAYER_ASSET','SELECT * FROM aoo_ledger WHERE player_id=? AND currency=? AND currency_scope_id=? AND (created_at,ledger_id)<(?,?) ORDER BY created_at DESC,ledger_id DESC LIMIT ?','da9157cae29db97de5473ad6358ccdc5b7b55d86d254fea4d66fd2a6eff824ba','idx_ledger_player_scope_time',200,200,30.000,75.000,0,0,0,'ACTIVE'),('REPLAY_PLAYER_FORWARD','GAME_RUNTIME','SELECT * FROM perspective_replay_event WHERE owner_player_id=? AND room_id=? AND set_id=? AND event_sequence>? ORDER BY event_sequence LIMIT ?','256bfea4fbdca03bb0b7341c91f7c3bdefa7f75003c780a4adafce8beeee82e6','idx_replay_player_view',500,500,50.000,125.000,0,0,0,'ACTIVE'),('ROOM_CREATE_INDEX_DIRECT','GAME_CATALOG','SELECT * FROM aoo_compiled_index_active a JOIN aoo_compiled_room_create_index i USING(game_id,region_code,play_version,index_generation) WHERE a.game_id=? AND a.region_code=?','d403d4453fe63f16923afce77272e989bc9d2c3c111fd9c484d16cf26dbc16b2','PRIMARY',2,1,5.000,15.000,0,0,0,'ACTIVE'),('ROOM_EVENT_FORWARD','GAME_RUNTIME','SELECT * FROM aoo_room_event WHERE room_id=? AND event_sequence>? AND visibility=? AND owner_player_id=? ORDER BY event_sequence LIMIT ?','872030171aa04aa4a38f8135df63981f200d7acc7f6d1dbefdca7ddbfd60d704','PRIMARY',500,500,20.000,50.000,0,0,0,'ACTIVE');
/*!40000 ALTER TABLE `aoo_query_baseline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_query_plan_observation`
--

DROP TABLE IF EXISTS `aoo_query_plan_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_query_plan_observation` (
  `observation_id` bigint unsigned NOT NULL,
  `query_code` varchar(128) NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `mysql_version` varchar(64) NOT NULL,
  `dataset_hash` char(64) NOT NULL,
  `dataset_rows` bigint unsigned NOT NULL,
  `explain_json` json NOT NULL,
  `access_type` varchar(24) NOT NULL,
  `selected_index` varchar(64) DEFAULT NULL,
  `examined_rows` bigint unsigned NOT NULL,
  `result_rows` bigint unsigned NOT NULL,
  `uses_filesort` tinyint unsigned NOT NULL,
  `uses_temporary_table` tinyint unsigned NOT NULL,
  `p50_ms` decimal(12,3) NOT NULL,
  `p95_ms` decimal(12,3) NOT NULL,
  `p99_ms` decimal(12,3) NOT NULL,
  `sample_count` int unsigned NOT NULL,
  `passed` tinyint unsigned NOT NULL,
  `observed_at` datetime(3) NOT NULL,
  PRIMARY KEY (`observation_id`),
  UNIQUE KEY `uk_query_plan_environment_dataset` (`query_code`,`environment_code`,`dataset_hash`,`observed_at`),
  KEY `idx_query_plan_failures` (`passed`,`observed_at`,`query_code`),
  CONSTRAINT `fk_query_plan_baseline` FOREIGN KEY (`query_code`) REFERENCES `aoo_query_baseline` (`query_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_query_plan_dataset_hash` CHECK (regexp_like(`dataset_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_query_plan_flags` CHECK (((`uses_filesort` in (0,1)) and (`uses_temporary_table` in (0,1)) and (`passed` in (0,1)))),
  CONSTRAINT `chk_query_plan_order` CHECK (((`p50_ms` <= `p95_ms`) and (`p95_ms` <= `p99_ms`))),
  CONSTRAINT `chk_query_plan_samples` CHECK ((`sample_count` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_query_plan_observation`
--

LOCK TABLES `aoo_query_plan_observation` WRITE;
/*!40000 ALTER TABLE `aoo_query_plan_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_query_plan_observation` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_query_plan_score_insert` BEFORE INSERT ON `aoo_query_plan_observation` FOR EACH ROW BEGIN
    DECLARE v_max_examined BIGINT UNSIGNED;
    DECLARE v_max_result BIGINT UNSIGNED;
    DECLARE v_max_p95 DECIMAL(12,3);
    DECLARE v_max_p99 DECIMAL(12,3);
    DECLARE v_full_scan TINYINT UNSIGNED;
    DECLARE v_filesort TINYINT UNSIGNED;
    DECLARE v_temporary TINYINT UNSIGNED;
    DECLARE v_expected_index VARCHAR(64);

    SELECT maximum_examined_rows,maximum_result_rows,maximum_p95_ms,maximum_p99_ms,
           full_scan_allowed,filesort_allowed,temporary_table_allowed,expected_index
      INTO v_max_examined,v_max_result,v_max_p95,v_max_p99,
           v_full_scan,v_filesort,v_temporary,v_expected_index
      FROM aoo_query_baseline WHERE query_code=NEW.query_code;

    SET NEW.passed=(
        NEW.examined_rows<=v_max_examined AND NEW.result_rows<=v_max_result
        AND NEW.p95_ms<=v_max_p95 AND NEW.p99_ms<=v_max_p99
        AND (v_full_scan=1 OR NEW.access_type NOT IN ('ALL','INDEX'))
        AND (v_filesort=1 OR NEW.uses_filesort=0)
        AND (v_temporary=1 OR NEW.uses_temporary_table=0)
        AND NEW.selected_index=v_expected_index
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_rank_score`
--

DROP TABLE IF EXISTS `aoo_rank_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_rank_score` (
  `season_id` varchar(64) NOT NULL,
  `player_id` bigint NOT NULL,
  `score` bigint NOT NULL,
  `updated_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`season_id`,`player_id`),
  KEY `ix_rank_page` (`season_id`,`score` DESC,`player_id`),
  CONSTRAINT `fk_rank_season` FOREIGN KEY (`season_id`) REFERENCES `aoo_rank_season` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_rank_score`
--

LOCK TABLES `aoo_rank_score` WRITE;
/*!40000 ALTER TABLE `aoo_rank_score` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_rank_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_rank_season`
--

DROP TABLE IF EXISTS `aoo_rank_season`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_rank_season` (
  `id` varchar(64) NOT NULL,
  `period_type` enum('DAILY','WEEKLY','SEASON') NOT NULL,
  `starts_at` timestamp(6) NOT NULL,
  `ends_at` timestamp(6) NOT NULL,
  `state` enum('ACTIVE','FROZEN','CLOSED') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_rank_season_window` (`period_type`,`state`,`starts_at`,`ends_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_rank_season`
--

LOCK TABLES `aoo_rank_season` WRITE;
/*!40000 ALTER TABLE `aoo_rank_season` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_rank_season` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_redemption_campaign`
--

DROP TABLE IF EXISTS `aoo_redemption_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_redemption_campaign` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(64) NOT NULL,
  `item_code` varchar(64) NOT NULL,
  `item_quantity` bigint NOT NULL,
  `grant_expires_at` timestamp(3) NULL DEFAULT NULL,
  `active_from` timestamp(3) NOT NULL,
  `active_until` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_code` (`campaign_code`),
  KEY `item_code` (`item_code`),
  CONSTRAINT `aoo_redemption_campaign_ibfk_1` FOREIGN KEY (`item_code`) REFERENCES `aoo_item_catalog` (`item_code`),
  CONSTRAINT `aoo_redemption_campaign_chk_1` CHECK ((`item_quantity` > 0)),
  CONSTRAINT `aoo_redemption_campaign_chk_2` CHECK ((`active_until` > `active_from`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_redemption_campaign`
--

LOCK TABLES `aoo_redemption_campaign` WRITE;
/*!40000 ALTER TABLE `aoo_redemption_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_redemption_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_redemption_claim`
--

DROP TABLE IF EXISTS `aoo_redemption_claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_redemption_claim` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint NOT NULL,
  `code_hash` char(64) NOT NULL,
  `player_id` bigint NOT NULL,
  `command_id` varchar(128) NOT NULL,
  `claimed_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_hash` (`code_hash`),
  UNIQUE KEY `campaign_id` (`campaign_id`,`player_id`),
  UNIQUE KEY `command_id` (`command_id`),
  CONSTRAINT `aoo_redemption_claim_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `aoo_redemption_campaign` (`id`),
  CONSTRAINT `aoo_redemption_claim_ibfk_2` FOREIGN KEY (`code_hash`) REFERENCES `aoo_redemption_code` (`code_hash`),
  CONSTRAINT `aoo_redemption_claim_ibfk_3` FOREIGN KEY (`command_id`) REFERENCES `aoo_inventory_command` (`command_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_redemption_claim`
--

LOCK TABLES `aoo_redemption_claim` WRITE;
/*!40000 ALTER TABLE `aoo_redemption_claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_redemption_claim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_redemption_code`
--

DROP TABLE IF EXISTS `aoo_redemption_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_redemption_code` (
  `code_hash` char(64) NOT NULL,
  `campaign_id` bigint NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`code_hash`),
  KEY `campaign_id` (`campaign_id`),
  CONSTRAINT `aoo_redemption_code_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `aoo_redemption_campaign` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_redemption_code`
--

LOCK TABLES `aoo_redemption_code` WRITE;
/*!40000 ALTER TABLE `aoo_redemption_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_redemption_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_region`
--

DROP TABLE IF EXISTS `aoo_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_region` (
  `region_code` varchar(32) NOT NULL,
  `parent_region_code` varchar(32) DEFAULT NULL,
  `region_type` varchar(16) NOT NULL,
  `country_code` char(2) DEFAULT NULL,
  `subdivision_code` varchar(16) DEFAULT NULL,
  `display_name` varchar(64) NOT NULL,
  `path` varchar(256) NOT NULL,
  `depth` tinyint unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`region_code`),
  UNIQUE KEY `uk_region_path` (`path`),
  KEY `idx_region_parent` (`parent_region_code`,`status`,`region_code`),
  KEY `idx_region_country_subdivision` (`country_code`,`subdivision_code`,`status`),
  CONSTRAINT `fk_region_parent` FOREIGN KEY (`parent_region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_region_code` CHECK (regexp_like(`region_code`,_utf8mb4'^[A-Z0-9][A-Z0-9-]{0,31}$')),
  CONSTRAINT `chk_region_depth` CHECK ((`depth` <= 4)),
  CONSTRAINT `chk_region_parent_shape` CHECK ((((`region_type` in (_utf8mb4'GLOBAL',_utf8mb4'NONE',_utf8mb4'COUNTRY')) and (`parent_region_code` is null)) or ((`region_type` in (_utf8mb4'PROVINCE',_utf8mb4'CITY',_utf8mb4'DISTRICT')) and (`parent_region_code` is not null)))),
  CONSTRAINT `chk_region_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED'))),
  CONSTRAINT `chk_region_type` CHECK ((`region_type` in (_utf8mb4'GLOBAL',_utf8mb4'NONE',_utf8mb4'COUNTRY',_utf8mb4'PROVINCE',_utf8mb4'CITY',_utf8mb4'DISTRICT')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_region`
--

LOCK TABLES `aoo_region` WRITE;
/*!40000 ALTER TABLE `aoo_region` DISABLE KEYS */;
INSERT INTO `aoo_region` VALUES ('CN',NULL,'COUNTRY','CN',NULL,'中国','/CN',0,'ACTIVE',1,'2026-09-26 12:28:16.821','2026-09-26 12:28:16.821'),('CN-11','CN','PROVINCE','CN','11','北京','/CN/CN-11',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-12','CN','PROVINCE','CN','12','天津','/CN/CN-12',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-13','CN','PROVINCE','CN','13','河北','/CN/CN-13',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-14','CN','PROVINCE','CN','14','山西','/CN/CN-14',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-15','CN','PROVINCE','CN','15','内蒙古','/CN/CN-15',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-21','CN','PROVINCE','CN','21','辽宁','/CN/CN-21',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-22','CN','PROVINCE','CN','22','吉林','/CN/CN-22',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-23','CN','PROVINCE','CN','23','黑龙江','/CN/CN-23',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-23-01','CN-23','CITY','CN','2301','哈尔滨','/CN/CN-23/CN-23-01',2,'ACTIVE',1,'2026-09-26 12:28:16.824','2026-09-26 12:28:16.824'),('CN-31','CN','PROVINCE','CN','31','上海','/CN/CN-31',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-32','CN','PROVINCE','CN','32','江苏','/CN/CN-32',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-33','CN','PROVINCE','CN','33','浙江','/CN/CN-33',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-34','CN','PROVINCE','CN','34','安徽','/CN/CN-34',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-35','CN','PROVINCE','CN','35','福建','/CN/CN-35',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-36','CN','PROVINCE','CN','36','江西','/CN/CN-36',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-37','CN','PROVINCE','CN','37','山东','/CN/CN-37',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-37-03','CN-37','CITY','CN','3703','淄博','/CN/CN-37/CN-37-03',2,'ACTIVE',1,'2026-09-26 12:28:16.824','2026-09-26 12:28:16.824'),('CN-37-03-02','CN-37-03','DISTRICT','CN','370302','淄川','/CN/CN-37/CN-37-03/CN-37-03-02',3,'ACTIVE',1,'2026-09-26 12:28:16.824','2026-09-26 12:28:16.824'),('CN-41','CN','PROVINCE','CN','41','河南','/CN/CN-41',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-42','CN','PROVINCE','CN','42','湖北','/CN/CN-42',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-43','CN','PROVINCE','CN','43','湖南','/CN/CN-43',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-43-11','CN-43','CITY','CN','4311','永州','/CN/CN-43/CN-43-11',2,'ACTIVE',1,'2026-09-26 12:28:18.802','2026-09-26 12:28:18.802'),('CN-44','CN','PROVINCE','CN','44','广东','/CN/CN-44',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-45','CN','PROVINCE','CN','45','广西','/CN/CN-45',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-46','CN','PROVINCE','CN','46','海南','/CN/CN-46',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-50','CN','PROVINCE','CN','50','重庆','/CN/CN-50',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-51','CN','PROVINCE','CN','51','四川','/CN/CN-51',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-51-01','CN-51','CITY','CN','5101','成都','/CN/CN-51/CN-51-01',2,'ACTIVE',1,'2026-09-26 12:28:18.802','2026-09-26 12:28:18.802'),('CN-51-10','CN-51','CITY','CN','5110','内江','/CN/CN-51/CN-51-10',2,'ACTIVE',1,'2026-09-26 12:28:19.584','2026-09-26 12:28:19.584'),('CN-51-34','CN-51','CITY','CN','5134','凉山','/CN/CN-51/CN-51-34',2,'ACTIVE',1,'2026-09-26 12:28:19.748','2026-09-26 12:28:19.748'),('CN-52','CN','PROVINCE','CN','52','贵州','/CN/CN-52',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-53','CN','PROVINCE','CN','53','云南','/CN/CN-53',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-54','CN','PROVINCE','CN','54','西藏','/CN/CN-54',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-61','CN','PROVINCE','CN','61','陕西','/CN/CN-61',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-62','CN','PROVINCE','CN','62','甘肃','/CN/CN-62',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-64','CN','PROVINCE','CN','64','宁夏','/CN/CN-64',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-65','CN','PROVINCE','CN','65','新疆','/CN/CN-65',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('CN-71','CN','PROVINCE','CN','71','台湾','/CN/CN-71',1,'ACTIVE',1,'2026-09-26 12:28:16.822','2026-09-26 12:28:16.822'),('GLOBAL',NULL,'GLOBAL',NULL,NULL,'全国/全球','/GLOBAL',0,'ACTIVE',1,'2026-09-26 12:28:16.821','2026-09-26 12:28:16.821'),('IN',NULL,'COUNTRY','IN',NULL,'印度','/IN',0,'ACTIVE',1,'2026-09-26 12:28:16.821','2026-09-26 12:28:16.821'),('JP',NULL,'COUNTRY','JP',NULL,'日本','/JP',0,'ACTIVE',1,'2026-09-26 12:28:16.821','2026-09-26 12:28:16.821'),('NONE',NULL,'NONE',NULL,NULL,'无地区','/NONE',0,'ACTIVE',1,'2026-09-26 12:28:16.821','2026-09-26 12:28:16.821');
/*!40000 ALTER TABLE `aoo_region` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_region_row_version` BEFORE UPDATE ON `aoo_region` FOR EACH ROW BEGIN
    SET NEW.row_version=OLD.row_version+1;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_region_alias`
--

DROP TABLE IF EXISTS `aoo_region_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_region_alias` (
  `source_system` varchar(32) NOT NULL,
  `source_region_code` varchar(64) NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `mapping_status` varchar(16) NOT NULL DEFAULT 'VERIFIED',
  `verified_by` bigint unsigned DEFAULT NULL,
  `verified_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`source_system`,`source_region_code`),
  KEY `idx_region_alias_target` (`region_code`,`mapping_status`),
  CONSTRAINT `fk_region_alias_target` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_region_alias_status` CHECK ((`mapping_status` in (_utf8mb4'PROPOSED',_utf8mb4'VERIFIED',_utf8mb4'REJECTED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_region_alias`
--

LOCK TABLES `aoo_region_alias` WRITE;
/*!40000 ALTER TABLE `aoo_region_alias` DISABLE KEYS */;
INSERT INTO `aoo_region_alias` VALUES ('bootstrap-catalog','cd','CN-51-01','VERIFIED',NULL,'2026-09-26 12:28:18.803'),('bootstrap-catalog','sc','CN-51','VERIFIED',NULL,'2026-09-26 12:28:18.803'),('bootstrap-catalog','yongzhou','CN-43-11','VERIFIED',NULL,'2026-09-26 12:28:18.803'),('canonical-adcode','511000','CN-51-10','VERIFIED',NULL,'2026-09-26 12:28:19.585'),('canonical-adcode','513400','CN-51-34','VERIFIED',NULL,'2026-09-26 12:28:19.749'),('legacy-city-id','1041000','CN-51-10','VERIFIED',NULL,'2026-09-26 12:28:19.585'),('legacy-gamelist','all','GLOBAL','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','anhui','CN-34','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','chongqing','CN-50','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','fujian','CN-35','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','fujiang','CN-35','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','gansu','CN-62','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','guangdong','CN-44','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','guangxi','CN-45','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','guizhou','CN-52','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','haerbin','CN-23-01','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','hainan','CN-46','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','hebei','CN-13','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','heilongjiang','CN-23','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','henan','CN-41','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','henna','CN-41','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','hubei','CN-42','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','hunan','CN-43','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','jiangsu','CN-32','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','jiangxi','CN-36','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','jilin','CN-22','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','liaoning','CN-21','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','neimenggu','CN-15','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','ningxia','CN-64','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','riben','JP','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','shandong','CN-37','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','shanghai','CN-31','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','shanxi','CN-14','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','shanxisheng','CN-61','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','sichaun','CN-51','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','sichuan','CN-51','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','taiwan','CN-71','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','tianjin','CN-12','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','xinjiang','CN-65','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','xizang','CN-54','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','yindu','IN','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','yunnan','CN-53','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','zhejiang','CN-33','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('legacy-gamelist','zichuan','CN-37-03-02','VERIFIED',NULL,'2026-09-26 12:28:16.825'),('xqp-area','9','CN-51-34','VERIFIED',NULL,'2026-09-26 12:28:19.749');
/*!40000 ALTER TABLE `aoo_region_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_region_identity_legacy_snapshot`
--

DROP TABLE IF EXISTS `aoo_region_identity_legacy_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_region_identity_legacy_snapshot` (
  `entity_type` varchar(32) NOT NULL,
  `entity_id` bigint NOT NULL,
  `legacy_value` varchar(500) NOT NULL,
  `captured_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `quarantine_owner` varchar(64) NOT NULL DEFAULT 'data-governance',
  `delete_after` date NOT NULL DEFAULT '2027-08-25',
  PRIMARY KEY (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_region_identity_legacy_snapshot`
--

LOCK TABLES `aoo_region_identity_legacy_snapshot` WRITE;
/*!40000 ALTER TABLE `aoo_region_identity_legacy_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_region_identity_legacy_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_region_semantics_policy`
--

DROP TABLE IF EXISTS `aoo_region_semantics_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_region_semantics_policy` (
  `policy_key` varchar(64) NOT NULL,
  `policy_value` varchar(255) NOT NULL,
  `updated_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`policy_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_region_semantics_policy`
--

LOCK TABLES `aoo_region_semantics_policy` WRITE;
/*!40000 ALTER TABLE `aoo_region_semantics_policy` DISABLE KEYS */;
INSERT INTO `aoo_region_semantics_policy` VALUES ('CLASSIFICATION_REGION_AUDIT_ONLY','TRUE','2026-09-26 12:28:19.341'),('CLUB_PARTITION','FORBIDDEN','2026-09-26 12:28:19.015'),('HISTORY_PARTITION','FORBIDDEN','2026-09-26 12:28:19.015'),('LEGACY_CITY_GIFT_RUNTIME','FORBIDDEN','2026-09-26 12:28:19.326'),('LEGACY_CITY_ID_COLUMN_RUNTIME','FORBIDDEN','2026-09-26 12:28:19.341'),('LEGACY_IDENTITY_SNAPSHOT_DELETE_AFTER','2027-08-25','2026-09-26 12:28:19.326'),('LEGACY_IDENTITY_SNAPSHOT_OWNER','data-governance','2026-09-26 12:28:19.326'),('LEGACY_ROOM_COST_REGION_CONFIG_DELETE_AFTER','2027-08-25','2026-09-26 12:28:19.326'),('LEGACY_ROOM_COST_REGION_CONFIG_OWNER','data-governance','2026-09-26 12:28:19.326'),('LEGACY_ROOM_COST_REGION_CONFIG_RUNTIME','FORBIDDEN','2026-09-26 12:28:19.326'),('PLAYER_ASSET_PARTITION','FORBIDDEN','2026-09-26 12:28:19.015'),('PLAYER_PROFILE_REGION_DELETE_AFTER','2027-08-25','2026-09-26 12:28:19.416'),('PLAYER_PROFILE_REGION_QUARANTINE_OWNER','data-governance','2026-09-26 12:28:19.416'),('PLAYER_PROFILE_REGION_RUNTIME','FORBIDDEN','2026-09-26 12:28:19.416'),('ROOM_ROUTE_PARTITION','FORBIDDEN','2026-09-26 12:28:19.015'),('SEMANTICS','GAMEPLAY_CLASSIFICATION_ONLY','2026-09-26 12:28:19.015');
/*!40000 ALTER TABLE `aoo_region_semantics_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_relationship_contract`
--

DROP TABLE IF EXISTS `aoo_relationship_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_relationship_contract` (
  `relationship_code` varchar(128) NOT NULL,
  `child_table` varchar(64) NOT NULL,
  `child_columns` varchar(512) NOT NULL,
  `parent_table` varchar(64) NOT NULL,
  `parent_columns` varchar(512) NOT NULL,
  `enforcement_type` varchar(16) NOT NULL,
  `delete_action` varchar(16) NOT NULL,
  `orphan_detector_sql` text NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`relationship_code`),
  KEY `idx_relationship_child` (`child_table`,`status`,`relationship_code`),
  KEY `idx_relationship_parent` (`parent_table`,`status`,`relationship_code`),
  KEY `fk_relationship_owner` (`owner_code`),
  CONSTRAINT `fk_relationship_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_relationship_delete` CHECK ((`delete_action` in (_utf8mb4'RESTRICT',_utf8mb4'CASCADE',_utf8mb4'SET_NULL',_utf8mb4'ARCHIVE',_utf8mb4'ANONYMIZE'))),
  CONSTRAINT `chk_relationship_enforcement` CHECK ((`enforcement_type` in (_utf8mb4'FOREIGN_KEY',_utf8mb4'LOGICAL_GATE'))),
  CONSTRAINT `chk_relationship_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_relationship_contract`
--

LOCK TABLES `aoo_relationship_contract` WRITE;
/*!40000 ALTER TABLE `aoo_relationship_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_relationship_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_replica_failover_drill`
--

DROP TABLE IF EXISTS `aoo_replica_failover_drill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_replica_failover_drill` (
  `drill_id` bigint unsigned NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `old_primary_server_uuid` char(36) NOT NULL,
  `new_primary_server_uuid` char(36) NOT NULL,
  `expected_gtid_set` text NOT NULL,
  `promoted_gtid_set` text NOT NULL,
  `read_only_guard_verified` tinyint unsigned NOT NULL,
  `connection_reroute_verified` tinyint unsigned NOT NULL,
  `identity_generation_verified` tinyint unsigned NOT NULL,
  `writes_fenced_verified` tinyint unsigned NOT NULL,
  `data_loss_rows` bigint unsigned NOT NULL,
  `unavailable_ms` bigint unsigned NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) NOT NULL,
  `passed` tinyint unsigned NOT NULL,
  `evidence_uri` varchar(512) NOT NULL,
  PRIMARY KEY (`drill_id`),
  KEY `idx_replica_failover_result` (`passed`,`completed_at`,`drill_id`),
  CONSTRAINT `chk_failover_distinct` CHECK ((`old_primary_server_uuid` <> `new_primary_server_uuid`)),
  CONSTRAINT `chk_failover_flags` CHECK (((`read_only_guard_verified` in (0,1)) and (`connection_reroute_verified` in (0,1)) and (`identity_generation_verified` in (0,1)) and (`writes_fenced_verified` in (0,1)) and (`passed` in (0,1)))),
  CONSTRAINT `chk_failover_time` CHECK ((`completed_at` >= `started_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_replica_failover_drill`
--

LOCK TABLES `aoo_replica_failover_drill` WRITE;
/*!40000 ALTER TABLE `aoo_replica_failover_drill` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_replica_failover_drill` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_failover_drill_score_insert` BEFORE INSERT ON `aoo_replica_failover_drill` FOR EACH ROW BEGIN
    SET NEW.passed=(
        NEW.completed_at>=NEW.started_at
        AND NEW.expected_gtid_set=NEW.promoted_gtid_set
        AND NEW.read_only_guard_verified=1
        AND NEW.connection_reroute_verified=1
        AND NEW.identity_generation_verified=1
        AND NEW.writes_fenced_verified=1
        AND NEW.data_loss_rows=0
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_replica_read_policy`
--

DROP TABLE IF EXISTS `aoo_replica_read_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_replica_read_policy` (
  `domain_code` varchar(64) NOT NULL,
  `operation_code` varchar(128) NOT NULL,
  `consistency_level` varchar(24) NOT NULL,
  `read_your_write_seconds` int unsigned NOT NULL,
  `maximum_replica_lag_ms` bigint unsigned NOT NULL,
  `fallback_to_primary` tinyint unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`domain_code`,`operation_code`),
  CONSTRAINT `chk_replica_consistency` CHECK ((`consistency_level` in (_utf8mb4'PRIMARY_ONLY',_utf8mb4'READ_YOUR_WRITE',_utf8mb4'BOUNDED_STALENESS',_utf8mb4'EVENTUAL'))),
  CONSTRAINT `chk_replica_fallback` CHECK ((`fallback_to_primary` in (0,1))),
  CONSTRAINT `chk_replica_policy_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_replica_read_policy`
--

LOCK TABLES `aoo_replica_read_policy` WRITE;
/*!40000 ALTER TABLE `aoo_replica_read_policy` DISABLE KEYS */;
INSERT INTO `aoo_replica_read_policy` VALUES ('GAME_RUNTIME','CREATE_OR_RECOVER_ROOM','PRIMARY_ONLY',300,0,1,'ACTIVE'),('HISTORY','LIST_SETTLEMENTS','BOUNDED_STALENESS',0,3000,1,'ACTIVE'),('PLAYER_ASSET','BALANCE_AND_LEDGER','PRIMARY_ONLY',300,0,1,'ACTIVE'),('ROOM_TEMPLATE','CREATE_OR_UPDATE_TEMPLATE','PRIMARY_ONLY',60,0,1,'ACTIVE'),('ROOM_TEMPLATE','READ_AFTER_UPDATE','READ_YOUR_WRITE',60,1000,1,'ACTIVE');
/*!40000 ALTER TABLE `aoo_replica_read_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_resource_manifest`
--

DROP TABLE IF EXISTS `aoo_resource_manifest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_resource_manifest` (
  `id` bigint NOT NULL,
  `release_id` bigint NOT NULL,
  `version` varchar(32) NOT NULL,
  `content_sha256` char(64) NOT NULL,
  `signature_algorithm` varchar(32) NOT NULL,
  `key_id` varchar(128) NOT NULL,
  `signature` text NOT NULL,
  `state` varchar(24) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_manifest_release` (`release_id`),
  CONSTRAINT `fk_manifest_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_client_release` (`id`),
  CONSTRAINT `ck_manifest_hash` CHECK (regexp_like(`content_sha256`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `ck_manifest_state` CHECK ((`state` in (_utf8mb4'DRAFT',_utf8mb4'PUBLISHED',_utf8mb4'REVOKED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_resource_manifest`
--

LOCK TABLES `aoo_resource_manifest` WRITE;
/*!40000 ALTER TABLE `aoo_resource_manifest` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_resource_manifest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_resource_manifest_entry`
--

DROP TABLE IF EXISTS `aoo_resource_manifest_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_resource_manifest_entry` (
  `manifest_id` bigint NOT NULL,
  `asset_path` varchar(760) NOT NULL,
  `size_bytes` bigint NOT NULL,
  `sha256` char(64) NOT NULL,
  PRIMARY KEY (`manifest_id`,`asset_path`),
  CONSTRAINT `fk_manifest_entry` FOREIGN KEY (`manifest_id`) REFERENCES `aoo_resource_manifest` (`id`),
  CONSTRAINT `ck_asset_hash` CHECK (regexp_like(`sha256`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `ck_asset_size` CHECK ((`size_bytes` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_resource_manifest_entry`
--

LOCK TABLES `aoo_resource_manifest_entry` WRITE;
/*!40000 ALTER TABLE `aoo_resource_manifest_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_resource_manifest_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_restore_drill`
--

DROP TABLE IF EXISTS `aoo_restore_drill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_restore_drill` (
  `drill_id` bigint unsigned NOT NULL,
  `backup_id` bigint unsigned NOT NULL,
  `target_environment` varchar(64) NOT NULL,
  `restore_point` datetime(3) NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) NOT NULL,
  `rto_seconds` bigint unsigned NOT NULL,
  `rpo_seconds` bigint unsigned NOT NULL,
  `table_count_expected` int unsigned NOT NULL,
  `table_count_actual` int unsigned NOT NULL,
  `asset_hash_expected` char(64) NOT NULL,
  `asset_hash_actual` char(64) NOT NULL,
  `room_history_hash_expected` char(64) NOT NULL,
  `room_history_hash_actual` char(64) NOT NULL,
  `relationship_mismatch_count` bigint unsigned NOT NULL,
  `passed` tinyint unsigned NOT NULL,
  `evidence_uri` varchar(512) NOT NULL,
  PRIMARY KEY (`drill_id`),
  KEY `idx_restore_drill_result` (`passed`,`completed_at`,`drill_id`),
  KEY `fk_restore_drill_backup` (`backup_id`),
  CONSTRAINT `fk_restore_drill_backup` FOREIGN KEY (`backup_id`) REFERENCES `aoo_backup_manifest` (`backup_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_restore_drill_hashes` CHECK ((regexp_like(`asset_hash_expected`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`asset_hash_actual`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`room_history_hash_expected`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`room_history_hash_actual`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_restore_drill_passed` CHECK ((`passed` in (0,1))),
  CONSTRAINT `chk_restore_drill_time` CHECK ((`completed_at` >= `started_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_restore_drill`
--

LOCK TABLES `aoo_restore_drill` WRITE;
/*!40000 ALTER TABLE `aoo_restore_drill` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_restore_drill` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_restore_drill_score_insert` BEFORE INSERT ON `aoo_restore_drill` FOR EACH ROW BEGIN
    SET NEW.passed=(
        NEW.completed_at>=NEW.started_at
        AND NEW.table_count_expected=NEW.table_count_actual
        AND NEW.asset_hash_expected=NEW.asset_hash_actual
        AND NEW.room_history_hash_expected=NEW.room_history_hash_actual
        AND NEW.relationship_mismatch_count=0
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_room_authority_route`
--

DROP TABLE IF EXISTS `aoo_room_authority_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_authority_route` (
  `room_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `node_id` varchar(128) NOT NULL,
  `authority_endpoint` varchar(512) NOT NULL,
  `fencing_token` bigint unsigned NOT NULL,
  `lifecycle_state` varchar(24) NOT NULL,
  `last_request_id` varchar(128) NOT NULL,
  `trace_id` varchar(64) NOT NULL,
  `lease_expires_at` datetime(3) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `first_round_started_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `uk_authority_create_request` (`last_request_id`),
  KEY `idx_authority_node_state` (`node_id`,`lifecycle_state`,`lease_expires_at`),
  KEY `idx_room_authority_waiting_expiry` (`lifecycle_state`,`first_round_started_at`,`created_at`,`room_id`),
  CONSTRAINT `chk_authority_fencing` CHECK ((`fencing_token` > 0)),
  CONSTRAINT `chk_authority_state` CHECK ((`lifecycle_state` in (_utf8mb4'CREATING',_utf8mb4'ACTIVE',_utf8mb4'RECOVERING',_utf8mb4'REMOVING',_utf8mb4'REMOVED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_authority_route`
--

LOCK TABLES `aoo_room_authority_route` WRITE;
/*!40000 ALTER TABLE `aoo_room_authority_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_authority_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_billing_reservation`
--

DROP TABLE IF EXISTS `aoo_room_billing_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_billing_reservation` (
  `request_id` varchar(128) NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `currency_code` varchar(32) NOT NULL,
  `amount` bigint unsigned NOT NULL,
  `state` varchar(16) NOT NULL,
  `failure_code` varchar(64) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `uk_room_billing_room` (`room_id`),
  KEY `idx_room_billing_account` (`account_id`,`state`,`updated_at`),
  CONSTRAINT `chk_room_billing_state` CHECK ((`state` in (_utf8mb4'RESERVED',_utf8mb4'CONFIRMED',_utf8mb4'RELEASED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_billing_reservation`
--

LOCK TABLES `aoo_room_billing_reservation` WRITE;
/*!40000 ALTER TABLE `aoo_room_billing_reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_billing_reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_cost_policy`
--

DROP TABLE IF EXISTS `aoo_room_cost_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_cost_policy` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `round_count` int unsigned NOT NULL,
  `player_count` smallint unsigned NOT NULL,
  `payer_mode` varchar(16) NOT NULL,
  `currency_code` varchar(32) NOT NULL,
  `cost_minor` bigint unsigned NOT NULL,
  `club_cost_minor` bigint unsigned DEFAULT NULL,
  `union_cost_minor` bigint unsigned DEFAULT NULL,
  `policy_version` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`game_id`,`play_version`,`region_code`,`round_count`,`player_count`,`payer_mode`),
  KEY `idx_room_cost_lookup` (`region_code`,`game_id`,`play_version`,`player_count`,`round_count`,`status`),
  KEY `fk_room_cost_currency` (`currency_code`),
  CONSTRAINT `fk_room_cost_currency` FOREIGN KEY (`currency_code`) REFERENCES `aoo_currency_catalog` (`currency_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_room_cost_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_room_cost_region` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_cost_counts` CHECK (((`round_count` > 0) and (`player_count` > 0))),
  CONSTRAINT `chk_room_cost_currency` CHECK (regexp_like(`currency_code`,_utf8mb4'^[A-Z][A-Z0-9_]{0,31}$')),
  CONSTRAINT `chk_room_cost_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_room_cost_payer` CHECK ((`payer_mode` in (_utf8mb4'OWNER',_utf8mb4'AA',_utf8mb4'WINNER',_utf8mb4'CLUB',_utf8mb4'UNION'))),
  CONSTRAINT `chk_room_cost_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_cost_policy`
--

LOCK TABLES `aoo_room_cost_policy` WRITE;
/*!40000 ALTER TABLE `aoo_room_cost_policy` DISABLE KEYS */;
INSERT INTO `aoo_room_cost_policy` VALUES (8,'1.0.0','CN-51-01',8,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'6ea816c3836566a3a8317e0dbe4e59cd654508f01804290af6253927621d70d1','ACTIVE'),(8,'1.0.0','CN-51-01',8,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'6d92b70ba8c6131250dd48d16d8bb3c5b7a61558a4e05a2aabb48737401d482c','ACTIVE'),(8,'1.0.0','CN-51-01',8,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'faa761941eceaf450148d497d2fab73829e924c653bab42ca4f1daca3f936ea0','ACTIVE'),(8,'1.0.0','CN-51-01',10,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'44ff8fb783d91a97183ca48d299b5c3f1e08e627857b7b43166a3cfc4c5525f0','ACTIVE'),(8,'1.0.0','CN-51-01',10,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'5a4ee28eede6497d5788bca229a729d7eb383fdf873df7ae3ddfd85afe640149','ACTIVE'),(8,'1.0.0','CN-51-01',10,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'de83eb2f50676c0efd57b12933996caa6f3fe11c6b8a329d700e98e2d4a7a80d','ACTIVE'),(8,'1.0.0','CN-51-01',12,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'5ef9045e6de1ea19c455d6ec2d557a2811c9a0679740321c305c6a7460b43e15','ACTIVE'),(8,'1.0.0','CN-51-01',12,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'0ad5e487db07c2b262a7b5d40b981b11c7917c2793be8f15385aef4a94189c28','ACTIVE'),(8,'1.0.0','CN-51-01',12,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'1e9440bad6bcb1d091861d84da93548ecf057035d30a41753ecb8d45856a7348','ACTIVE'),(8,'1.0.0','CN-51-01',16,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'a710e1e1e7480f278ee4953cb7e96cbb6b1e39b73014fc17d7ac17af7aa07a51','ACTIVE'),(8,'1.0.0','CN-51-01',16,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'33108d3053250e76e85f40ed4975be9e1edf90317939ddc21c9c80156d6acd89','ACTIVE'),(8,'1.0.0','CN-51-01',16,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'8cdf162ac942977c72cd658b8545b331f7e0452734aaf10f2e544a5c8c18cd07','ACTIVE'),(629,'legacy-equivalent-1','CN-51',8,4,'OWNER','ROOM_CARD',0,NULL,NULL,2,'25a0f00e60014c94e29d4c903f32180a03bda4f86f8ed693f974966b8c6926c6','RETIRED'),(629,'legacy-equivalent-1','CN-51',10,4,'OWNER','ROOM_CARD',0,NULL,NULL,2,'cb7cb93026d6e51001dcaaf13cc3464ce3debe1fe2c34d0f65f4384dfcd24feb','RETIRED'),(629,'legacy-equivalent-1','CN-51',16,4,'OWNER','ROOM_CARD',0,NULL,NULL,2,'c72e8db72079b306c0a6980b8f1754ccf7ed0cc8ec48f9bd24f4564978f822f2','RETIRED'),(629,'legacy-equivalent-1','CN-51-10',8,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'5897844606952fa10d15821a5f5b4101ed0ef32f02deff2b37f86045298f274f','ACTIVE'),(629,'legacy-equivalent-1','CN-51-10',12,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'cfe4647b6b9593b6dda8f6e8701adc76c1e59dea733c8a1c221f899292e98e1d','ACTIVE'),(629,'legacy-equivalent-1','CN-51-10',12,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'356bb09486f7898ec4514ce74680fdb863813df298b1a6d37fa375cfe74bb169','ACTIVE'),(629,'legacy-equivalent-1','CN-51-10',12,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'e090bdb1d026a4eecfed8da7a7b6d20b0523eb721bcb933493ea76fb3d9e28d1','ACTIVE'),(629,'legacy-equivalent-1','CN-51-10',16,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'cc3690fa6d55178924234e275abd8538e1b6b9ea3c715b0091759713bed0d0a9','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',8,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'02ed04a5698ca96ed6dd28beee48a971bdacbc56d2bfb541c770b38378dcb30f','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',8,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'30911d9b0151ff98eb5e832d6a81867b97e27f2434029a9a9ef25b04d08a1573','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',8,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'45dafb71b1ef9d94c9b30fde5500bd9c0987423869eb2432f97b36ef3a752f07','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',12,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'335f994f82c08a0fc45ee09d825c27b806b02de61d620b067758954abbada438','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',12,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'e8942ab1c597268d84ade49629813195f8401fd9f231e5637d4e9eb24a272769','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',12,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'047daa47dd7997234a5613f6e866231b490b848760c9d729b89fe584d2207f30','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',16,2,'OWNER','ROOM_CARD',0,NULL,NULL,1,'5424e55ee63b5d7122afd472f368dd8d2410373750601b054e2a1901f29cc924','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',16,3,'OWNER','ROOM_CARD',0,NULL,NULL,1,'7e348f497257947212e599db4545c8213e35b2e2e9fdbaf5231ad2d3b1924451','ACTIVE'),(90005,'xqp-equivalent-1','CN-51-34',16,4,'OWNER','ROOM_CARD',0,NULL,NULL,1,'5a4358e42499422fc2cbd3545a0a429374a4f0d68542844fb34827ba2143194f','ACTIVE');
/*!40000 ALTER TABLE `aoo_room_cost_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_create_saga`
--

DROP TABLE IF EXISTS `aoo_room_create_saga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_create_saga` (
  `request_id` varchar(128) NOT NULL,
  `request_hash` varchar(128) NOT NULL,
  `request_json` json DEFAULT NULL,
  `account_id` bigint unsigned NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `state_version` bigint unsigned NOT NULL,
  `step` varchar(32) NOT NULL,
  `compensation_origin_step` varchar(32) DEFAULT NULL,
  `response_json` json DEFAULT NULL,
  `failure_code` varchar(128) DEFAULT NULL,
  `attempt_count` int unsigned NOT NULL DEFAULT '0',
  `next_retry_at` datetime(3) DEFAULT NULL,
  `trace_id` varchar(64) NOT NULL DEFAULT 'migration',
  `processing_token` varchar(64) DEFAULT NULL,
  `processing_until` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `uk_room_create_saga_room` (`room_id`),
  KEY `idx_room_saga_recovery` (`step`,`next_retry_at`,`updated_at`),
  KEY `idx_room_saga_processing` (`processing_until`,`step`,`updated_at`),
  KEY `idx_room_saga_compensation` (`compensation_origin_step`,`step`,`next_retry_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_create_saga`
--

LOCK TABLES `aoo_room_create_saga` WRITE;
/*!40000 ALTER TABLE `aoo_room_create_saga` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_create_saga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_event`
--

DROP TABLE IF EXISTS `aoo_room_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_event` (
  `room_id` bigint unsigned NOT NULL,
  `round_no` int NOT NULL,
  `event_sequence` bigint NOT NULL,
  `business_event_id` varchar(128) NOT NULL,
  `event_type` varchar(128) NOT NULL,
  `schema_version` int NOT NULL DEFAULT '1',
  `is_compensation` tinyint(1) NOT NULL DEFAULT '0',
  `compensates_business_event_id` varchar(128) DEFAULT NULL,
  `compensation_reason` varchar(500) DEFAULT NULL,
  `event_payload` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `visibility` varchar(24) NOT NULL DEFAULT 'LEGACY_RESTRICTED',
  `owner_player_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`room_id`,`event_sequence`,`visibility`,`owner_player_id`),
  UNIQUE KEY `uq_room_round_business_view` (`room_id`,`round_no`,`business_event_id`,`visibility`,`owner_player_id`),
  KEY `idx_room_event_created` (`created_at`),
  KEY `idx_room_event_player_view` (`room_id`,`event_sequence`,`visibility`,`owner_player_id`),
  KEY `idx_room_round_type_sequence` (`room_id`,`round_no`,`event_type`,`event_sequence`),
  KEY `idx_room_event_compensation` (`room_id`,`compensates_business_event_id`),
  KEY `idx_room_event_view_sequence` (`room_id`,`visibility`,`owner_player_id`,`event_sequence`),
  CONSTRAINT `chk_room_event_compensation` CHECK ((((`is_compensation` = false) and (`compensates_business_event_id` is null) and (`compensation_reason` is null)) or ((`is_compensation` = true) and (`compensates_business_event_id` is not null) and (`compensation_reason` is not null)))),
  CONSTRAINT `chk_room_event_identity` CHECK (((`room_id` > 0) and (`round_no` >= 0) and (`event_sequence` >= 0))),
  CONSTRAINT `chk_room_event_visibility` CHECK ((((`visibility` in (_utf8mb4'PUBLIC',_utf8mb4'LEGACY_RESTRICTED')) and (`owner_player_id` = 0)) or ((`visibility` = _utf8mb4'PLAYER_PRIVATE') and (`owner_player_id` > 0))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_event`
--

LOCK TABLES `aoo_room_event` WRITE;
/*!40000 ALTER TABLE `aoo_room_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_event` ENABLE KEYS */;
UNLOCK TABLES;
ALTER DATABASE `aoo_login_fresh_verify` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_aoo_room_event_no_update` BEFORE UPDATE ON `aoo_room_event` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='aoo_room_event is append-only; write a compensation event';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `aoo_login_fresh_verify` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_aoo_room_event_no_delete` BEFORE DELETE ON `aoo_room_event` FOR EACH ROW BEGIN
    IF COALESCE(@aoo_authorized_room_cleanup,0) <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='aoo_room_event is append-only; retention must archive, not delete';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_room_history_cleanup_count`
--

DROP TABLE IF EXISTS `aoo_room_history_cleanup_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_history_cleanup_count` (
  `run_id` varchar(64) NOT NULL,
  `phase` varchar(8) NOT NULL,
  `table_name` varchar(128) NOT NULL,
  `row_filter` varchar(500) NOT NULL,
  `row_count` bigint unsigned NOT NULL,
  `recorded_at` datetime(3) NOT NULL,
  PRIMARY KEY (`run_id`,`phase`,`table_name`),
  CONSTRAINT `fk_room_cleanup_count_run` FOREIGN KEY (`run_id`) REFERENCES `aoo_room_history_cleanup_run` (`run_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_cleanup_count_phase` CHECK ((`phase` in (_utf8mb4'BEFORE',_utf8mb4'AFTER')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_history_cleanup_count`
--

LOCK TABLES `aoo_room_history_cleanup_count` WRITE;
/*!40000 ALTER TABLE `aoo_room_history_cleanup_count` DISABLE KEYS */;
INSERT INTO `aoo_room_history_cleanup_count` VALUES ('20260907-pdk-code-reset-v1','AFTER','aoo_appeal','detach room_id only',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_business_idempotency','room_id>0',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_club_room_projection','all rows; club body/member preserved',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_connection_generation','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_consumed_event','event belongs to room outbox',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_dead_letter_replay_audit','event belongs to room outbox',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_game_share','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_hall_game_ticket','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_hall_idempotency','all room operations',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_hall_room','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_hall_room_member','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_match','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_match_member','members of all room matches',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_outbox','LOWER(aggregate_type)=room',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_player_risk_observation','room_id IS NOT NULL',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_authority_route','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_billing_reservation','all rows; billing ledger preserved',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_create_saga','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_event','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_idempotent_allocation','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_lease','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_rule_lock','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_room_snapshot','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_settlement','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_settlement_outbox','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_settlement_score','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','aoo_spectator_admission','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','perspective_replay_event','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','perspective_replay_event_archive','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','replay_participant','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','replay_participant_archive','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','replay_set_manifest','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','replay_short_code','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','replay_short_code_access','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','risk_admission_decision','room_id IS NOT NULL',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','risk_event','room_id or room telemetry source',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','risk_review_directive','directives for room-derived risk events',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','room_safety_location','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','room_safety_mute','all rows',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','room_safety_report','room_id IS NOT NULL',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','social_presence','detach room_id only',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','AFTER','telemetry_signal','room_id IS NOT NULL',0,'2026-09-26 12:28:19.859'),('20260907-pdk-code-reset-v1','BEFORE','aoo_appeal','detach room_id only',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_business_idempotency','room_id>0',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_club_room_projection','all rows; club body/member preserved',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_connection_generation','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_consumed_event','event belongs to room outbox',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_dead_letter_replay_audit','event belongs to room outbox',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_game_share','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_hall_game_ticket','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_hall_idempotency','all room operations',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_hall_room','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_hall_room_member','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_match','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_match_member','members of all room matches',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_outbox','LOWER(aggregate_type)=room',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_player_risk_observation','room_id IS NOT NULL',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_authority_route','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_billing_reservation','all rows; billing ledger preserved',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_create_saga','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_event','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_idempotent_allocation','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_lease','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_rule_lock','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_room_snapshot','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_settlement','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_settlement_outbox','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_settlement_score','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','aoo_spectator_admission','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','perspective_replay_event','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','perspective_replay_event_archive','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','replay_participant','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','replay_participant_archive','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','replay_set_manifest','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','replay_short_code','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','replay_short_code_access','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','risk_admission_decision','room_id IS NOT NULL',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','risk_event','room_id or room telemetry source',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','risk_review_directive','directives for room-derived risk events',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','room_safety_location','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','room_safety_mute','all rows',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','room_safety_report','room_id IS NOT NULL',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','social_presence','detach room_id only',0,'2026-09-26 12:28:19.826'),('20260907-pdk-code-reset-v1','BEFORE','telemetry_signal','room_id IS NOT NULL',0,'2026-09-26 12:28:19.826');
/*!40000 ALTER TABLE `aoo_room_history_cleanup_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_history_cleanup_run`
--

DROP TABLE IF EXISTS `aoo_room_history_cleanup_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_history_cleanup_run` (
  `run_id` varchar(64) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `status` varchar(16) NOT NULL,
  `account_rows_before` bigint unsigned NOT NULL,
  `ledger_rows_before` bigint unsigned NOT NULL,
  `club_rows_before` bigint unsigned NOT NULL,
  `club_member_rows_before` bigint unsigned NOT NULL,
  `account_rows_after` bigint unsigned DEFAULT NULL,
  `ledger_rows_after` bigint unsigned DEFAULT NULL,
  `club_rows_after` bigint unsigned DEFAULT NULL,
  `club_member_rows_after` bigint unsigned DEFAULT NULL,
  `started_at` datetime(3) NOT NULL,
  `completed_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`run_id`),
  CONSTRAINT `chk_room_cleanup_status` CHECK ((`status` in (_utf8mb4'RUNNING',_utf8mb4'SUCCEEDED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_history_cleanup_run`
--

LOCK TABLES `aoo_room_history_cleanup_run` WRITE;
/*!40000 ALTER TABLE `aoo_room_history_cleanup_run` DISABLE KEYS */;
INSERT INTO `aoo_room_history_cleanup_run` VALUES ('20260907-pdk-code-reset-v1','User-authorized full historical and active room cleanup before CD201/NJ201/LS201 activation','SUCCEEDED',0,0,0,0,0,0,0,0,'2026-09-26 12:28:19.825','2026-09-26 12:28:19.861');
/*!40000 ALTER TABLE `aoo_room_history_cleanup_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_id_sequence`
--

DROP TABLE IF EXISTS `aoo_room_id_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_id_sequence` (
  `room_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_id_sequence`
--

LOCK TABLES `aoo_room_id_sequence` WRITE;
/*!40000 ALTER TABLE `aoo_room_id_sequence` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_id_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_idempotent_allocation`
--

DROP TABLE IF EXISTS `aoo_room_idempotent_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_idempotent_allocation` (
  `request_id` varchar(128) NOT NULL,
  `account_id` bigint NOT NULL,
  `room_id` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `uk_room_idempotent_allocation_room` (`room_id`),
  KEY `idx_room_idempotent_allocation_account` (`account_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_idempotent_allocation`
--

LOCK TABLES `aoo_room_idempotent_allocation` WRITE;
/*!40000 ALTER TABLE `aoo_room_idempotent_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_idempotent_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_lease`
--

DROP TABLE IF EXISTS `aoo_room_lease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_lease` (
  `room_id` bigint unsigned NOT NULL,
  `owner_node` varchar(128) NOT NULL,
  `fencing_token` bigint NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `idx_room_lease_expiry` (`expires_at`),
  CONSTRAINT `chk_edge_room_lease_fence` CHECK ((`fencing_token` > 0)),
  CONSTRAINT `chk_lease_identity` CHECK (((`room_id` > 0) and (`fencing_token` > 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_lease`
--

LOCK TABLES `aoo_room_lease` WRITE;
/*!40000 ALTER TABLE `aoo_room_lease` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_lease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_rule_choice`
--

DROP TABLE IF EXISTS `aoo_room_rule_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_rule_choice` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `rule_key` varchar(96) NOT NULL,
  `choice_key` varchar(96) NOT NULL,
  `wire_value` json NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`game_id`,`play_version`,`rule_key`,`choice_key`),
  UNIQUE KEY `uk_room_rule_choice_ordinal` (`game_id`,`play_version`,`rule_key`,`ordinal`),
  CONSTRAINT `fk_room_rule_choice_rule` FOREIGN KEY (`game_id`, `play_version`, `rule_key`) REFERENCES `aoo_room_rule_definition` (`game_id`, `play_version`, `rule_key`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_rule_choice_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DEPRECATED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_rule_choice`
--

LOCK TABLES `aoo_room_rule_choice` WRITE;
/*!40000 ALTER TABLE `aoo_room_rule_choice` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_rule_choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_rule_definition`
--

DROP TABLE IF EXISTS `aoo_room_rule_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_rule_definition` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `rule_key` varchar(96) NOT NULL,
  `rule_kind` varchar(24) NOT NULL,
  `value_type` varchar(16) NOT NULL,
  `required_value` tinyint unsigned NOT NULL DEFAULT '0',
  `default_value` json DEFAULT NULL,
  `minimum_value` decimal(38,9) DEFAULT NULL,
  `maximum_value` decimal(38,9) DEFAULT NULL,
  `validation_pattern` varchar(512) DEFAULT NULL,
  `description` varchar(500) NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `schema_version` int unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`game_id`,`play_version`,`rule_key`),
  UNIQUE KEY `uk_room_rule_ordinal` (`game_id`,`play_version`,`ordinal`),
  KEY `idx_room_rule_kind` (`rule_kind`,`status`,`game_id`,`play_version`),
  CONSTRAINT `fk_room_rule_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_rule_hash` CHECK (regexp_like(`content_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_room_rule_key` CHECK (regexp_like(`rule_key`,_utf8mb4'^[a-z][a-zA-Z0-9_.-]{0,95}$')),
  CONSTRAINT `chk_room_rule_kind` CHECK ((`rule_kind` in (_utf8mb4'ROOM',_utf8mb4'DECK',_utf8mb4'HAND',_utf8mb4'FIRST_MOVE',_utf8mb4'ACTION',_utf8mb4'FLOW',_utf8mb4'SCORING',_utf8mb4'SETTLEMENT',_utf8mb4'REPLAY'))),
  CONSTRAINT `chk_room_rule_range` CHECK (((`maximum_value` is null) or (`minimum_value` is null) or (`maximum_value` >= `minimum_value`))),
  CONSTRAINT `chk_room_rule_required` CHECK ((`required_value` in (0,1))),
  CONSTRAINT `chk_room_rule_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DEPRECATED'))),
  CONSTRAINT `chk_room_rule_value_type` CHECK ((`value_type` in (_utf8mb4'BOOLEAN',_utf8mb4'INTEGER',_utf8mb4'DECIMAL',_utf8mb4'STRING',_utf8mb4'ENUM',_utf8mb4'LIST',_utf8mb4'OBJECT')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_rule_definition`
--

LOCK TABLES `aoo_room_rule_definition` WRITE;
/*!40000 ALTER TABLE `aoo_room_rule_definition` DISABLE KEYS */;
INSERT INTO `aoo_room_rule_definition` VALUES (90005,'xqp-equivalent-1','dealCardCount','DECK','INTEGER',1,'8',8.000000000,10.000000000,NULL,'每人8张使用7-A牌堆；10张使用5-A牌堆',40,1,'799fe568029ca7c5bc25e181a83f54895133620c64503f4879039b5f838431fa','ACTIVE'),(90005,'xqp-equivalent-1','jinHuaScore','SCORING','ENUM',1,'\"no_compare\"',NULL,NULL,NULL,'金花分值或不比较',50,1,'8d244fe7c390897db77e3864ac2547a13bce059f3481dfbedf71e5bcb3413104','ACTIVE'),(90005,'xqp-equivalent-1','operationTime','FLOW','INTEGER',1,'10',10.000000000,20.000000000,NULL,'操作超时秒数',30,1,'cd7eb42a90b642460e6b74f500f0cd939ed4c8443ed883a1c566ad5d8a276e1a','ACTIVE'),(90005,'xqp-equivalent-1','playerCount','ROOM','INTEGER',1,'2',2.000000000,4.000000000,NULL,'凉山跑得快人数',10,1,'5beee672ba2389a4781e016e259963cf5bee4088571f890d902626081045513e','ACTIVE'),(90005,'xqp-equivalent-1','playRule','HAND','LIST',0,'[\"compare_attachments\", \"triple_with_one\", \"four_ace_rank\", \"full_consecutive_pairs\"]',NULL,NULL,NULL,'凉山地区牌型开关',70,1,'ef77e6ba7184e157247a425a20056c1d48ea507df6ffbc46d2dfb0f699965009','ACTIVE'),(90005,'xqp-equivalent-1','robDealerRule','FLOW','ENUM',1,'\"dealer_first\"',NULL,NULL,NULL,'抢庄顺序与首局规则',60,1,'b98f74aaa032b5409f8d790457b3d77a7c15f3237a81cdcdebb72b5f5257d2e6','ACTIVE'),(90005,'xqp-equivalent-1','roomRestriction','ROOM','LIST',0,'[\"ip_limit\", \"timeout_auto_play\", \"distance_warning\", \"chat_muted\"]',NULL,NULL,NULL,'房间安全与互动开关',80,1,'1ac44f633ca9b74909471daa40d380263e652801bb8f14906735f5ccf394a6d2','ACTIVE'),(90005,'xqp-equivalent-1','roundCount','ROOM','INTEGER',1,'8',8.000000000,16.000000000,NULL,'凉山跑得快局数',20,1,'bb250cfccf2b25ce7f8d5a7652ee82579bbb4a8e325f1a092ab0f47af7ec5ead','ACTIVE');
/*!40000 ALTER TABLE `aoo_room_rule_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_rule_lock`
--

DROP TABLE IF EXISTS `aoo_room_rule_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_rule_lock` (
  `room_id` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `index_generation` bigint unsigned NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `component_chain` json NOT NULL,
  `immutable_rules` json NOT NULL,
  `bundle_hash` char(64) NOT NULL,
  `rule_hash` char(64) NOT NULL,
  `component_hash` char(64) NOT NULL,
  `card_codec_version` varchar(64) NOT NULL,
  `event_interpreter_version` varchar(64) NOT NULL,
  `protocol_version` varchar(64) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`room_id`),
  KEY `idx_room_rule_lock_release` (`release_id`,`room_id`),
  KEY `idx_room_rule_lock_history` (`game_id`,`play_version`,`created_at`,`room_id`),
  KEY `fk_room_rule_lock_index_release` (`game_id`,`region_code`,`play_version`,`index_generation`,`release_id`),
  CONSTRAINT `fk_room_rule_lock_index_release` FOREIGN KEY (`game_id`, `region_code`, `play_version`, `index_generation`, `release_id`) REFERENCES `aoo_compiled_room_create_index` (`game_id`, `region_code`, `play_version`, `index_generation`, `release_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_room_rule_lock_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_rule_lock_hashes` CHECK ((regexp_like(`bundle_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`rule_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`component_hash`,_utf8mb4'^[0-9a-f]{64}$')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_rule_lock`
--

LOCK TABLES `aoo_room_rule_lock` WRITE;
/*!40000 ALTER TABLE `aoo_room_rule_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_rule_lock` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_room_rule_lock_no_update` BEFORE UPDATE ON `aoo_room_rule_lock` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='room rule lock is immutable';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_room_rule_lock_no_delete` BEFORE DELETE ON `aoo_room_rule_lock` FOR EACH ROW BEGIN
    IF COALESCE(@aoo_authorized_room_cleanup,0) <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='room rule lock is retention controlled';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_room_snapshot`
--

DROP TABLE IF EXISTS `aoo_room_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_snapshot` (
  `room_id` bigint unsigned NOT NULL,
  `game_id` int NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `release_id` bigint unsigned DEFAULT NULL,
  `component_version` varchar(64) NOT NULL,
  `rule_content_hash` char(64) DEFAULT NULL,
  `component_content_hash` char(64) DEFAULT NULL,
  `card_codec_version` varchar(64) DEFAULT NULL,
  `event_interpreter_version` varchar(64) DEFAULT NULL,
  `protocol_version` varchar(64) DEFAULT NULL,
  `fencing_token` bigint NOT NULL,
  `state_version` bigint NOT NULL DEFAULT '0',
  `last_event_sequence` bigint NOT NULL,
  `captured_at` datetime(3) NOT NULL,
  `state_payload` json NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `idx_room_snapshot_capture` (`captured_at`),
  KEY `idx_snapshot_state_event_version` (`room_id`,`state_version`,`last_event_sequence`),
  KEY `idx_snapshot_recoverable` (`captured_at`,`room_id`),
  KEY `idx_room_snapshot_release` (`release_id`,`room_id`),
  CONSTRAINT `fk_room_snapshot_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_snapshot_identity` CHECK (((`room_id` > 0) and (`fencing_token` > 0) and (`state_version` >= 0) and (`last_event_sequence` = `state_version`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_snapshot`
--

LOCK TABLES `aoo_room_snapshot` WRITE;
/*!40000 ALTER TABLE `aoo_room_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_template`
--

DROP TABLE IF EXISTS `aoo_room_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_template` (
  `club_id` bigint unsigned NOT NULL,
  `template_code` varchar(64) NOT NULL,
  `template_version` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `rule_payload` json NOT NULL,
  `status` varchar(16) NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `row_version` bigint unsigned NOT NULL DEFAULT '1',
  `active_display_name` varchar(64) GENERATED ALWAYS AS ((case when (`status` = _utf8mb4'ACTIVE') then `display_name` else NULL end)) STORED,
  PRIMARY KEY (`club_id`,`template_code`,`template_version`),
  UNIQUE KEY `uk_template_active_display_name` (`club_id`,`active_display_name`),
  KEY `idx_template_catalog` (`club_id`,`status`,`game_id`,`template_code`),
  KEY `idx_template_active_page` (`club_id`,`status`,`game_id`,`template_code`,`template_version`),
  KEY `fk_room_template_play_version` (`game_id`,`play_version`),
  CONSTRAINT `fk_room_template_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_room_template` CHECK (((`club_id` > 0) and (`game_id` > 0) and (`template_version` > 0) and (`created_by` > 0) and (`status` in (_utf8mb4'DRAFT',_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))),
  CONSTRAINT `chk_room_template_revision` CHECK ((`row_version` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_template`
--

LOCK TABLES `aoo_room_template` WRITE;
/*!40000 ALTER TABLE `aoo_room_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_room_template_release_lock`
--

DROP TABLE IF EXISTS `aoo_room_template_release_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_room_template_release_lock` (
  `club_id` bigint unsigned NOT NULL,
  `template_code` varchar(64) NOT NULL,
  `template_version` bigint unsigned NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `region_code` varchar(32) NOT NULL,
  `release_id` bigint unsigned NOT NULL,
  `rule_hash` char(64) NOT NULL,
  `locked_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`club_id`,`template_code`,`template_version`),
  KEY `idx_template_release_lock_release` (`release_id`,`club_id`,`template_code`),
  KEY `fk_template_release_lock_play_version` (`game_id`,`play_version`),
  KEY `fk_template_release_lock_region` (`region_code`),
  KEY `fk_template_release_lock_identity` (`release_id`,`game_id`,`play_version`),
  CONSTRAINT `fk_template_release_lock_identity` FOREIGN KEY (`release_id`, `game_id`, `play_version`) REFERENCES `aoo_game_release` (`release_id`, `game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_template_release_lock_play_version` FOREIGN KEY (`game_id`, `play_version`) REFERENCES `aoo_play_version` (`game_id`, `play_version`) ON DELETE RESTRICT,
  CONSTRAINT `fk_template_release_lock_region` FOREIGN KEY (`region_code`) REFERENCES `aoo_region` (`region_code`) ON DELETE RESTRICT,
  CONSTRAINT `fk_template_release_lock_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_template_release_lock_template` FOREIGN KEY (`club_id`, `template_code`, `template_version`) REFERENCES `aoo_room_template` (`club_id`, `template_code`, `template_version`) ON DELETE RESTRICT,
  CONSTRAINT `chk_template_release_lock_hash` CHECK (regexp_like(`rule_hash`,_utf8mb4'^[0-9a-f]{64}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_room_template_release_lock`
--

LOCK TABLES `aoo_room_template_release_lock` WRITE;
/*!40000 ALTER TABLE `aoo_room_template_release_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_room_template_release_lock` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_template_release_lock_no_update` BEFORE UPDATE ON `aoo_room_template_release_lock` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='template release lock is immutable; create a new template version';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `trg_template_release_lock_no_delete` BEFORE DELETE ON `aoo_room_template_release_lock` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='template release lock is history protected';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aoo_schema_change_plan`
--

DROP TABLE IF EXISTS `aoo_schema_change_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_schema_change_plan` (
  `change_id` bigint unsigned NOT NULL,
  `migration_version` varchar(64) NOT NULL,
  `affected_table` varchar(64) NOT NULL,
  `schema_phase` varchar(16) NOT NULL,
  `backward_compatible` tinyint unsigned NOT NULL,
  `online_ddl_algorithm` varchar(16) NOT NULL,
  `lock_mode` varchar(16) NOT NULL,
  `estimated_rows` bigint unsigned NOT NULL,
  `estimated_bytes` bigint unsigned NOT NULL,
  `maximum_lock_ms` bigint unsigned NOT NULL,
  `maximum_replica_lag_ms` bigint unsigned NOT NULL,
  `preflight_sql` text NOT NULL,
  `verification_sql` text NOT NULL,
  `rollback_sql` text,
  `status` varchar(24) NOT NULL DEFAULT 'PLANNED',
  `approved_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`change_id`),
  UNIQUE KEY `uk_schema_change_table_phase` (`migration_version`,`affected_table`,`schema_phase`),
  KEY `idx_schema_change_status` (`status`,`migration_version`,`affected_table`),
  CONSTRAINT `chk_schema_change_algorithm` CHECK ((`online_ddl_algorithm` in (_utf8mb4'INSTANT',_utf8mb4'INPLACE',_utf8mb4'COPY',_utf8mb4'EXTERNAL'))),
  CONSTRAINT `chk_schema_change_compatible` CHECK ((`backward_compatible` in (0,1))),
  CONSTRAINT `chk_schema_change_lock` CHECK ((`lock_mode` in (_utf8mb4'NONE',_utf8mb4'SHARED',_utf8mb4'EXCLUSIVE'))),
  CONSTRAINT `chk_schema_change_phase` CHECK ((`schema_phase` in (_utf8mb4'EXPAND',_utf8mb4'MIGRATE',_utf8mb4'CONTRACT'))),
  CONSTRAINT `chk_schema_change_status` CHECK ((`status` in (_utf8mb4'PLANNED',_utf8mb4'PREFLIGHT_PASSED',_utf8mb4'RUNNING',_utf8mb4'VERIFIED',_utf8mb4'ROLLED_BACK',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_schema_change_plan`
--

LOCK TABLES `aoo_schema_change_plan` WRITE;
/*!40000 ALTER TABLE `aoo_schema_change_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_schema_change_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_sequence`
--

DROP TABLE IF EXISTS `aoo_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_sequence` (
  `sequence_name` varchar(64) NOT NULL,
  `next_value` bigint NOT NULL,
  PRIMARY KEY (`sequence_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_sequence`
--

LOCK TABLES `aoo_sequence` WRITE;
/*!40000 ALTER TABLE `aoo_sequence` DISABLE KEYS */;
INSERT INTO `aoo_sequence` VALUES ('aoo_match_seq',100000),('aoo_room_seq',900000);
/*!40000 ALTER TABLE `aoo_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_server_directory`
--

DROP TABLE IF EXISTS `aoo_server_directory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_server_directory` (
  `id` bigint NOT NULL,
  `server_code` varchar(64) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `region` varchar(64) NOT NULL,
  `public_endpoint` varchar(1024) NOT NULL,
  `platform` varchar(32) NOT NULL DEFAULT '*',
  `channel` varchar(64) NOT NULL DEFAULT '*',
  `state` varchar(24) NOT NULL,
  `weight` int NOT NULL DEFAULT '100',
  `rollout_percent` smallint NOT NULL DEFAULT '100',
  `migrate_to_server_id` bigint DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `directory_revision` bigint NOT NULL,
  `visible_from` timestamp(3) NOT NULL,
  `visible_until` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_server_code` (`server_code`),
  KEY `fk_server_migration` (`migrate_to_server_id`),
  KEY `ix_directory_resolution` (`platform`,`channel`,`state`,`visible_from`,`visible_until`,`directory_revision`),
  CONSTRAINT `fk_server_migration` FOREIGN KEY (`migrate_to_server_id`) REFERENCES `aoo_server_directory` (`id`),
  CONSTRAINT `ck_server_rollout` CHECK ((`rollout_percent` between 0 and 100)),
  CONSTRAINT `ck_server_state` CHECK ((`state` in (_utf8mb4'ACTIVE',_utf8mb4'MAINTENANCE',_utf8mb4'MIGRATING',_utf8mb4'OFFLINE'))),
  CONSTRAINT `ck_server_window` CHECK (((`visible_until` is null) or (`visible_until` > `visible_from`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_server_directory`
--

LOCK TABLES `aoo_server_directory` WRITE;
/*!40000 ALTER TABLE `aoo_server_directory` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_server_directory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_session`
--

DROP TABLE IF EXISTS `aoo_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_session` (
  `session_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_version` bigint NOT NULL,
  `refresh_token_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issued_at` datetime(3) NOT NULL,
  `access_expires_at` datetime(3) NOT NULL,
  `refresh_expires_at` datetime(3) NOT NULL,
  `revoked_at` datetime(3) DEFAULT NULL,
  `revoke_reason` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `uk_session_user_version` (`user_id`,`session_version`),
  KEY `idx_session_user_active` (`user_id`,`revoked_at`,`refresh_expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_session`
--

LOCK TABLES `aoo_session` WRITE;
/*!40000 ALTER TABLE `aoo_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_settlement`
--

DROP TABLE IF EXISTS `aoo_settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_settlement` (
  `settlement_id` bigint unsigned NOT NULL,
  `business_id` varchar(128) NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `round_no` int NOT NULL,
  `settlement_version` varchar(64) NOT NULL,
  `result_payload` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`settlement_id`),
  UNIQUE KEY `uk_settlement_business` (`business_id`),
  KEY `idx_settlement_room_round` (`room_id`,`round_no`),
  CONSTRAINT `chk_settlement_identity` CHECK (((`settlement_id` > 0) and (`room_id` > 0) and (`round_no` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_settlement`
--

LOCK TABLES `aoo_settlement` WRITE;
/*!40000 ALTER TABLE `aoo_settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_settlement_outbox`
--

DROP TABLE IF EXISTS `aoo_settlement_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_settlement_outbox` (
  `business_id` varchar(128) NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `round_no` int unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `result_payload` json NOT NULL,
  `status` varchar(16) NOT NULL,
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `next_attempt_at` datetime(3) NOT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`business_id`),
  KEY `idx_settlement_outbox_retry` (`status`,`next_attempt_at`,`created_at`),
  CONSTRAINT `chk_settlement_outbox_status` CHECK ((`status` = _utf8mb4'PENDING'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_settlement_outbox`
--

LOCK TABLES `aoo_settlement_outbox` WRITE;
/*!40000 ALTER TABLE `aoo_settlement_outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_settlement_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_settlement_score`
--

DROP TABLE IF EXISTS `aoo_settlement_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_settlement_score` (
  `settlement_id` bigint unsigned NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `score_scale` tinyint unsigned NOT NULL DEFAULT '0',
  `score_delta` decimal(38,9) NOT NULL,
  `score_after` decimal(38,9) DEFAULT NULL,
  `multiplier` decimal(20,9) NOT NULL DEFAULT '1.000000000',
  `score_reason` varchar(64) NOT NULL,
  `calculation_hash` char(64) NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`settlement_id`,`player_id`),
  KEY `idx_settlement_score_player` (`player_id`,`created_at`,`settlement_id`),
  CONSTRAINT `fk_settlement_score_settlement` FOREIGN KEY (`settlement_id`) REFERENCES `aoo_settlement` (`settlement_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_settlement_score_hash` CHECK (regexp_like(`calculation_hash`,_utf8mb4'^[0-9a-f]{64}$')),
  CONSTRAINT `chk_settlement_score_multiplier` CHECK (((`multiplier` >= 0) and (`multiplier` <= 99999999999.999999999))),
  CONSTRAINT `chk_settlement_score_scale` CHECK ((`score_scale` <= 9))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_settlement_score`
--

LOCK TABLES `aoo_settlement_score` WRITE;
/*!40000 ALTER TABLE `aoo_settlement_score` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_settlement_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_shard_route_contract`
--

DROP TABLE IF EXISTS `aoo_shard_route_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_shard_route_contract` (
  `domain_code` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `route_key` varchar(64) NOT NULL,
  `route_algorithm` varchar(64) NOT NULL,
  `virtual_shard_count` int unsigned NOT NULL,
  `physical_shard_count` int unsigned NOT NULL,
  `cross_shard_query_policy` varchar(24) NOT NULL,
  `maximum_fanout` int unsigned NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`domain_code`,`table_name`),
  CONSTRAINT `chk_shard_counts` CHECK (((`virtual_shard_count` > 0) and (`physical_shard_count` > 0) and (`virtual_shard_count` >= `physical_shard_count`))),
  CONSTRAINT `chk_shard_fanout` CHECK (((`maximum_fanout` > 0) and (`maximum_fanout` <= `physical_shard_count`))),
  CONSTRAINT `chk_shard_policy` CHECK ((`cross_shard_query_policy` in (_utf8mb4'FORBIDDEN',_utf8mb4'ASYNC_AGGREGATE',_utf8mb4'BOUNDED_FANOUT'))),
  CONSTRAINT `chk_shard_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_shard_route_contract`
--

LOCK TABLES `aoo_shard_route_contract` WRITE;
/*!40000 ALTER TABLE `aoo_shard_route_contract` DISABLE KEYS */;
INSERT INTO `aoo_shard_route_contract` VALUES ('ASSET','aoo_currency_balance','player_id','MURMUR3_MOD',1024,64,'FORBIDDEN',1,'ACTIVE'),('ASSET','aoo_ledger','player_id','MURMUR3_MOD',1024,64,'BOUNDED_FANOUT',4,'ACTIVE'),('CLUB','aoo_club_member','club_id','MURMUR3_MOD',1024,64,'FORBIDDEN',1,'ACTIVE'),('CLUB','aoo_room_template','club_id','MURMUR3_MOD',1024,64,'FORBIDDEN',1,'ACTIVE'),('HISTORY','perspective_replay_event','room_id','SNOWFLAKE_ROUTE_BITS',1024,64,'FORBIDDEN',1,'ACTIVE'),('PLAYER','aoo_session','user_id','MURMUR3_MOD',1024,64,'FORBIDDEN',1,'ACTIVE'),('ROOM','aoo_room_event','room_id','SNOWFLAKE_ROUTE_BITS',1024,64,'FORBIDDEN',1,'ACTIVE'),('ROOM','aoo_room_snapshot','room_id','SNOWFLAKE_ROUTE_BITS',1024,64,'FORBIDDEN',1,'ACTIVE');
/*!40000 ALTER TABLE `aoo_shard_route_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_soft_delete_contract`
--

DROP TABLE IF EXISTS `aoo_soft_delete_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_soft_delete_contract` (
  `table_name` varchar(64) NOT NULL,
  `deleted_column` varchar(64) NOT NULL,
  `active_unique_key` varchar(256) NOT NULL,
  `restore_conflict_policy` varchar(24) NOT NULL,
  `history_query_policy` varchar(24) NOT NULL,
  `detector_sql` text NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`table_name`),
  CONSTRAINT `chk_soft_delete_history` CHECK ((`history_query_policy` in (_utf8mb4'EXCLUDE_DEFAULT',_utf8mb4'INCLUDE_EXPLICIT',_utf8mb4'ARCHIVE_ONLY'))),
  CONSTRAINT `chk_soft_delete_restore` CHECK ((`restore_conflict_policy` in (_utf8mb4'REJECT',_utf8mb4'RENAME',_utf8mb4'MERGE',_utf8mb4'MANUAL'))),
  CONSTRAINT `chk_soft_delete_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_soft_delete_contract`
--

LOCK TABLES `aoo_soft_delete_contract` WRITE;
/*!40000 ALTER TABLE `aoo_soft_delete_contract` DISABLE KEYS */;
INSERT INTO `aoo_soft_delete_contract` VALUES ('aoo_club_member','member_status','PRIMARY KEY(club_id,player_id)','MERGE','INCLUDE_EXPLICIT','SELECT club_id,player_id FROM aoo_club_member GROUP BY club_id,player_id HAVING COUNT(*)>1','ACTIVE'),('aoo_game_catalog','status','uk_game_catalog_code(game_code)','REJECT','INCLUDE_EXPLICIT','SELECT game_code FROM aoo_game_catalog GROUP BY game_code HAVING COUNT(*)>1','ACTIVE'),('aoo_room_template','status','uk_template_active_display_name(club_id,active_display_name)','REJECT','INCLUDE_EXPLICIT','SELECT club_id,display_name FROM aoo_room_template WHERE status=\'ACTIVE\' GROUP BY club_id,display_name HAVING COUNT(*)>1','ACTIVE');
/*!40000 ALTER TABLE `aoo_soft_delete_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_spectator_admission`
--

DROP TABLE IF EXISTS `aoo_spectator_admission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_spectator_admission` (
  `request_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `room_id` bigint unsigned NOT NULL,
  `spectator_id` bigint unsigned NOT NULL,
  `status` varchar(16) NOT NULL,
  `requested_at` datetime(3) NOT NULL,
  `authorized_by` bigint unsigned DEFAULT NULL,
  `authorized_at` datetime(3) DEFAULT NULL,
  `left_at` datetime(3) DEFAULT NULL,
  `row_version` bigint unsigned NOT NULL,
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `uk_spectator_one_open` (`room_id`,`spectator_id`,((case when (`status` in (_utf8mb4'PENDING',_utf8mb4'AUTHORIZED')) then 1 else NULL end))),
  KEY `idx_spectator_active` (`room_id`,`status`,`request_id`),
  KEY `idx_spectator_subject` (`spectator_id`,`status`,`room_id`),
  CONSTRAINT `fk_spectator_room` FOREIGN KEY (`room_id`) REFERENCES `aoo_hall_room` (`room_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_spectator_decision` CHECK ((((`status` = _utf8mb4'PENDING') and (`authorized_by` is null) and (`authorized_at` is null) and (`left_at` is null)) or ((`status` in (_utf8mb4'AUTHORIZED',_utf8mb4'REJECTED')) and (`authorized_by` is not null) and (`authorized_at` is not null) and (`left_at` is null)) or ((`status` = _utf8mb4'LEFT') and (`authorized_by` is not null) and (`authorized_at` is not null) and (`left_at` is not null)))),
  CONSTRAINT `chk_spectator_status` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'AUTHORIZED',_utf8mb4'REJECTED',_utf8mb4'LEFT')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_spectator_admission`
--

LOCK TABLES `aoo_spectator_admission` WRITE;
/*!40000 ALTER TABLE `aoo_spectator_admission` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_spectator_admission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_statistics_plan_baseline`
--

DROP TABLE IF EXISTS `aoo_statistics_plan_baseline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_statistics_plan_baseline` (
  `baseline_id` bigint unsigned NOT NULL,
  `query_code` varchar(128) NOT NULL,
  `environment_code` varchar(64) NOT NULL,
  `table_statistics_hash` char(64) NOT NULL,
  `plan_hash` char(64) NOT NULL,
  `parameter_bucket` varchar(128) NOT NULL,
  `selected_index` varchar(64) DEFAULT NULL,
  `examined_rows` bigint unsigned NOT NULL,
  `p95_ms` decimal(12,3) NOT NULL,
  `captured_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`baseline_id`),
  UNIQUE KEY `uk_statistics_plan_bucket` (`query_code`,`environment_code`,`parameter_bucket`,`captured_at`),
  KEY `idx_statistics_plan_expiry` (`status`,`expires_at`,`baseline_id`),
  CONSTRAINT `fk_statistics_plan_query` FOREIGN KEY (`query_code`) REFERENCES `aoo_query_baseline` (`query_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_statistics_plan_expiry` CHECK ((`expires_at` > `captured_at`)),
  CONSTRAINT `chk_statistics_plan_hashes` CHECK ((regexp_like(`table_statistics_hash`,_utf8mb4'^[0-9a-f]{64}$') and regexp_like(`plan_hash`,_utf8mb4'^[0-9a-f]{64}$'))),
  CONSTRAINT `chk_statistics_plan_status` CHECK ((`status` in (_utf8mb4'ACTIVE',_utf8mb4'DRIFTED',_utf8mb4'EXPIRED',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_statistics_plan_baseline`
--

LOCK TABLES `aoo_statistics_plan_baseline` WRITE;
/*!40000 ALTER TABLE `aoo_statistics_plan_baseline` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_statistics_plan_baseline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_store_offer`
--

DROP TABLE IF EXISTS `aoo_store_offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_store_offer` (
  `offer_code` varchar(64) NOT NULL,
  `item_code` varchar(64) NOT NULL,
  `item_quantity` bigint NOT NULL,
  `currency_code` varchar(32) NOT NULL,
  `price_minor` bigint NOT NULL,
  `active_from` timestamp(3) NOT NULL,
  `active_until` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`offer_code`),
  KEY `item_code` (`item_code`),
  CONSTRAINT `aoo_store_offer_ibfk_1` FOREIGN KEY (`item_code`) REFERENCES `aoo_item_catalog` (`item_code`),
  CONSTRAINT `aoo_store_offer_chk_1` CHECK ((`item_quantity` > 0)),
  CONSTRAINT `aoo_store_offer_chk_2` CHECK ((`price_minor` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_store_offer`
--

LOCK TABLES `aoo_store_offer` WRITE;
/*!40000 ALTER TABLE `aoo_store_offer` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_store_offer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_table_governance`
--

DROP TABLE IF EXISTS `aoo_table_governance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_table_governance` (
  `table_name` varchar(64) NOT NULL,
  `owner_code` varchar(64) NOT NULL,
  `data_classification` varchar(24) NOT NULL,
  `authoritative_source` varchar(64) NOT NULL,
  `hot_retention_days` int unsigned NOT NULL,
  `archive_retention_days` int unsigned NOT NULL,
  `purge_after_days` int unsigned DEFAULT NULL,
  `legal_hold_supported` tinyint unsigned NOT NULL,
  `anonymization_strategy` varchar(64) DEFAULT NULL,
  `backup_purge_sla_days` int unsigned DEFAULT NULL,
  `lifecycle_status` varchar(16) NOT NULL DEFAULT 'ACTIVE',
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`table_name`),
  KEY `idx_table_governance_owner` (`owner_code`,`lifecycle_status`,`table_name`),
  CONSTRAINT `fk_table_governance_owner` FOREIGN KEY (`owner_code`) REFERENCES `aoo_data_owner` (`owner_code`) ON DELETE RESTRICT,
  CONSTRAINT `chk_table_governance_class` CHECK ((`data_classification` in (_utf8mb4'PUBLIC',_utf8mb4'INTERNAL',_utf8mb4'CONFIDENTIAL',_utf8mb4'RESTRICTED'))),
  CONSTRAINT `chk_table_governance_hold` CHECK ((`legal_hold_supported` in (0,1))),
  CONSTRAINT `chk_table_governance_retention` CHECK (((`archive_retention_days` >= `hot_retention_days`) and ((`purge_after_days` is null) or (`purge_after_days` >= `archive_retention_days`)))),
  CONSTRAINT `chk_table_governance_status` CHECK ((`lifecycle_status` in (_utf8mb4'ACTIVE',_utf8mb4'RETIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_table_governance`
--

LOCK TABLES `aoo_table_governance` WRITE;
/*!40000 ALTER TABLE `aoo_table_governance` DISABLE KEYS */;
INSERT INTO `aoo_table_governance` VALUES ('activity_check_in','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('activity_mission_progress','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('activity_mission_version','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('activity_progress_event','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('activity_reward_claim','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('activity_version','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_authorization_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',30,365,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_browser_session','SECURITY_PRIVACY','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_command_dedup','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_control_resource','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_operator_account','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_operator_permission','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_operator_role','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_role','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_role_permission','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,NULL,35,'ACTIVE','2026-09-26 12:28:17.297'),('admin_security_nonce','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_sensitive_export','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_sensitive_export_artifact','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_sensitive_export_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('admin_sensitive_export_request','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_account','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_account_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_account_device','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_account_identity','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'IDENTITY_VALUE_HASH',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_account_legal_hold','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_account_session','SECURITY_PRIVACY','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_achievement_claim','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_achievement_definition','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_achievement_progress','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_admin_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'OPERATOR_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_appeal','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_archive_run','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_backup_manifest','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_business_idempotency','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_capacity_forecast','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_card_category','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_client_feature_flag','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_client_notice','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_client_release','GAME_CATALOG','INTERNAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_club_guard','CLUB','CONFIDENTIAL','AOO_DB',365,730,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_club_ledger','CLUB','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_club_member','CLUB','CONFIDENTIAL','AOO_DB',365,730,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_club_room_projection','CLUB','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_club_state','CLUB','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_club_template_index','CLUB','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_club_write_idempotency','CLUB','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_competition_event','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_competition_idempotency','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_compiled_index_active','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_compiled_room_create_index','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_component_conflict','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_component_dependency','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_component_type','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_concurrency_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.473'),('aoo_configuration_cache_epoch','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_connection_generation','GAME_RUNTIME','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_connection_pool_observation','GAME_RUNTIME','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_consumed_event','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_create_ui_choice','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_create_ui_option','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_currency_balance','PLAYER_ASSET','RESTRICTED','AOO_DB',3650,3650,NULL,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_currency_catalog','PLAYER_ASSET','RESTRICTED','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_lifecycle_policy','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_owner','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_quality_issue','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_repair_approval','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_repair_audit','PLATFORM_DATA','INTERNAL','AOO_DB',30,365,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_repair_job','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_data_rights_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_data_rights_request','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_dead_letter_replay_audit','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_deadlock_incident','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_deadlock_retry_policy','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_device_challenge','SECURITY_PRIVACY','RESTRICTED','AOO_DB',7,30,90,0,'DEVICE_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_device_pin','SECURITY_PRIVACY','RESTRICTED','AOO_DB',90,365,730,1,'DEVICE_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_display_id_history','SECURITY_PRIVACY','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'ACCOUNT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_display_id_segment','SECURITY_PRIVACY','INTERNAL','AOO_DB',3650,3650,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_dual_write_control','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_enum_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_enum_value_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_external_callback_receipt','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_external_identity','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_game_catalog','GAME_CATALOG','INTERNAL','AOO_DB',3650,3650,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_game_component','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_family','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_help_content','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_profile_version','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_region','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_release','GAME_CATALOG','INTERNAL','AOO_DB',3650,3650,NULL,1,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_game_release_audit','GAME_RUNTIME','INTERNAL','AOO_DB',30,365,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_release_component','GAME_RUNTIME','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_release_region','GAME_RUNTIME','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_game_service_route','GAME_CATALOG','INTERNAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_game_share','GAME_CATALOG','INTERNAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_hall_game_ticket','GAME_CATALOG','INTERNAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_hall_idempotency','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_hall_room','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_hall_room_member','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_identity_admin_request','SECURITY_PRIVACY','CONFIDENTIAL','AOO_DB',90,365,730,1,'OPERATOR_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_identity_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_identity_credential','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_identity_idempotency','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_identity_migration','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'ACCOUNT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_identity_verification','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_inventory_command','PLAYER_ASSET','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_inventory_lot','PLAYER_ASSET','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_inventory_movement','PLAYER_ASSET','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_invite_consumption','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_invite_link','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_invite_link_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_item_catalog','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_json_schema_registry','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_ledger','PLAYER_ASSET','RESTRICTED','AOO_DB',730,2555,3650,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_legacy_field_mapping','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_legacy_record_envelope','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_legacy_source_object','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_legal_hold','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_luck_draw','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_luck_draw_campaign','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_luck_draw_chance','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_luck_draw_outbox','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_luck_draw_prize','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_maintenance_window','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_match','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_match_member','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_match_queue','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_migration_run','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_migration_validation','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_online_ddl_observation','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_outbox','PLATFORM_DATA','INTERNAL','AOO_DB',30,365,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_pagination_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_payment_order','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_payment_product','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_payment_transaction_claim','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_phone_challenge','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_play_component_binding','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_play_variant','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_play_version','GAME_CATALOG','INTERNAL','AOO_DB',3650,3650,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_player_risk_observation','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_privacy_request','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_HASH_ONLY',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_published_game_configuration','GAME_CATALOG','INTERNAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_query_baseline','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_query_plan_observation','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_rank_score','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_rank_season','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_redemption_campaign','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_redemption_claim','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_redemption_code','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_region','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_region_alias','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_region_identity_legacy_snapshot','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,730,1,'ENTITY_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_region_semantics_policy','GAME_CATALOG','INTERNAL','AOO_DB',3650,3650,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_relationship_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_replica_failover_drill','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_replica_read_policy','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_resource_manifest','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_resource_manifest_entry','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_restore_drill','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_room_authority_route','GAME_RUNTIME','INTERNAL','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_room_billing_reservation','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_room_cost_policy','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_room_create_saga','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_room_event','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_room_id_sequence','GAME_RUNTIME','INTERNAL','AOO_DB',3650,3650,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_room_idempotent_allocation','GAME_RUNTIME','INTERNAL','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('aoo_room_lease','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_room_rule_choice','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_room_rule_definition','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_room_rule_lock','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',180,730,2555,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_room_snapshot','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_room_template','CLUB','CONFIDENTIAL','AOO_DB',365,730,2555,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('aoo_room_template_release_lock','CLUB','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_schema_change_plan','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_sequence','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_server_directory','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_session','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,730,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_settlement','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,730,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_settlement_score','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',180,730,2555,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.412'),('aoo_shard_route_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_soft_delete_contract','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_spectator_admission','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_statistics_plan_baseline','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_store_offer','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_table_governance','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('aoo_tournament','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_tournament_entry','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('aoo_ui_rule_binding','GAME_CATALOG','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('flyway_schema_history','PLATFORM_DATA','INTERNAL','AOO_DB',365,730,2555,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('game_profile_active','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('game_profile_audit','GAME_CATALOG','INTERNAL','AOO_DB',30,365,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('game_profile_version','GAME_CATALOG','INTERNAL','AOO_DB',365,730,NULL,0,NULL,NULL,'ACTIVE','2026-09-26 12:28:17.297'),('gateway_ws_ticket','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('gift_audit','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('gift_ledger','PLAYER_ASSET','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('gift_policy','PLAYER_ASSET','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('gift_transfer','PLAYER_ASSET','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('media_asset','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('media_asset_access','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('media_upload_part','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('media_upload_ticket','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('perspective_replay_event','GAME_RUNTIME','RESTRICTED','AOO_DB',30,180,730,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.188'),('perspective_replay_event_archive','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('player_profile','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('playerWallet','PLAYER_ASSET','RESTRICTED','AOO_DB',730,2555,3650,1,'PLAYER_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:19.351'),('promoter_commission_instruction','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('referral_invite_reward_instruction','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('referral_invite_reward_policy','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('replay_participant','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('replay_participant_archive','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',30,365,2555,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:17.297'),('replay_set_manifest','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('risk_admission_decision','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('risk_event','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('risk_review_directive','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('room_safety_location','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('room_safety_mute','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('room_safety_report','GAME_RUNTIME','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_block','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_friend_request','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_friendship','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_mail','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_notice','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_notification','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_presence','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('social_read_cursor','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_case','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_case_event','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_case_evidence','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_live_audit','SECURITY_PRIVACY','RESTRICTED','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_live_idempotency','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_live_message','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('support_live_session','SECURITY_PRIVACY','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922'),('telemetry_signal','PLATFORM_DATA','CONFIDENTIAL','AOO_DB',365,2555,3650,1,'SUBJECT_ID_TOKENIZE',35,'ACTIVE','2026-09-26 12:28:18.922');
/*!40000 ALTER TABLE `aoo_table_governance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_tournament`
--

DROP TABLE IF EXISTS `aoo_tournament`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_tournament` (
  `tournament_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  `name` varchar(128) NOT NULL,
  `phase` varchar(24) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`tournament_id`),
  CONSTRAINT `chk_tournament_phase` CHECK ((`phase` in (_utf8mb4'REGISTRATION',_utf8mb4'GROUPED',_utf8mb4'RUNNING',_utf8mb4'COMPLETED',_utf8mb4'CANCELLED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_tournament`
--

LOCK TABLES `aoo_tournament` WRITE;
/*!40000 ALTER TABLE `aoo_tournament` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_tournament` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_tournament_entry`
--

DROP TABLE IF EXISTS `aoo_tournament_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_tournament_entry` (
  `tournament_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `status` varchar(24) NOT NULL,
  `registered_at` timestamp(3) NOT NULL,
  `group_no` int DEFAULT NULL,
  `seed_no` int DEFAULT NULL,
  `score` bigint NOT NULL DEFAULT '0',
  `rank_no` int DEFAULT NULL,
  PRIMARY KEY (`tournament_id`,`player_id`),
  UNIQUE KEY `uk_tournament_rank` (`tournament_id`,`rank_no`),
  KEY `idx_tournament_group` (`tournament_id`,`group_no`,`seed_no`),
  CONSTRAINT `fk_tournament_entry` FOREIGN KEY (`tournament_id`) REFERENCES `aoo_tournament` (`tournament_id`),
  CONSTRAINT `chk_tournament_entry_status` CHECK ((`status` in (_utf8mb4'REGISTERED',_utf8mb4'WITHDRAWN',_utf8mb4'ADVANCED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_tournament_entry`
--

LOCK TABLES `aoo_tournament_entry` WRITE;
/*!40000 ALTER TABLE `aoo_tournament_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_tournament_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aoo_ui_rule_binding`
--

DROP TABLE IF EXISTS `aoo_ui_rule_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aoo_ui_rule_binding` (
  `game_id` bigint unsigned NOT NULL,
  `play_version` varchar(64) NOT NULL,
  `option_key` varchar(96) NOT NULL,
  `rule_key` varchar(96) NOT NULL,
  `mapping_expression` json NOT NULL,
  `validation_expression` json NOT NULL,
  `priority` smallint unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`game_id`,`play_version`,`option_key`,`rule_key`),
  KEY `idx_ui_rule_binding_rule` (`game_id`,`play_version`,`rule_key`,`priority`),
  CONSTRAINT `fk_ui_rule_binding_option` FOREIGN KEY (`game_id`, `play_version`, `option_key`) REFERENCES `aoo_create_ui_option` (`game_id`, `play_version`, `option_key`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ui_rule_binding_rule` FOREIGN KEY (`game_id`, `play_version`, `rule_key`) REFERENCES `aoo_room_rule_definition` (`game_id`, `play_version`, `rule_key`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aoo_ui_rule_binding`
--

LOCK TABLES `aoo_ui_rule_binding` WRITE;
/*!40000 ALTER TABLE `aoo_ui_rule_binding` DISABLE KEYS */;
/*!40000 ALTER TABLE `aoo_ui_rule_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'20260822.01','business closure','SQL','V20260822_01__business_closure.sql',-148081085,'root','2026-09-26 12:28:15',81,1),(2,'20260822.02','admin control plane','SQL','V20260822_02__admin_control_plane.sql',-1544706934,'root','2026-09-26 12:28:15',20,1),(3,'20260822.03','game profile publication','SQL','V20260822_03__game_profile_publication.sql',1623325548,'root','2026-09-26 12:28:15',19,1),(4,'20260822.04','admin permissions','SQL','V20260822_04__admin_permissions.sql',-1944078652,'root','2026-09-26 12:28:15',8,1),(5,'20260822.04.1','room recovery','SQL','V20260822_04_1__room_recovery.sql',-182768462,'root','2026-09-26 12:28:15',19,1),(6,'20260822.04.2','currency balance','SQL','V20260822_04_2__currency_balance.sql',-318968283,'root','2026-09-26 12:28:15',8,1),(7,'20260822.04.3','outbox retry','SQL','V20260822_04_3__outbox_retry.sql',724947807,'root','2026-09-26 12:28:15',12,1),(8,'20260822.05','ledger reconciliation indexes','SQL','V20260822_05__ledger_reconciliation_indexes.sql',367575407,'root','2026-09-26 12:28:15',11,1),(9,'20260822.06','million member club indexes','SQL','V20260822_06__million_member_club_indexes.sql',-105362225,'root','2026-09-26 12:28:15',9,1),(10,'20260822.07','ten million player indexes','SQL','V20260822_07__ten_million_player_indexes.sql',-337944779,'root','2026-09-26 12:28:15',9,1),(11,'20260822.08','perspective replay','SQL','V20260822_08__perspective_replay.sql',-135274932,'root','2026-09-26 12:28:15',13,1),(12,'20260822.09','replay retention','SQL','V20260822_09__replay_retention.sql',85697625,'root','2026-09-26 12:28:15',15,1),(13,'20260822.10','perspective room events','SQL','V20260822_10__perspective_room_events.sql',1132802492,'root','2026-09-26 12:28:15',10,1),(14,'20260822.11','consumed events','SQL','V20260822_11__consumed_events.sql',937910647,'root','2026-09-26 12:28:15',8,1),(15,'20260822.12','consumed event claim','SQL','V20260822_12__consumed_event_claim.sql',-33554241,'root','2026-09-26 12:28:15',11,1),(16,'20260822.13','room event visibility identity','SQL','V20260822_13__room_event_visibility_identity.sql',-635921,'root','2026-09-26 12:28:15',11,1),(17,'20260822.14','scalable club members','SQL','V20260822_14__scalable_club_members.sql',-1636273616,'root','2026-09-26 12:28:15',13,1),(18,'20260822.15','account login index','SQL','V20260822_15__account_login_index.sql',2139512476,'root','2026-09-26 12:28:15',4,1),(19,'20260823.01','room event business identity','SQL','V20260823_01__room_event_business_identity.sql',-860525309,'root','2026-09-26 12:28:15',21,1),(20,'20260823.02','outbox claim dlq lifecycle','SQL','V20260823_02__outbox_claim_dlq_lifecycle.sql',1599546435,'root','2026-09-26 12:28:15',14,1),(21,'20260823.03','consumed event repeatable result','SQL','V20260823_03__consumed_event_repeatable_result.sql',2092975979,'root','2026-09-26 12:28:15',14,1),(22,'20260823.04','consumer dead letter replay','SQL','V20260823_04__consumer_dead_letter_replay.sql',1313567175,'root','2026-09-26 12:28:15',18,1),(23,'20260823.05','idempotency result model','SQL','V20260823_05__idempotency_result_model.sql',-2094473149,'root','2026-09-26 12:28:15',11,1),(24,'20260823.06','idempotency business scope','SQL','V20260823_06__idempotency_business_scope.sql',1177218730,'root','2026-09-26 12:28:15',13,1),(25,'20260823.07','snapshot state version','SQL','V20260823_07__snapshot_state_version.sql',1268886353,'root','2026-09-26 12:28:15',12,1),(26,'20260823.08','outbox schema version','SQL','V20260823_08__outbox_schema_version.sql',-187484283,'root','2026-09-26 12:28:15',13,1),(27,'20260823.09','immutable room event history','SQL','V20260823_09__immutable_room_event_history.sql',-460735576,'root','2026-09-26 12:28:15',21,1),(28,'20260823.10','connection generation','SQL','V20260823_10__connection_generation.sql',1748591036,'root','2026-09-26 12:28:15',6,1),(29,'20260823.11','required business semantics','SQL','V20260823_11__required_business_semantics.sql',-1714103317,'root','2026-09-26 12:28:15',20,1),(30,'20260823.12','play member template business keys','SQL','V20260823_12__play_member_template_business_keys.sql',-1452844961,'root','2026-09-26 12:28:15',21,1),(31,'20260823.13','enforced domain checks','SQL','V20260823_13__enforced_domain_checks.sql',1193753295,'root','2026-09-26 12:28:15',118,1),(32,'20260823.14','query shape indexes','SQL','V20260823_14__query_shape_indexes.sql',-2137723072,'root','2026-09-26 12:28:15',26,1),(33,'20260823.15','canonical column types','SQL','V20260823_15__canonical_column_types.sql',-1019913642,'root','2026-09-26 12:28:16',230,1),(34,'20260823.16','utc millisecond time','SQL','V20260823_16__utc_millisecond_time.sql',-138249930,'root','2026-09-26 12:28:16',19,1),(35,'20260823.17','distributed id ownership','SQL','V20260823_17__distributed_id_ownership.sql',-1526456491,'root','2026-09-26 12:28:16',29,1),(36,'20260823.18','club aggregate concurrency','SQL','V20260823_18__club_aggregate_concurrency.sql',-1351609145,'root','2026-09-26 12:28:16',86,1),(37,'20260823.19','canonical storage layout','SQL','V20260823_19__canonical_storage_layout.sql',-1851072423,'root','2026-09-26 12:28:16',88,1),(38,'20260823.20','account login unique index','SQL','V20260823_20__account_login_unique_index.sql',1989287950,'root','2026-09-26 12:28:16',4,1),(39,'20260823.21','consumed event fenced lease','SQL','V20260823_21__consumed_event_fenced_lease.sql',85600160,'root','2026-09-26 12:28:16',13,1),(40,'20260823.22','versioned replay archive','SQL','V20260823_22__versioned_replay_archive.sql',238652874,'root','2026-09-26 12:28:16',26,1),(41,'20260823.23','ledger reconciliation dimensions','SQL','V20260823_23__ledger_reconciliation_dimensions.sql',-30754776,'root','2026-09-26 12:28:16',16,1),(42,'20260823.24','admin rbac audit','SQL','V20260823_24__admin_rbac_audit.sql',968370083,'root','2026-09-26 12:28:16',24,1),(43,'20260823.25','outbox fencing and retention','SQL','V20260823_25__outbox_fencing_and_retention.sql',-1973605759,'root','2026-09-26 12:28:16',19,1),(44,'20260823.26','currency catalog and authority','SQL','V20260823_26__currency_catalog_and_authority.sql',-91002942,'root','2026-09-26 12:28:16',18,1),(45,'20260824.01','game catalog component model','SQL','V20260824_01__game_catalog_component_model.sql',-1473446783,'root','2026-09-26 12:28:16',158,1),(46,'20260824.02','immutable game release index','SQL','V20260824_02__immutable_game_release_index.sql',240769096,'root','2026-09-26 12:28:17',176,1),(47,'20260824.03','data governance controls','SQL','V20260824_03__data_governance_controls.sql',919298982,'root','2026-09-26 12:28:17',152,1),(48,'20260824.04','database operational safety','SQL','V20260824_04__database_operational_safety.sql',-262640529,'root','2026-09-26 12:28:17',86,1),(49,'20260824.05','database integrity gates','SQL','V20260824_05__database_integrity_gates.sql',1429763345,'root','2026-09-26 12:28:17',50,1),(50,'20260824.06','governance workflow procedures','SQL','V20260824_06__governance_workflow_procedures.sql',-1474997389,'root','2026-09-26 12:28:17',21,1),(51,'20260824.07','ledger scope and score precision','SQL','V20260824_07__ledger_scope_and_score_precision.sql',-1889382251,'root','2026-09-26 12:28:17',27,1),(52,'20260824.08','concurrency soft delete and route contracts','SQL','V20260824_08__concurrency_soft_delete_and_route_contracts.sql',1927908091,'root','2026-09-26 12:28:17',52,1),(53,'20260824.21','admin security nonce','SQL','V20260824_21__admin_security_nonce.sql',-1960705764,'root','2026-09-26 12:28:17',6,1),(54,'20260824.24','edge runtime state guards','SQL','V20260824_24__edge_runtime_state_guards.sql',-1230069360,'root','2026-09-26 12:28:17',58,1),(55,'20260824.30','club backend consistency','SQL','V20260824_30__club_backend_consistency.sql',603249348,'root','2026-09-26 12:28:17',27,1),(56,'20260824.31','admin sensitive export','SQL','V20260824_31__admin_sensitive_export.sql',578631219,'root','2026-09-26 12:28:17',29,1),(57,'20260824.32','external platform identity and risk','SQL','V20260824_32__external_platform_identity_and_risk.sql',-1098868386,'root','2026-09-26 12:28:17',20,1),(58,'20260824.34','billing payment api','SQL','V20260824_34__billing_payment_api.sql',84544517,'root','2026-09-26 12:28:17',21,1),(59,'20260824.35','record replay api','SQL','V20260824_35__record_replay_api.sql',-389535581,'root','2026-09-26 12:28:17',56,1),(60,'20260824.36','hall catalog room api','SQL','V20260824_36__hall_catalog_room_api.sql',-1543451284,'root','2026-09-26 12:28:17',45,1),(61,'20260824.38','account session api','SQL','V20260824_38__account_session_api.sql',-1609742896,'root','2026-09-26 12:28:17',33,1),(62,'20260824.39','social notification api','SQL','V20260824_39__social_notification_api.sql',1171727493,'root','2026-09-26 12:28:17',51,1),(63,'20260824.40','player support api','SQL','V20260824_40__player_support_api.sql',590519780,'root','2026-09-26 12:28:17',23,1),(64,'20260824.41','media upload api','SQL','V20260824_41__media_upload_api.sql',-1771806957,'root','2026-09-26 12:28:17',33,1),(65,'20260824.42','version notice update api','SQL','V20260824_42__version_notice_update_api.sql',754052334,'root','2026-09-26 12:28:18',32,1),(66,'20260824.43','matchmaking tournament','SQL','V20260824_43__matchmaking_tournament.sql',-492977792,'root','2026-09-26 12:28:18',53,1),(67,'20260824.44','inventory store api','SQL','V20260824_44__inventory_store_api.sql',973021356,'root','2026-09-26 12:28:18',82,1),(68,'20260824.45','ranking achievement','SQL','V20260824_45__ranking_achievement.sql',1756651233,'root','2026-09-26 12:28:18',31,1),(69,'20260824.46','privacy data rights api','SQL','V20260824_46__privacy_data_rights_api.sql',-1158709499,'root','2026-09-26 12:28:18',22,1),(70,'20260824.47','telemetry risk api','SQL','V20260824_47__telemetry_risk_api.sql',-1491848499,'root','2026-09-26 12:28:18',21,1),(71,'20260824.48','share invite link api','SQL','V20260824_48__share_invite_link_api.sql',1612411437,'root','2026-09-26 12:28:18',21,1),(72,'20260824.49','identity verification api','SQL','V20260824_49__identity_verification_api.sql',-418985778,'root','2026-09-26 12:28:18',38,1),(73,'20260824.50','player profile api','SQL','V20260824_50__player_profile_api.sql',669922264,'root','2026-09-26 12:28:18',13,1),(74,'20260824.51','activity mission api','SQL','V20260824_51__activity_mission_api.sql',840274039,'root','2026-09-26 12:28:18',62,1),(75,'20260824.52','spectator game share api','SQL','V20260824_52__spectator_game_share_api.sql',-164810893,'root','2026-09-26 12:28:18',34,1),(76,'20260824.53','referral agent api','SQL','V20260824_53__referral_agent_api.sql',-47676593,'root','2026-09-26 12:28:18',17,1),(77,'20260824.54','player gifting api','SQL','V20260824_54__player_gifting_api.sql',-1578279657,'root','2026-09-26 12:28:18',30,1),(78,'20260824.55','canonical game configuration repository','SQL','V20260824_55__canonical_game_configuration_repository.sql',-122820788,'root','2026-09-26 12:28:18',11,1),(79,'20260824.56','gateway ws ticket','SQL','V20260824_56__gateway_ws_ticket.sql',1625558638,'root','2026-09-26 12:28:18',9,1),(80,'20260824.57','luck draw api','SQL','V20260824_57__luck_draw_api.sql',540290030,'root','2026-09-26 12:28:18',33,1),(81,'20260824.58','social notice red dot','SQL','V20260824_58__social_notice_red_dot.sql',-1983851380,'root','2026-09-26 12:28:18',18,1),(82,'20260824.59','version feature flags server directory','SQL','V20260824_59__version_feature_flags_server_directory.sql',-1872934436,'root','2026-09-26 12:28:18',14,1),(83,'20260824.60','support live session','SQL','V20260824_60__support_live_session.sql',1727113877,'root','2026-09-26 12:28:18',31,1),(84,'20260824.73','risk admission authority','SQL','V20260824_73__risk_admission_authority.sql',1005644390,'root','2026-09-26 12:28:18',11,1),(85,'20260824.74','room safety report gps','SQL','V20260824_74__room_safety_report_gps.sql',-509560448,'root','2026-09-26 12:28:18',18,1),(86,'20260824.76','admin browser auth','SQL','V20260824_76__admin_browser_auth.sql',1448957631,'root','2026-09-26 12:28:18',15,1),(87,'20260824.77','game release referential consistency','SQL','V20260824_77__game_release_referential_consistency.sql',-1221092439,'root','2026-09-26 12:28:18',124,1),(88,'20260825.78','hall room id sequence','SQL','V20260825_78__hall_room_id_sequence.sql',135832321,'root','2026-09-26 12:28:18',7,1),(89,'20260825.79','room authority lifecycle','SQL','V20260825_79__room_authority_lifecycle.sql',-1471450476,'root','2026-09-26 12:28:18',21,1),(90,'20260825.80','room create saga recovery','SQL','V20260825_80__room_create_saga_recovery.sql',237462470,'root','2026-09-26 12:28:18',15,1),(91,'20260825.81','region is classification only','SQL','V20260825_81__region_is_classification_only.sql',-1929720232,'root','2026-09-26 12:28:19',12,1),(92,'20260825.82','matchmaking without region partition','SQL','V20260825_82__matchmaking_without_region_partition.sql',-306088497,'root','2026-09-26 12:28:19',19,1),(93,'20260825.83','room saga compensation origin','SQL','V20260825_83__room_saga_compensation_origin.sql',-237554000,'root','2026-09-26 12:28:19',14,1),(94,'20260825.84','hall room region is classification','SQL','V20260825_84__hall_room_region_is_classification.sql',-537218120,'root','2026-09-26 12:28:19',9,1),(95,'20260825.85','idempotent room id allocation','SQL','V20260825_85__idempotent_room_id_allocation.sql',1441600505,'root','2026-09-26 12:28:19',26,1),(96,'20260825.86','hall room scope and club projection','SQL','V20260825_86__hall_room_scope_and_club_projection.sql',1266287013,'root','2026-09-26 12:28:19',24,1),(97,'20260825.87','global player wallet','SQL','V20260825_87__global_player_wallet.sql',686131909,'root','2026-09-26 12:28:19',12,1),(98,'20260825.88','retire city runtime controls','SQL','V20260825_88__retire_city_runtime_controls.sql',-1332889912,'root','2026-09-26 12:28:19',2,1),(99,'20260825.90','unified account identity','SQL','V20260825_90__unified_account_identity.sql',-192382196,'root','2026-09-26 12:28:19',45,1),(100,'20260825.91','remove legacy account login','SQL','V20260825_91__remove_legacy_account_login.sql',-695799935,'root','2026-09-26 12:28:19',19,1),(101,'20260825.92','retire region identity columns','SQL','V20260825_92__retire_region_identity_columns.sql',1867106511,'root','2026-09-26 12:28:19',20,1),(102,'20260825.93','rename remaining city audit columns','SQL','V20260825_93__rename_remaining_city_audit_columns.sql',304433960,'root','2026-09-26 12:28:19',6,1),(103,'20260825.94','late table governance coverage','SQL','V20260825_94__late_table_governance_coverage.sql',696412991,'root','2026-09-26 12:28:19',3,1),(104,'20260825.95','hall room saga state','SQL','V20260825_95__hall_room_saga_state.sql',589746247,'root','2026-09-26 12:28:19',19,1),(105,'20260825.96','remove player profile region identity','SQL','V20260825_96__remove_player_profile_region_identity.sql',1030780592,'root','2026-09-26 12:28:19',28,1),(106,'20260825.96.1','required pdk catalog prerequisites','SQL','V20260825_96_1__required_pdk_catalog_prerequisites.sql',-2027279043,'root','2026-09-26 12:28:19',4,1),(107,'20260825.97','njpdk native resource release','SQL','V20260825_97__njpdk_native_resource_release.sql',379306045,'root','2026-09-26 12:28:19',7,1),(108,'20260826.01','njpdk four player publication','SQL','V20260826_01__njpdk_four_player_publication.sql',1672091599,'root','2026-09-26 12:28:19',5,1),(109,'20260826.02','hall authoritative join reservation','SQL','V20260826_02__hall_authoritative_join_reservation.sql',571217346,'root','2026-09-26 12:28:19',21,1),(110,'20260826.03','idempotency unknown outcome','SQL','V20260826_03__idempotency_unknown_outcome.sql',699057170,'root','2026-09-26 12:28:19',16,1),(111,'20260826.04','durable settlement outbox and score backfill','SQL','V20260826_04__durable_settlement_outbox_and_score_backfill.sql',-1308274023,'root','2026-09-26 12:28:19',8,1),(112,'20260826.05','settlement template catalog contract','SQL','V20260826_05__settlement_template_catalog_contract.sql',1749857205,'root','2026-09-26 12:28:19',1,1),(113,'20260826.06','canonical poker family and settlement defaults','SQL','V20260826_06__canonical_poker_family_and_settlement_defaults.sql',757265097,'root','2026-09-26 12:28:19',27,1),(114,'20260826.07','njpdk neijiang classification','SQL','V20260826_07__njpdk_neijiang_classification.sql',1063645517,'root','2026-09-26 12:28:19',3,1),(115,'20260826.08','publish chengdu pdk catalog','SQL','V20260826_08__publish_chengdu_pdk_catalog.sql',922270241,'root','2026-09-26 12:28:19',7,1),(116,'20260827.01','publish pdk public room rules','SQL','V20260827_01__publish_pdk_public_room_rules.sql',-766703678,'root','2026-09-26 12:28:19',4,1),(117,'20260827.02','inherit pdk public rules in njpdk','SQL','V20260827_02__inherit_pdk_public_rules_in_njpdk.sql',819930301,'root','2026-09-26 12:28:19',4,1),(118,'20260827.03','chengdu pdk twelve round cost policy','SQL','V20260827_03__chengdu_pdk_twelve_round_cost_policy.sql',-941235734,'root','2026-09-26 12:28:19',2,1),(119,'20260827.04','publish pdk common room bundle','SQL','V20260827_04__publish_pdk_common_room_bundle.sql',-2042589706,'root','2026-09-26 12:28:19',6,1),(120,'20260901.01','default account crystal balance','SQL','V20260901_01__default_account_crystal_balance.sql',935126151,'root','2026-09-26 12:28:19',5,1),(121,'20260903.01','durable waiting room expiration','SQL','V20260903_01__durable_waiting_room_expiration.sql',1898015565,'root','2026-09-26 12:28:19',45,1),(122,'20260907.01','stable short replay code','SQL','V20260907_01__stable_short_replay_code.sql',1880914422,'root','2026-09-26 12:28:19',13,1),(123,'20260907.02','publish neijiang liangshan pdk profiles','SQL','V20260907_02__publish_neijiang_liangshan_pdk_profiles.sql',-2015856002,'root','2026-09-26 12:28:19',19,1),(124,'20260907.03','pdk business codes and room history cleanup','SQL','V20260907_03__pdk_business_codes_and_room_history_cleanup.sql',-1198017318,'root','2026-09-26 12:28:19',89,1),(125,'20260907.04','repair regional pdk create validators','SQL','V20260907_04__repair_regional_pdk_create_validators.sql',1109168378,'root','2026-09-26 12:28:19',8,1),(126,'20260907.05','deduplicate neijiang pdk cost scope','SQL','V20260907_05__deduplicate_neijiang_pdk_cost_scope.sql',1079557189,'root','2026-09-26 12:28:19',2,1),(127,'20260907.06','make regional pdk room restrictions optional','SQL','V20260907_06__make_regional_pdk_room_restrictions_optional.sql',-1213755586,'root','2026-09-26 12:28:19',8,1),(128,'20260907.07','canonicalize liangshan pdk create defaults','SQL','V20260907_07__canonicalize_liangshan_pdk_create_defaults.sql',-1119189681,'root','2026-09-26 12:28:19',8,1),(129,'20260907.08','fix liangshan pdk string defaults','SQL','V20260907_08__fix_liangshan_pdk_string_defaults.sql',160472094,'root','2026-09-26 12:28:19',7,1),(130,'20260907.09','publish liangshan room rule ui','SQL','V20260907_09__publish_liangshan_room_rule_ui.sql',1905077493,'root','2026-09-26 12:28:19',10,1),(131,'20260907.10','correct ls201 xqp rules and deal schema','SQL','V20260907_10__correct_ls201_xqp_rules_and_deal_schema.sql',1502818568,'root','2026-09-26 12:28:19',11,1),(132,'20260907.11','repair ls201 utf8 publication','SQL','V20260907_11__repair_ls201_utf8_publication.sql',595712401,'root','2026-09-26 12:28:20',14,1),(133,'20260910.01','publish cd201 pdk common room bundle','SQL','V20260910_01__publish_cd201_pdk_common_room_bundle.sql',-123157339,'root','2026-09-26 12:28:20',7,1),(134,'20260910.02','publish cd201 pdk common bundle','SQL','V20260910_02__publish_cd201_pdk_common_bundle.sql',654873655,'root','2026-09-26 12:28:20',7,1),(135,'20260911.01','remove regional and club card assets','SQL','V20260911_01__remove_regional_and_club_card_assets.sql',1376036246,'root','2026-09-26 12:28:20',26,0);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_profile_active`
--

DROP TABLE IF EXISTS `game_profile_active`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_profile_active` (
  `game_id` bigint unsigned NOT NULL,
  `version` varchar(64) NOT NULL,
  `activated_by` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `activated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`game_id`),
  KEY `fk_game_profile_active_version` (`game_id`,`version`),
  CONSTRAINT `fk_game_profile_active_version` FOREIGN KEY (`game_id`, `version`) REFERENCES `game_profile_version` (`game_id`, `version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_profile_active`
--

LOCK TABLES `game_profile_active` WRITE;
/*!40000 ALTER TABLE `game_profile_active` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_profile_active` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_profile_audit`
--

DROP TABLE IF EXISTS `game_profile_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_profile_audit` (
  `audit_id` varchar(64) NOT NULL,
  `game_id` bigint unsigned NOT NULL,
  `version` varchar(64) NOT NULL,
  `action` varchar(32) NOT NULL,
  `operator_id` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  `occurred_at` datetime(3) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_game_profile_audit` (`game_id`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_profile_audit`
--

LOCK TABLES `game_profile_audit` WRITE;
/*!40000 ALTER TABLE `game_profile_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_profile_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_profile_version`
--

DROP TABLE IF EXISTS `game_profile_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_profile_version` (
  `game_id` bigint unsigned NOT NULL,
  `version` varchar(64) NOT NULL,
  `scope` varchar(16) NOT NULL,
  `profile_json` json NOT NULL,
  `published_at` datetime(3) NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `reason` varchar(500) NOT NULL,
  PRIMARY KEY (`game_id`,`version`),
  UNIQUE KEY `uk_game_profile_business` (`game_id`,`version`),
  KEY `idx_game_profile_scope` (`scope`,`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_profile_version`
--

LOCK TABLES `game_profile_version` WRITE;
/*!40000 ALTER TABLE `game_profile_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_profile_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_ws_ticket`
--

DROP TABLE IF EXISTS `gateway_ws_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gateway_ws_ticket` (
  `ticket_hash` char(64) NOT NULL,
  `account_id` bigint NOT NULL,
  `session_id` char(36) NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `allowed_origin` varchar(255) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `issued_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`ticket_hash`),
  UNIQUE KEY `uk_gateway_ws_ticket_request` (`account_id`,`idempotency_key`),
  KEY `idx_gateway_ws_ticket_expiry` (`expires_at`),
  KEY `fk_gateway_ws_ticket_session` (`session_id`),
  CONSTRAINT `fk_gateway_ws_ticket_account` FOREIGN KEY (`account_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `fk_gateway_ws_ticket_session` FOREIGN KEY (`session_id`) REFERENCES `aoo_account_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_ws_ticket`
--

LOCK TABLES `gateway_ws_ticket` WRITE;
/*!40000 ALTER TABLE `gateway_ws_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateway_ws_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_audit`
--

DROP TABLE IF EXISTS `gift_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_audit` (
  `sequence_no` bigint NOT NULL AUTO_INCREMENT,
  `gift_id` char(36) NOT NULL,
  `event_type` varchar(32) NOT NULL,
  `actor_id` bigint NOT NULL,
  `payload_json` json NOT NULL,
  `previous_hash` char(64) NOT NULL,
  `event_hash` char(64) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`sequence_no`),
  UNIQUE KEY `uk_gift_audit_hash` (`event_hash`),
  KEY `idx_gift_audit_chain` (`gift_id`,`sequence_no`),
  CONSTRAINT `fk_gift_audit_transfer` FOREIGN KEY (`gift_id`) REFERENCES `gift_transfer` (`gift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_audit`
--

LOCK TABLES `gift_audit` WRITE;
/*!40000 ALTER TABLE `gift_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_ledger`
--

DROP TABLE IF EXISTS `gift_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_ledger` (
  `ledger_id` bigint NOT NULL AUTO_INCREMENT,
  `gift_id` char(36) NOT NULL,
  `player_id` bigint NOT NULL,
  `counterparty_id` bigint NOT NULL,
  `direction` varchar(3) NOT NULL,
  `asset_code` varchar(64) NOT NULL,
  `quantity` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`ledger_id`),
  UNIQUE KEY `uk_gift_ledger_side` (`gift_id`,`player_id`,`direction`),
  KEY `idx_gift_ledger_player` (`player_id`,`created_at`),
  CONSTRAINT `fk_gift_ledger_transfer` FOREIGN KEY (`gift_id`) REFERENCES `gift_transfer` (`gift_id`),
  CONSTRAINT `ck_gift_direction` CHECK ((`direction` in (_utf8mb4'IN',_utf8mb4'OUT')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_ledger`
--

LOCK TABLES `gift_ledger` WRITE;
/*!40000 ALTER TABLE `gift_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_policy`
--

DROP TABLE IF EXISTS `gift_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_policy` (
  `asset_code` varchar(64) NOT NULL,
  `per_gift_limit` bigint NOT NULL,
  `daily_sender_limit` bigint NOT NULL,
  `min_account_age_hours` bigint NOT NULL DEFAULT '24',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`asset_code`),
  CONSTRAINT `ck_gift_policy_limits` CHECK (((`per_gift_limit` > 0) and (`daily_sender_limit` >= `per_gift_limit`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_policy`
--

LOCK TABLES `gift_policy` WRITE;
/*!40000 ALTER TABLE `gift_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_transfer`
--

DROP TABLE IF EXISTS `gift_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_transfer` (
  `gift_id` char(36) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `sender_id` bigint NOT NULL,
  `recipient_id` bigint NOT NULL,
  `asset_code` varchar(64) NOT NULL,
  `quantity` bigint NOT NULL,
  `state` varchar(24) NOT NULL,
  `risk_code` varchar(64) NOT NULL,
  `risk_score` smallint NOT NULL,
  `failure_code` varchar(64) DEFAULT NULL,
  `device_id` varchar(128) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `business_date` date NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`gift_id`),
  UNIQUE KEY `uk_gift_idempotency` (`idempotency_key`),
  KEY `idx_gift_sender_daily` (`sender_id`,`asset_code`,`business_date`,`state`),
  KEY `idx_gift_recipient` (`recipient_id`,`created_at`),
  CONSTRAINT `fk_gift_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `fk_gift_sender` FOREIGN KEY (`sender_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `ck_gift_distinct` CHECK ((`sender_id` <> `recipient_id`)),
  CONSTRAINT `ck_gift_quantity` CHECK ((`quantity` > 0)),
  CONSTRAINT `ck_gift_state` CHECK ((`state` in (_utf8mb4'RESERVED',_utf8mb4'DEBITED',_utf8mb4'COMPLETED',_utf8mb4'FAILED',_utf8mb4'COMPENSATED',_utf8mb4'COMPENSATION_PENDING')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_transfer`
--

LOCK TABLES `gift_transfer` WRITE;
/*!40000 ALTER TABLE `gift_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_asset`
--

DROP TABLE IF EXISTS `media_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_asset` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `object_key` varchar(512) NOT NULL,
  `kind` varchar(16) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `byte_size` bigint NOT NULL,
  `duration_ms` bigint NOT NULL DEFAULT '0',
  `sha256` char(64) NOT NULL,
  `state` varchar(16) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_media_asset_hash` (`sha256`,`byte_size`,`mime_type`),
  UNIQUE KEY `uk_media_asset_object_key` (`object_key`),
  CONSTRAINT `ck_media_asset_duration` CHECK ((`duration_ms` >= 0)),
  CONSTRAINT `ck_media_asset_kind` CHECK ((`kind` in (_utf8mb4'AVATAR',_utf8mb4'VOICE',_utf8mb4'EVIDENCE'))),
  CONSTRAINT `ck_media_asset_size` CHECK ((`byte_size` > 0)),
  CONSTRAINT `ck_media_asset_state` CHECK ((`state` in (_utf8mb4'READY',_utf8mb4'DELETING',_utf8mb4'DELETED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_asset`
--

LOCK TABLES `media_asset` WRITE;
/*!40000 ALTER TABLE `media_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_asset_access`
--

DROP TABLE IF EXISTS `media_asset_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_asset_access` (
  `asset_id` bigint NOT NULL,
  `owner_id` bigint NOT NULL,
  `granted_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`asset_id`,`owner_id`),
  KEY `ix_media_asset_access_owner` (`owner_id`,`asset_id`),
  CONSTRAINT `fk_media_asset_access_asset` FOREIGN KEY (`asset_id`) REFERENCES `media_asset` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_asset_access`
--

LOCK TABLES `media_asset_access` WRITE;
/*!40000 ALTER TABLE `media_asset_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_asset_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_upload_part`
--

DROP TABLE IF EXISTS `media_upload_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_upload_part` (
  `ticket_id` char(36) NOT NULL,
  `part_number` int NOT NULL,
  `byte_size` bigint NOT NULL,
  `etag` varchar(255) NOT NULL,
  `sha256` char(64) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`ticket_id`,`part_number`),
  CONSTRAINT `fk_media_part_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `media_upload_ticket` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_media_part_number` CHECK ((`part_number` > 0)),
  CONSTRAINT `ck_media_part_size` CHECK ((`byte_size` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_upload_part`
--

LOCK TABLES `media_upload_part` WRITE;
/*!40000 ALTER TABLE `media_upload_part` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_upload_part` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_upload_ticket`
--

DROP TABLE IF EXISTS `media_upload_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_upload_ticket` (
  `id` char(36) NOT NULL,
  `owner_id` bigint NOT NULL,
  `object_key` varchar(512) NOT NULL,
  `storage_upload_id` varchar(1024) NOT NULL,
  `kind` varchar(16) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `byte_size` bigint NOT NULL,
  `duration_ms` bigint NOT NULL DEFAULT '0',
  `sha256` char(64) NOT NULL,
  `chunk_bytes` int NOT NULL,
  `expected_parts` int NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `state` varchar(16) NOT NULL,
  `asset_id` bigint DEFAULT NULL,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_media_ticket_expiry` (`state`,`expires_at`),
  KEY `ix_media_ticket_owner` (`owner_id`,`created_at`),
  KEY `fk_media_ticket_asset` (`asset_id`),
  CONSTRAINT `fk_media_ticket_asset` FOREIGN KEY (`asset_id`) REFERENCES `media_asset` (`id`),
  CONSTRAINT `ck_media_ticket_kind` CHECK ((`kind` in (_utf8mb4'AVATAR',_utf8mb4'VOICE',_utf8mb4'EVIDENCE'))),
  CONSTRAINT `ck_media_ticket_size` CHECK (((`byte_size` > 0) and (`chunk_bytes` > 0) and (`expected_parts` > 0))),
  CONSTRAINT `ck_media_ticket_state` CHECK ((`state` in (_utf8mb4'OPEN',_utf8mb4'COMPLETING',_utf8mb4'READY',_utf8mb4'FAILED',_utf8mb4'EXPIRED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_upload_ticket`
--

LOCK TABLES `media_upload_ticket` WRITE;
/*!40000 ALTER TABLE `media_upload_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_upload_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perspective_replay_event`
--

DROP TABLE IF EXISTS `perspective_replay_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perspective_replay_event` (
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `event_sequence` bigint unsigned NOT NULL,
  `visibility` varchar(24) NOT NULL,
  `owner_player_id` bigint unsigned NOT NULL DEFAULT '0',
  `message_id` varchar(128) NOT NULL,
  `schema_version` int NOT NULL DEFAULT '1',
  `play_version` varchar(128) NOT NULL DEFAULT 'legacy-v1',
  `release_id` bigint unsigned DEFAULT NULL,
  `card_codec_version` varchar(64) DEFAULT NULL,
  `event_interpreter_version` varchar(64) DEFAULT NULL,
  `protocol_version` varchar(64) DEFAULT NULL,
  `payload` mediumblob NOT NULL,
  `content_hash` char(64) GENERATED ALWAYS AS (lower(sha2(`payload`,256))) STORED,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`room_id`,`set_id`,`event_sequence`,`visibility`,`owner_player_id`),
  KEY `idx_replay_player_view` (`owner_player_id`,`room_id`,`set_id`,`event_sequence`),
  KEY `idx_replay_retention` (`created_at`,`room_id`,`set_id`),
  KEY `idx_replay_release` (`release_id`,`room_id`,`set_id`,`event_sequence`),
  KEY `idx_replay_chunk` (`room_id`,`set_id`,`event_sequence`,`visibility`,`owner_player_id`,`play_version`),
  CONSTRAINT `fk_replay_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perspective_replay_event`
--

LOCK TABLES `perspective_replay_event` WRITE;
/*!40000 ALTER TABLE `perspective_replay_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `perspective_replay_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perspective_replay_event_archive`
--

DROP TABLE IF EXISTS `perspective_replay_event_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perspective_replay_event_archive` (
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `event_sequence` bigint unsigned NOT NULL,
  `visibility` varchar(24) NOT NULL,
  `owner_player_id` bigint unsigned NOT NULL,
  `message_id` varchar(128) NOT NULL,
  `schema_version` int NOT NULL,
  `play_version` varchar(128) NOT NULL,
  `release_id` bigint unsigned DEFAULT NULL,
  `card_codec_version` varchar(64) DEFAULT NULL,
  `event_interpreter_version` varchar(64) DEFAULT NULL,
  `protocol_version` varchar(64) DEFAULT NULL,
  `payload` mediumblob NOT NULL,
  `content_hash` char(64) GENERATED ALWAYS AS (lower(sha2(`payload`,256))) STORED,
  `created_at` datetime(3) NOT NULL,
  `archived_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`,`set_id`,`event_sequence`,`visibility`,`owner_player_id`),
  KEY `idx_replay_archive_retention` (`archived_at`,`room_id`,`set_id`),
  KEY `idx_replay_archive_player` (`owner_player_id`,`room_id`,`set_id`,`event_sequence`),
  KEY `idx_replay_archive_release` (`release_id`,`room_id`,`set_id`,`event_sequence`),
  CONSTRAINT `fk_replay_archive_release` FOREIGN KEY (`release_id`) REFERENCES `aoo_game_release` (`release_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perspective_replay_event_archive`
--

LOCK TABLES `perspective_replay_event_archive` WRITE;
/*!40000 ALTER TABLE `perspective_replay_event_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `perspective_replay_event_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playerWallet`
--

DROP TABLE IF EXISTS `playerWallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playerWallet` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `accountID` bigint NOT NULL DEFAULT '0',
  `pid` bigint NOT NULL,
  `value` int NOT NULL DEFAULT '0',
  `time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_player_wallet_pid` (`pid`),
  CONSTRAINT `chk_player_wallet_value` CHECK ((`value` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='account-wide room-card wallet';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playerWallet`
--

LOCK TABLES `playerWallet` WRITE;
/*!40000 ALTER TABLE `playerWallet` DISABLE KEYS */;
/*!40000 ALTER TABLE `playerWallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_profile`
--

DROP TABLE IF EXISTS `player_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_profile` (
  `player_id` bigint NOT NULL,
  `nickname` varchar(96) NOT NULL,
  `avatar_asset_id` bigint DEFAULT NULL,
  `gender_code` varchar(16) NOT NULL DEFAULT 'UNSPECIFIED',
  `language_code` varchar(35) NOT NULL DEFAULT 'en',
  `sound_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `music_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `vibration_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `show_gender` tinyint(1) NOT NULL DEFAULT '0',
  `nickname_changed_at` timestamp(3) NULL DEFAULT NULL,
  `avatar_changed_at` timestamp(3) NULL DEFAULT NULL,
  `profile_version` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`player_id`),
  KEY `idx_player_profile_nickname` (`nickname`),
  KEY `idx_player_profile_avatar` (`avatar_asset_id`),
  CONSTRAINT `fk_player_profile_account` FOREIGN KEY (`player_id`) REFERENCES `aoo_account` (`account_id`),
  CONSTRAINT `fk_player_profile_avatar` FOREIGN KEY (`avatar_asset_id`) REFERENCES `media_asset` (`id`),
  CONSTRAINT `ck_player_profile_gender` CHECK ((`gender_code` in (_utf8mb4'UNSPECIFIED',_utf8mb4'FEMALE',_utf8mb4'MALE',_utf8mb4'NON_BINARY'))),
  CONSTRAINT `ck_player_profile_version` CHECK ((`profile_version` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_profile`
--

LOCK TABLES `player_profile` WRITE;
/*!40000 ALTER TABLE `player_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promoter_commission_instruction`
--

DROP TABLE IF EXISTS `promoter_commission_instruction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promoter_commission_instruction` (
  `command_id` varchar(128) NOT NULL,
  `club_id` bigint NOT NULL,
  `promoter_id` bigint NOT NULL,
  `from_date` int NOT NULL,
  `to_date` int NOT NULL,
  `base_amount` decimal(20,2) NOT NULL,
  `rate` decimal(9,6) NOT NULL,
  `commission_amount` bigint NOT NULL,
  `currency` varchar(32) NOT NULL,
  `status` enum('CALCULATED','SETTLED') NOT NULL,
  `billing_reference` varchar(160) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`command_id`),
  KEY `idx_commission_promoter_status` (`promoter_id`,`status`,`created_at`),
  CONSTRAINT `chk_commission_amount` CHECK (((`base_amount` >= 0) and (`commission_amount` >= 0))),
  CONSTRAINT `chk_commission_period` CHECK ((`from_date` <= `to_date`)),
  CONSTRAINT `chk_commission_rate` CHECK (((`rate` >= 0) and (`rate` <= 1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promoter_commission_instruction`
--

LOCK TABLES `promoter_commission_instruction` WRITE;
/*!40000 ALTER TABLE `promoter_commission_instruction` DISABLE KEYS */;
/*!40000 ALTER TABLE `promoter_commission_instruction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_invite_reward_instruction`
--

DROP TABLE IF EXISTS `referral_invite_reward_instruction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_invite_reward_instruction` (
  `idempotency_key` varchar(128) NOT NULL,
  `consumption_id` bigint NOT NULL,
  `invite_id` bigint NOT NULL,
  `issuer_account_id` bigint NOT NULL,
  `consumer_account_id` bigint NOT NULL,
  `kind` enum('ROOM','CLUB') NOT NULL,
  `target_id` bigint NOT NULL,
  `currency` varchar(32) NOT NULL,
  `reward_amount` decimal(20,2) NOT NULL,
  `status` enum('RESERVED','GRANTED') NOT NULL,
  `billing_reference` varchar(160) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`idempotency_key`),
  UNIQUE KEY `uk_referral_consumption` (`consumption_id`),
  KEY `ix_referral_consumer` (`consumer_account_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_invite_reward_instruction`
--

LOCK TABLES `referral_invite_reward_instruction` WRITE;
/*!40000 ALTER TABLE `referral_invite_reward_instruction` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_invite_reward_instruction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_invite_reward_policy`
--

DROP TABLE IF EXISTS `referral_invite_reward_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_invite_reward_policy` (
  `kind` enum('ROOM','CLUB') NOT NULL,
  `currency` varchar(32) NOT NULL,
  `reward_amount` decimal(20,2) NOT NULL,
  `enabled` tinyint NOT NULL,
  PRIMARY KEY (`kind`),
  CONSTRAINT `chk_invite_reward_amount` CHECK ((`reward_amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_invite_reward_policy`
--

LOCK TABLES `referral_invite_reward_policy` WRITE;
/*!40000 ALTER TABLE `referral_invite_reward_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_invite_reward_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replay_participant`
--

DROP TABLE IF EXISTS `replay_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replay_participant` (
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `seat_id` int unsigned NOT NULL,
  `granted_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`,`set_id`,`player_id`),
  KEY `idx_replay_participant_player` (`player_id`,`room_id`,`set_id`),
  KEY `idx_replay_participant_retention` (`granted_at`,`room_id`,`set_id`),
  KEY `idx_history_player_granted` (`player_id`,`granted_at`,`room_id`,`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replay_participant`
--

LOCK TABLES `replay_participant` WRITE;
/*!40000 ALTER TABLE `replay_participant` DISABLE KEYS */;
/*!40000 ALTER TABLE `replay_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replay_participant_archive`
--

DROP TABLE IF EXISTS `replay_participant_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replay_participant_archive` (
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `seat_id` int unsigned NOT NULL,
  `granted_at` datetime(3) NOT NULL,
  `archived_at` datetime(3) NOT NULL,
  PRIMARY KEY (`room_id`,`set_id`,`player_id`),
  KEY `idx_replay_participant_archive_player` (`player_id`,`room_id`,`set_id`),
  KEY `idx_history_archive_player_granted` (`player_id`,`granted_at`,`room_id`,`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replay_participant_archive`
--

LOCK TABLES `replay_participant_archive` WRITE;
/*!40000 ALTER TABLE `replay_participant_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `replay_participant_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replay_set_manifest`
--

DROP TABLE IF EXISTS `replay_set_manifest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replay_set_manifest` (
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `play_version` varchar(128) NOT NULL,
  `schema_version` int NOT NULL,
  `event_count` bigint unsigned NOT NULL,
  `content_hash` char(64) NOT NULL,
  `closed_at` datetime(3) NOT NULL,
  `archive_after` datetime(3) NOT NULL,
  `delete_after` datetime(3) NOT NULL,
  `legal_hold` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`room_id`,`set_id`),
  KEY `idx_replay_manifest_lifecycle` (`legal_hold`,`archive_after`,`delete_after`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replay_set_manifest`
--

LOCK TABLES `replay_set_manifest` WRITE;
/*!40000 ALTER TABLE `replay_set_manifest` DISABLE KEYS */;
/*!40000 ALTER TABLE `replay_set_manifest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replay_short_code`
--

DROP TABLE IF EXISTS `replay_short_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replay_short_code` (
  `short_code` varchar(8) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `code_length` tinyint unsigned NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `set_id` int unsigned NOT NULL,
  `status` enum('ACTIVE','EXPIRED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expires_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`short_code`),
  UNIQUE KEY `uq_replay_short_target` (`room_id`,`set_id`),
  KEY `idx_replay_short_capacity` (`code_length`,`status`),
  CONSTRAINT `chk_replay_short_code` CHECK (((`code_length` in (6,7,8)) and (char_length(`short_code`) = `code_length`) and regexp_like(`short_code`,_utf8mb4'^[1-9][0-9]+$')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replay_short_code`
--

LOCK TABLES `replay_short_code` WRITE;
/*!40000 ALTER TABLE `replay_short_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `replay_short_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replay_short_code_access`
--

DROP TABLE IF EXISTS `replay_short_code_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replay_short_code_access` (
  `short_code` varchar(8) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `granted_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`short_code`,`player_id`),
  KEY `idx_replay_short_access_player` (`player_id`,`granted_at`),
  CONSTRAINT `fk_replay_short_access_code` FOREIGN KEY (`short_code`) REFERENCES `replay_short_code` (`short_code`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replay_short_code_access`
--

LOCK TABLES `replay_short_code_access` WRITE;
/*!40000 ALTER TABLE `replay_short_code_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `replay_short_code_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risk_admission_decision`
--

DROP TABLE IF EXISTS `risk_admission_decision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `risk_admission_decision` (
  `request_id` varchar(128) NOT NULL,
  `action_name` varchar(24) NOT NULL,
  `player_id` bigint NOT NULL,
  `device_hash` char(64) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  `decision_code` varchar(16) NOT NULL,
  `risk_score` smallint NOT NULL,
  `reason_codes` varchar(255) NOT NULL,
  `decided_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`request_id`,`action_name`),
  KEY `idx_admission_player_time` (`player_id`,`action_name`,`decided_at`),
  KEY `idx_admission_room_time` (`room_id`,`decided_at`),
  CONSTRAINT `chk_admission_action` CHECK ((`action_name` in (_utf8mb4'LOGIN',_utf8mb4'CREATE_ROOM',_utf8mb4'JOIN_ROOM'))),
  CONSTRAINT `chk_admission_decision` CHECK ((`decision_code` in (_utf8mb4'ALLOW',_utf8mb4'REJECT'))),
  CONSTRAINT `chk_admission_score` CHECK ((`risk_score` between 0 and 100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_admission_decision`
--

LOCK TABLES `risk_admission_decision` WRITE;
/*!40000 ALTER TABLE `risk_admission_decision` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_admission_decision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risk_event`
--

DROP TABLE IF EXISTS `risk_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `risk_event` (
  `risk_event_id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `source_signal_id` bigint NOT NULL,
  `risk_score` smallint NOT NULL,
  `reasons_json` json NOT NULL,
  `status` varchar(24) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`risk_event_id`),
  UNIQUE KEY `uk_risk_source` (`source_signal_id`),
  KEY `idx_risk_review` (`status`,`created_at`),
  CONSTRAINT `fk_risk_signal` FOREIGN KEY (`source_signal_id`) REFERENCES `telemetry_signal` (`signal_id`),
  CONSTRAINT `chk_risk_score` CHECK ((`risk_score` between 0 and 100)),
  CONSTRAINT `chk_risk_status` CHECK ((`status` in (_utf8mb4'PENDING_REVIEW',_utf8mb4'CONFIRMED',_utf8mb4'DISMISSED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_event`
--

LOCK TABLES `risk_event` WRITE;
/*!40000 ALTER TABLE `risk_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risk_review_directive`
--

DROP TABLE IF EXISTS `risk_review_directive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `risk_review_directive` (
  `directive_id` bigint NOT NULL AUTO_INCREMENT,
  `risk_event_id` bigint NOT NULL,
  `directive_type` varchar(32) NOT NULL,
  `status` varchar(16) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`directive_id`),
  UNIQUE KEY `uk_review_risk` (`risk_event_id`),
  KEY `idx_review_queue` (`status`,`directive_id`),
  CONSTRAINT `fk_review_risk` FOREIGN KEY (`risk_event_id`) REFERENCES `risk_event` (`risk_event_id`),
  CONSTRAINT `chk_review_status` CHECK ((`status` in (_utf8mb4'OPEN',_utf8mb4'CLAIMED',_utf8mb4'CLOSED'))),
  CONSTRAINT `chk_review_type` CHECK ((`directive_type` in (_utf8mb4'REVIEW_ACCOUNT',_utf8mb4'REVIEW_TABLE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_review_directive`
--

LOCK TABLES `risk_review_directive` WRITE;
/*!40000 ALTER TABLE `risk_review_directive` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_review_directive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_safety_location`
--

DROP TABLE IF EXISTS `room_safety_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_safety_location` (
  `room_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `accuracy_meters` decimal(9,2) NOT NULL,
  `observed_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`room_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_safety_location`
--

LOCK TABLES `room_safety_location` WRITE;
/*!40000 ALTER TABLE `room_safety_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_safety_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_safety_mute`
--

DROP TABLE IF EXISTS `room_safety_mute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_safety_mute` (
  `room_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `muted_by` bigint NOT NULL,
  `reason` varchar(256) NOT NULL,
  `muted_until` timestamp(3) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`room_id`,`player_id`),
  UNIQUE KEY `uq_room_mute_idem` (`muted_by`,`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_safety_mute`
--

LOCK TABLES `room_safety_mute` WRITE;
/*!40000 ALTER TABLE `room_safety_mute` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_safety_mute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_safety_report`
--

DROP TABLE IF EXISTS `room_safety_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_safety_report` (
  `report_id` varchar(36) NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `reporter_id` bigint NOT NULL,
  `target_player_id` bigint DEFAULT NULL,
  `category` varchar(24) NOT NULL,
  `detail` varchar(1000) NOT NULL,
  `status` varchar(20) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `uq_room_report_idem` (`reporter_id`,`idempotency_key`),
  KEY `ix_room_report_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_safety_report`
--

LOCK TABLES `room_safety_report` WRITE;
/*!40000 ALTER TABLE `room_safety_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_safety_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_block`
--

DROP TABLE IF EXISTS `social_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_block` (
  `blocker_id` bigint NOT NULL,
  `blocked_id` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`blocker_id`,`blocked_id`),
  KEY `ix_social_block_reverse` (`blocked_id`,`blocker_id`),
  CONSTRAINT `ck_social_block_distinct` CHECK ((`blocker_id` <> `blocked_id`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_block`
--

LOCK TABLES `social_block` WRITE;
/*!40000 ALTER TABLE `social_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_friend_request`
--

DROP TABLE IF EXISTS `social_friend_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_friend_request` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `requester_id` bigint NOT NULL,
  `recipient_id` bigint NOT NULL,
  `status` varchar(16) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  `decided_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_social_friend_request_recipient` (`recipient_id`,`status`,`id`),
  KEY `ix_social_friend_request_pair` (`requester_id`,`recipient_id`,`status`),
  CONSTRAINT `ck_social_friend_request_distinct` CHECK ((`requester_id` <> `recipient_id`)),
  CONSTRAINT `ck_social_friend_request_status` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'ACCEPTED',_utf8mb4'REJECTED',_utf8mb4'CANCELLED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_friend_request`
--

LOCK TABLES `social_friend_request` WRITE;
/*!40000 ALTER TABLE `social_friend_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_friend_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_friendship`
--

DROP TABLE IF EXISTS `social_friendship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_friendship` (
  `user_low` bigint NOT NULL,
  `user_high` bigint NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`user_low`,`user_high`),
  KEY `ix_social_friendship_high` (`user_high`,`user_low`),
  CONSTRAINT `ck_social_friendship_order` CHECK ((`user_low` < `user_high`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_friendship`
--

LOCK TABLES `social_friendship` WRITE;
/*!40000 ALTER TABLE `social_friendship` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_friendship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_mail`
--

DROP TABLE IF EXISTS `social_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_mail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipient_id` bigint NOT NULL,
  `dedupe_key` varchar(128) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_social_mail_dedupe` (`recipient_id`,`dedupe_key`),
  KEY `ix_social_mail_feed` (`recipient_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_mail`
--

LOCK TABLES `social_mail` WRITE;
/*!40000 ALTER TABLE `social_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_notice`
--

DROP TABLE IF EXISTS `social_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `content` varchar(4096) NOT NULL,
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_social_notice_active` (`published`,`starts_at`,`ends_at`,`id`),
  CONSTRAINT `ck_social_notice_window` CHECK ((`ends_at` > `starts_at`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_notice`
--

LOCK TABLES `social_notice` WRITE;
/*!40000 ALTER TABLE `social_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_notification`
--

DROP TABLE IF EXISTS `social_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_notification` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipient_id` bigint NOT NULL,
  `type` varchar(32) NOT NULL,
  `dedupe_key` varchar(128) NOT NULL,
  `payload` text NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_social_notification_dedupe` (`recipient_id`,`dedupe_key`),
  KEY `ix_social_notification_feed` (`recipient_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_notification`
--

LOCK TABLES `social_notification` WRITE;
/*!40000 ALTER TABLE `social_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_presence`
--

DROP TABLE IF EXISTS `social_presence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_presence` (
  `account_id` bigint NOT NULL,
  `state` varchar(16) NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `visibility` varchar(16) NOT NULL,
  `last_seen_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`account_id`),
  CONSTRAINT `ck_social_presence_state` CHECK ((`state` in (_utf8mb4'ONLINE',_utf8mb4'AWAY',_utf8mb4'OFFLINE'))),
  CONSTRAINT `ck_social_presence_visibility` CHECK ((`visibility` in (_utf8mb4'FRIENDS',_utf8mb4'NOBODY')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_presence`
--

LOCK TABLES `social_presence` WRITE;
/*!40000 ALTER TABLE `social_presence` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_presence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_read_cursor`
--

DROP TABLE IF EXISTS `social_read_cursor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_read_cursor` (
  `account_id` bigint NOT NULL,
  `stream` varchar(16) NOT NULL,
  `cursor_id` bigint NOT NULL,
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`account_id`,`stream`),
  CONSTRAINT `ck_social_read_cursor_nonnegative` CHECK ((`cursor_id` >= 0)),
  CONSTRAINT `ck_social_read_cursor_stream` CHECK ((`stream` in (_utf8mb4'NOTIFICATION',_utf8mb4'MAIL',_utf8mb4'NOTICE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_read_cursor`
--

LOCK TABLES `social_read_cursor` WRITE;
/*!40000 ALTER TABLE `social_read_cursor` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_read_cursor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_case`
--

DROP TABLE IF EXISTS `support_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_case` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `case_kind` enum('REPORT','APPEAL','TICKET') NOT NULL,
  `subject` varchar(120) NOT NULL,
  `description` varchar(4000) NOT NULL,
  `status` enum('OPEN','IN_REVIEW','RESOLVED','REJECTED','WITHDRAWN') NOT NULL,
  `resolution_summary` varchar(1000) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `row_version` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_support_player_list` (`player_id`,`id`),
  KEY `idx_support_handoff` (`id`,`status`,`updated_at`),
  CONSTRAINT `chk_support_version` CHECK ((`row_version` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_case`
--

LOCK TABLES `support_case` WRITE;
/*!40000 ALTER TABLE `support_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_case_event`
--

DROP TABLE IF EXISTS `support_case_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_case_event` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `actor_type` enum('PLAYER','SUPPORT','SYSTEM') NOT NULL,
  `actor_id` bigint unsigned NOT NULL,
  `event_type` varchar(40) NOT NULL,
  `case_status` enum('OPEN','IN_REVIEW','RESOLVED','REJECTED','WITHDRAWN') NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_support_event_case` (`case_id`,`id`),
  CONSTRAINT `fk_support_event_case` FOREIGN KEY (`case_id`) REFERENCES `support_case` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_case_event`
--

LOCK TABLES `support_case_event` WRITE;
/*!40000 ALTER TABLE `support_case_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_case_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_case_evidence`
--

DROP TABLE IF EXISTS `support_case_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_case_evidence` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `evidence_type` enum('REPLAY','ADMIN_CASE','URL') NOT NULL,
  `reference_id` varchar(256) NOT NULL,
  `label` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_support_evidence` (`case_id`,`evidence_type`,`reference_id`),
  CONSTRAINT `fk_support_evidence_case` FOREIGN KEY (`case_id`) REFERENCES `support_case` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_case_evidence`
--

LOCK TABLES `support_case_evidence` WRITE;
/*!40000 ALTER TABLE `support_case_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_case_evidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_live_audit`
--

DROP TABLE IF EXISTS `support_live_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_live_audit` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint unsigned NOT NULL,
  `actor_type` enum('PLAYER','SUPPORT','SYSTEM') NOT NULL,
  `actor_id` bigint unsigned NOT NULL,
  `event_type` varchar(40) NOT NULL,
  `event_detail` varchar(500) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_support_live_audit` (`session_id`,`id`),
  CONSTRAINT `fk_support_live_audit_session` FOREIGN KEY (`session_id`) REFERENCES `support_live_session` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_live_audit`
--

LOCK TABLES `support_live_audit` WRITE;
/*!40000 ALTER TABLE `support_live_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_live_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_live_idempotency`
--

DROP TABLE IF EXISTS `support_live_idempotency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_live_idempotency` (
  `actor_id` bigint unsigned NOT NULL,
  `operation_key` varchar(80) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `session_id` bigint unsigned NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`actor_id`,`operation_key`,`idempotency_key`),
  KEY `idx_support_live_idem_expiry` (`created_at`),
  KEY `fk_support_live_idem_session` (`session_id`),
  CONSTRAINT `fk_support_live_idem_session` FOREIGN KEY (`session_id`) REFERENCES `support_live_session` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_live_idempotency`
--

LOCK TABLES `support_live_idempotency` WRITE;
/*!40000 ALTER TABLE `support_live_idempotency` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_live_idempotency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_live_message`
--

DROP TABLE IF EXISTS `support_live_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_live_message` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint unsigned NOT NULL,
  `sender_type` enum('PLAYER','SUPPORT','SYSTEM') NOT NULL,
  `sender_id` bigint unsigned NOT NULL,
  `body` varchar(2000) NOT NULL,
  `media_reference` varchar(160) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_support_live_message_cursor` (`session_id`,`id`),
  CONSTRAINT `fk_support_live_message_session` FOREIGN KEY (`session_id`) REFERENCES `support_live_session` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_live_message`
--

LOCK TABLES `support_live_message` WRITE;
/*!40000 ALTER TABLE `support_live_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_live_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_live_session`
--

DROP TABLE IF EXISTS `support_live_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_live_session` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `case_id` bigint unsigned NOT NULL,
  `player_id` bigint unsigned NOT NULL,
  `agent_id` bigint unsigned DEFAULT NULL,
  `status` enum('QUEUED','ACTIVE','DISCONNECTED','CLOSED') NOT NULL,
  `active_case_id` bigint unsigned GENERATED ALWAYS AS ((case when (`status` = _utf8mb4'CLOSED') then NULL else `case_id` end)) STORED,
  `last_message_id` bigint unsigned NOT NULL DEFAULT '0',
  `close_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `closed_at` datetime(3) DEFAULT NULL,
  `row_version` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_support_live_open_case` (`active_case_id`),
  KEY `idx_support_live_queue` (`status`,`id`),
  KEY `idx_support_live_player` (`player_id`,`id`),
  KEY `idx_support_live_agent` (`agent_id`,`status`,`id`),
  KEY `fk_support_live_case` (`case_id`),
  CONSTRAINT `fk_support_live_case` FOREIGN KEY (`case_id`) REFERENCES `support_case` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_support_live_version` CHECK ((`row_version` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_live_session`
--

LOCK TABLES `support_live_session` WRITE;
/*!40000 ALTER TABLE `support_live_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_live_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telemetry_signal`
--

DROP TABLE IF EXISTS `telemetry_signal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telemetry_signal` (
  `signal_id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` varchar(64) NOT NULL,
  `player_id` bigint NOT NULL,
  `signal_kind` varchar(24) NOT NULL,
  `occurred_at` timestamp(3) NOT NULL,
  `received_at` timestamp(3) NOT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  `device_hash` char(64) DEFAULT NULL,
  `network_prefix` varchar(64) DEFAULT NULL,
  `geo_cell` varchar(32) DEFAULT NULL,
  `attributes_json` json NOT NULL,
  PRIMARY KEY (`signal_id`),
  UNIQUE KEY `uk_telemetry_player_event` (`player_id`,`event_id`),
  KEY `idx_telemetry_player_time` (`player_id`,`received_at`),
  KEY `idx_telemetry_room_device` (`room_id`,`device_hash`,`received_at`),
  KEY `idx_telemetry_room_geo` (`room_id`,`geo_cell`,`received_at`),
  CONSTRAINT `chk_telemetry_kind` CHECK ((`signal_kind` in (_utf8mb4'PERFORMANCE',_utf8mb4'CRASH',_utf8mb4'NETWORK',_utf8mb4'DEVICE',_utf8mb4'LOCATION',_utf8mb4'OPERATION')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telemetry_signal`
--

LOCK TABLES `telemetry_signal` WRITE;
/*!40000 ALTER TABLE `telemetry_signal` DISABLE KEYS */;
/*!40000 ALTER TABLE `telemetry_signal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_aoo_active_game_coverage`
--

DROP TABLE IF EXISTS `v_aoo_active_game_coverage`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_active_game_coverage`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_active_game_coverage` AS SELECT 
 1 AS `game_id`,
 1 AS `game_code`,
 1 AS `category_code`,
 1 AS `family_code`,
 1 AS `available_region_count`,
 1 AS `active_play_version_count`,
 1 AS `active_compiled_region_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_active_game_coverage_violation`
--

DROP TABLE IF EXISTS `v_aoo_active_game_coverage_violation`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_active_game_coverage_violation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_active_game_coverage_violation` AS SELECT 
 1 AS `game_id`,
 1 AS `game_code`,
 1 AS `category_code`,
 1 AS `family_code`,
 1 AS `available_region_count`,
 1 AS `active_play_version_count`,
 1 AS `active_compiled_region_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_component_completeness`
--

DROP TABLE IF EXISTS `v_aoo_component_completeness`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_component_completeness`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_component_completeness` AS SELECT 
 1 AS `game_id`,
 1 AS `play_version`,
 1 AS `component_type`,
 1 AS `binding_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_component_completeness_violation`
--

DROP TABLE IF EXISTS `v_aoo_component_completeness_violation`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_component_completeness_violation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_component_completeness_violation` AS SELECT 
 1 AS `game_id`,
 1 AS `play_version`,
 1 AS `component_type`,
 1 AS `binding_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_component_graph_violation`
--

DROP TABLE IF EXISTS `v_aoo_component_graph_violation`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_component_graph_violation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_component_graph_violation` AS SELECT 
 1 AS `violation_type`,
 1 AS `game_id`,
 1 AS `play_version`,
 1 AS `component_id`,
 1 AS `related_component_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_data_governance_gap`
--

DROP TABLE IF EXISTS `v_aoo_data_governance_gap`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_data_governance_gap`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_data_governance_gap` AS SELECT 
 1 AS `table_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_historical_reference_gap`
--

DROP TABLE IF EXISTS `v_aoo_historical_reference_gap`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_historical_reference_gap`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_historical_reference_gap` AS SELECT 
 1 AS `table_name`,
 1 AS `object_key`,
 1 AS `missing_column`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_release_preflight_violation`
--

DROP TABLE IF EXISTS `v_aoo_release_preflight_violation`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_release_preflight_violation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_release_preflight_violation` AS SELECT 
 1 AS `release_id`,
 1 AS `game_id`,
 1 AS `play_version`,
 1 AS `violation_type`,
 1 AS `violation_key`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_aoo_ui_rule_mapping_violation`
--

DROP TABLE IF EXISTS `v_aoo_ui_rule_mapping_violation`;
/*!50001 DROP VIEW IF EXISTS `v_aoo_ui_rule_mapping_violation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_aoo_ui_rule_mapping_violation` AS SELECT 
 1 AS `game_id`,
 1 AS `play_version`,
 1 AS `option_key`,
 1 AS `violation_type`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'aoo_login_fresh_verify'
--

--
-- Dumping routines for database 'aoo_login_fresh_verify'
--
/*!50003 DROP PROCEDURE IF EXISTS `aoo_activate_compiled_game_index` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `aoo_activate_compiled_game_index`(
    IN p_audit_id BIGINT UNSIGNED,
    IN p_request_id VARCHAR(64),
    IN p_game_id BIGINT UNSIGNED,
    IN p_region_code VARCHAR(32),
    IN p_play_version VARCHAR(64),
    IN p_index_generation BIGINT UNSIGNED,
    IN p_operator_id BIGINT UNSIGNED,
    IN p_action VARCHAR(16),
    IN p_reason VARCHAR(500)
)
BEGIN
    DECLARE v_guard BIGINT UNSIGNED DEFAULT NULL;
    DECLARE v_release_id BIGINT UNSIGNED DEFAULT NULL;
    DECLARE v_previous_release_id BIGINT UNSIGNED DEFAULT NULL;
    DECLARE v_next_epoch BIGINT UNSIGNED DEFAULT 1;
    DECLARE v_missing_components INT DEFAULT 0;
    DECLARE v_missing_dependencies INT DEFAULT 0;
    DECLARE v_conflicts INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    IF p_action NOT IN ('ACTIVATE','CANARY','ROLLBACK') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='unsupported release activation action';
    END IF;

    START TRANSACTION;

    SELECT game_id INTO v_guard
      FROM aoo_game_catalog
     WHERE game_id=p_game_id
     FOR UPDATE;

    SELECT MAX(release_id) INTO v_release_id
      FROM aoo_compiled_room_create_index
     WHERE game_id=p_game_id
       AND region_code=p_region_code
       AND play_version=p_play_version
       AND index_generation=p_index_generation
       AND lifecycle_state='READY';

    IF v_release_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='compiled index is absent or not READY';
    END IF;

    SELECT COUNT(*) INTO v_missing_components
      FROM aoo_component_type required_type
     WHERE required_type.required_for_active_game=1
       AND NOT EXISTS (
           SELECT 1
             FROM aoo_game_release_component released
            WHERE released.release_id=v_release_id
              AND released.component_type=required_type.component_type
       );

    SELECT COUNT(*) INTO v_missing_dependencies
      FROM aoo_game_release_component released
      JOIN aoo_component_dependency dependency
        ON dependency.component_id=released.component_id
       AND dependency.optional_dependency=0
     WHERE released.release_id=v_release_id
       AND NOT EXISTS (
           SELECT 1
             FROM aoo_game_release_component required_release
            WHERE required_release.release_id=v_release_id
              AND required_release.component_id=dependency.required_component_id
       );

    SELECT COUNT(*) INTO v_conflicts
      FROM aoo_game_release_component left_component
      JOIN aoo_component_conflict conflict
        ON conflict.component_id=left_component.component_id
      JOIN aoo_game_release_component right_component
        ON right_component.release_id=left_component.release_id
       AND right_component.component_id=conflict.conflicting_component_id
     WHERE left_component.release_id=v_release_id;

    IF v_missing_components > 0 OR v_missing_dependencies > 0 OR v_conflicts > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='release component graph validation failed';
    END IF;

    SELECT MAX(release_id),COALESCE(MAX(cache_epoch),0)+1
      INTO v_previous_release_id,v_next_epoch
      FROM aoo_compiled_index_active
     WHERE game_id=p_game_id AND region_code=p_region_code;

    UPDATE aoo_compiled_room_create_index
       SET lifecycle_state='RETIRED',retired_at=CURRENT_TIMESTAMP(3)
     WHERE game_id=p_game_id AND region_code=p_region_code
       AND lifecycle_state='ACTIVE' AND release_id<>v_release_id;

    UPDATE aoo_compiled_room_create_index
       SET lifecycle_state='ACTIVE',activated_at=CURRENT_TIMESTAMP(3),retired_at=NULL
     WHERE game_id=p_game_id AND region_code=p_region_code
       AND play_version=p_play_version AND index_generation=p_index_generation;

    INSERT INTO aoo_compiled_index_active(
        game_id,region_code,play_version,index_generation,release_id,cache_epoch,
        activated_by,activation_reason,activated_at
    ) VALUES (
        p_game_id,p_region_code,p_play_version,p_index_generation,v_release_id,v_next_epoch,
        p_operator_id,p_reason,CURRENT_TIMESTAMP(3)
    ) ON DUPLICATE KEY UPDATE
        play_version=VALUES(play_version),
        index_generation=VALUES(index_generation),
        release_id=VALUES(release_id),
        cache_epoch=VALUES(cache_epoch),
        activated_by=VALUES(activated_by),
        activation_reason=VALUES(activation_reason),
        activated_at=VALUES(activated_at);

    INSERT INTO aoo_configuration_cache_epoch(
        game_id,region_code,cache_epoch,release_id,invalidation_event_id,changed_at
    ) VALUES (
        p_game_id,p_region_code,v_next_epoch,v_release_id,p_request_id,CURRENT_TIMESTAMP(3)
    ) ON DUPLICATE KEY UPDATE
        cache_epoch=VALUES(cache_epoch),
        release_id=VALUES(release_id),
        invalidation_event_id=VALUES(invalidation_event_id),
        changed_at=VALUES(changed_at);

    UPDATE aoo_game_release
       SET status='ACTIVE',activated_at=CURRENT_TIMESTAMP(3)
     WHERE release_id=v_release_id;

    UPDATE aoo_game_release_region
       SET status='ACTIVE'
     WHERE release_id=v_release_id AND region_code=p_region_code;

    INSERT INTO aoo_game_release_audit(
        audit_id,release_id,action,operator_id,request_id,reason,before_status,
        after_status,before_active_release_id,after_active_release_id,occurred_at
    ) VALUES (
        p_audit_id,v_release_id,p_action,p_operator_id,p_request_id,p_reason,
        IF(v_previous_release_id IS NULL,NULL,'ACTIVE'),'ACTIVE',
        v_previous_release_id,v_release_id,CURRENT_TIMESTAMP(3)
    );

    INSERT INTO aoo_outbox(
        event_id,aggregate_type,aggregate_id,event_type,schema_version,payload,created_at
    ) VALUES (
        p_request_id,'GAME_RELEASE',p_game_id,'GameReleaseActivated',1,
        JSON_OBJECT(
            'gameId',p_game_id,'regionCode',p_region_code,'playVersion',p_play_version,
            'indexGeneration',p_index_generation,'releaseId',v_release_id,
            'cacheEpoch',v_next_epoch,'action',p_action
        ),CURRENT_TIMESTAMP(3)
    );

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `aoo_approve_data_repair` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `aoo_approve_data_repair`(IN p_repair_job_id BIGINT UNSIGNED)
BEGIN
    DECLARE v_requested_by BIGINT UNSIGNED;
    DECLARE v_owner_approver BIGINT UNSIGNED;
    DECLARE v_dba_approver BIGINT UNSIGNED;
    DECLARE v_scope_count INT;

    START TRANSACTION;
    SELECT requested_by INTO v_requested_by
      FROM aoo_data_repair_job
     WHERE repair_job_id=p_repair_job_id
       AND status='AWAITING_APPROVAL' AND dry_run=1
     FOR UPDATE;

    SELECT MAX(IF(approval_role='DATA_OWNER' AND decision='APPROVED',approver_id,NULL)),
           MAX(IF(approval_role='DBA' AND decision='APPROVED',approver_id,NULL)),
           COUNT(DISTINCT IF(decision='APPROVED',scope_hash,NULL))
      INTO v_owner_approver,v_dba_approver,v_scope_count
      FROM aoo_data_repair_approval
     WHERE repair_job_id=p_repair_job_id;

    IF v_owner_approver IS NULL OR v_dba_approver IS NULL OR v_scope_count<>1
       OR v_owner_approver=v_dba_approver
       OR v_owner_approver=v_requested_by OR v_dba_approver=v_requested_by THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='independent DATA_OWNER and DBA approvals with identical scope are required';
    END IF;

    UPDATE aoo_data_repair_job
       SET status='APPROVED',approved_by=v_dba_approver
     WHERE repair_job_id=p_repair_job_id;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `aoo_complete_privacy_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `aoo_complete_privacy_request`(IN p_privacy_request_id BIGINT UNSIGNED,IN p_result_manifest JSON)
BEGIN
    DECLARE v_subject_hash CHAR(64);
    DECLARE v_active_holds BIGINT UNSIGNED;

    START TRANSACTION;
    SELECT subject_id_hash INTO v_subject_hash
      FROM aoo_privacy_request
     WHERE privacy_request_id=p_privacy_request_id
       AND status='RUNNING'
     FOR UPDATE;

    SELECT COUNT(*) INTO v_active_holds
      FROM aoo_legal_hold
     WHERE scope_key_hash=v_subject_hash AND status='ACTIVE';

    IF v_active_holds>0 THEN
        UPDATE aoo_privacy_request SET status='ON_HOLD'
         WHERE privacy_request_id=p_privacy_request_id;
    ELSE
        UPDATE aoo_privacy_request
           SET status='COMPLETED',completed_at=CURRENT_TIMESTAMP(3),result_manifest=p_result_manifest
         WHERE privacy_request_id=p_privacy_request_id;
    END IF;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `aoo_finalize_migration_run` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `aoo_finalize_migration_run`(IN p_migration_run_id BIGINT UNSIGNED)
BEGIN
    DECLARE v_source_count BIGINT UNSIGNED;
    DECLARE v_target_count BIGINT UNSIGNED;
    DECLARE v_source_hash CHAR(64);
    DECLARE v_target_hash CHAR(64);
    DECLARE v_source_balance DECIMAL(38,9);
    DECLARE v_target_balance DECIMAL(38,9);
    DECLARE v_orphans BIGINT UNSIGNED;
    DECLARE v_mismatches BIGINT UNSIGNED;
    DECLARE v_failed_validations BIGINT UNSIGNED;

    START TRANSACTION;
    SELECT source_count,target_count,source_business_hash,target_business_hash,
           source_balance,target_balance,orphan_count,mismatch_count
      INTO v_source_count,v_target_count,v_source_hash,v_target_hash,
           v_source_balance,v_target_balance,v_orphans,v_mismatches
      FROM aoo_migration_run
     WHERE migration_run_id=p_migration_run_id AND status='VALIDATING'
     FOR UPDATE;

    SELECT COUNT(*) INTO v_failed_validations
      FROM aoo_migration_validation
     WHERE migration_run_id=p_migration_run_id AND passed=0;

    IF v_target_count IS NULL OR v_source_hash IS NULL OR v_target_hash IS NULL
       OR v_orphans IS NULL OR v_mismatches IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='migration evidence is incomplete';
    END IF;

    UPDATE aoo_migration_run
       SET status=IF(
               v_source_count=v_target_count
               AND v_source_hash=v_target_hash
               AND (v_source_balance <=> v_target_balance)
               AND v_orphans=0 AND v_mismatches=0 AND v_failed_validations=0,
               'PASSED','FAILED'),
           completed_at=CURRENT_TIMESTAMP(3)
     WHERE migration_run_id=p_migration_run_id;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Current Database: `aoo_login_fresh_verify`
--

USE `aoo_login_fresh_verify`;

--
-- Final view structure for view `v_aoo_active_game_coverage`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_active_game_coverage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_active_game_coverage` AS select `game`.`game_id` AS `game_id`,`game`.`game_code` AS `game_code`,`game`.`category_code` AS `category_code`,`game`.`family_code` AS `family_code`,count(distinct `region`.`region_code`) AS `available_region_count`,count(distinct `play`.`play_version`) AS `active_play_version_count`,count(distinct `active`.`region_code`) AS `active_compiled_region_count` from (((`aoo_game_catalog` `game` left join `aoo_game_region` `region` on(((`region`.`game_id` = `game`.`game_id`) and (`region`.`availability` = 'AVAILABLE')))) left join `aoo_play_version` `play` on(((`play`.`game_id` = `game`.`game_id`) and (`play`.`status` = 'ACTIVE')))) left join `aoo_compiled_index_active` `active` on((`active`.`game_id` = `game`.`game_id`))) where (`game`.`status` = 'ACTIVE') group by `game`.`game_id`,`game`.`game_code`,`game`.`category_code`,`game`.`family_code` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_active_game_coverage_violation`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_active_game_coverage_violation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_active_game_coverage_violation` AS select `v_aoo_active_game_coverage`.`game_id` AS `game_id`,`v_aoo_active_game_coverage`.`game_code` AS `game_code`,`v_aoo_active_game_coverage`.`category_code` AS `category_code`,`v_aoo_active_game_coverage`.`family_code` AS `family_code`,`v_aoo_active_game_coverage`.`available_region_count` AS `available_region_count`,`v_aoo_active_game_coverage`.`active_play_version_count` AS `active_play_version_count`,`v_aoo_active_game_coverage`.`active_compiled_region_count` AS `active_compiled_region_count` from `v_aoo_active_game_coverage` where ((`v_aoo_active_game_coverage`.`available_region_count` = 0) or (`v_aoo_active_game_coverage`.`active_play_version_count` = 0) or (`v_aoo_active_game_coverage`.`active_compiled_region_count` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_component_completeness`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_component_completeness`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_component_completeness` AS select `play`.`game_id` AS `game_id`,`play`.`play_version` AS `play_version`,`required_type`.`component_type` AS `component_type`,count(`binding`.`component_id`) AS `binding_count` from ((`aoo_play_version` `play` join `aoo_component_type` `required_type` on((`required_type`.`required_for_active_game` = 1))) left join `aoo_play_component_binding` `binding` on(((`binding`.`game_id` = `play`.`game_id`) and (`binding`.`play_version` = `play`.`play_version`) and (`binding`.`component_type` = `required_type`.`component_type`)))) where (`play`.`status` in ('VALIDATED','ACTIVE')) group by `play`.`game_id`,`play`.`play_version`,`required_type`.`component_type` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_component_completeness_violation`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_component_completeness_violation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_component_completeness_violation` AS select `v_aoo_component_completeness`.`game_id` AS `game_id`,`v_aoo_component_completeness`.`play_version` AS `play_version`,`v_aoo_component_completeness`.`component_type` AS `component_type`,`v_aoo_component_completeness`.`binding_count` AS `binding_count` from `v_aoo_component_completeness` where (`v_aoo_component_completeness`.`binding_count` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_component_graph_violation`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_component_graph_violation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_component_graph_violation` AS select 'MISSING_REQUIRED_DEPENDENCY' AS `violation_type`,`binding`.`game_id` AS `game_id`,`binding`.`play_version` AS `play_version`,`dependency`.`component_id` AS `component_id`,`dependency`.`required_component_id` AS `related_component_id` from (`aoo_play_component_binding` `binding` join `aoo_component_dependency` `dependency` on(((`dependency`.`component_id` = `binding`.`component_id`) and (`dependency`.`optional_dependency` = 0)))) where exists(select 1 from `aoo_play_component_binding` `required_binding` where ((`required_binding`.`game_id` = `binding`.`game_id`) and (`required_binding`.`play_version` = `binding`.`play_version`) and (`required_binding`.`component_id` = `dependency`.`required_component_id`))) is false union all select 'CONFLICTING_COMPONENTS' AS `violation_type`,`left_binding`.`game_id` AS `game_id`,`left_binding`.`play_version` AS `play_version`,`conflict`.`component_id` AS `component_id`,`conflict`.`conflicting_component_id` AS `related_component_id` from ((`aoo_play_component_binding` `left_binding` join `aoo_component_conflict` `conflict` on((`conflict`.`component_id` = `left_binding`.`component_id`))) join `aoo_play_component_binding` `right_binding` on(((`right_binding`.`game_id` = `left_binding`.`game_id`) and (`right_binding`.`play_version` = `left_binding`.`play_version`) and (`right_binding`.`component_id` = `conflict`.`conflicting_component_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_data_governance_gap`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_data_governance_gap`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_data_governance_gap` AS select `information_schema`.`tables`.`TABLE_NAME` AS `table_name` from (`information_schema`.`TABLES` `tables` left join `aoo_table_governance` `governance` on((`governance`.`table_name` = `information_schema`.`tables`.`TABLE_NAME`))) where ((`information_schema`.`tables`.`TABLE_SCHEMA` = database()) and (`information_schema`.`tables`.`TABLE_TYPE` = 'BASE TABLE') and (`governance`.`table_name` is null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_historical_reference_gap`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_historical_reference_gap`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_historical_reference_gap` AS select 'aoo_room_snapshot' AS `table_name`,cast(`aoo_room_snapshot`.`room_id` as char charset utf8mb4) AS `object_key`,'release_id' AS `missing_column` from `aoo_room_snapshot` where (`aoo_room_snapshot`.`release_id` is null) union all select 'aoo_room_snapshot' AS `aoo_room_snapshot`,cast(`aoo_room_snapshot`.`room_id` as char charset utf8mb4) AS `CAST(room_id AS CHAR)`,'rule_content_hash' AS `rule_content_hash` from `aoo_room_snapshot` where (`aoo_room_snapshot`.`rule_content_hash` is null) union all select 'perspective_replay_event' AS `perspective_replay_event`,concat(`perspective_replay_event`.`room_id`,':',`perspective_replay_event`.`set_id`,':',`perspective_replay_event`.`event_sequence`,':',`perspective_replay_event`.`visibility`,':',`perspective_replay_event`.`owner_player_id`) AS `Name_exp_8`,'release_id' AS `release_id` from `perspective_replay_event` where (`perspective_replay_event`.`release_id` is null) union all select 'perspective_replay_event' AS `perspective_replay_event`,concat(`perspective_replay_event`.`room_id`,':',`perspective_replay_event`.`set_id`,':',`perspective_replay_event`.`event_sequence`,':',`perspective_replay_event`.`visibility`,':',`perspective_replay_event`.`owner_player_id`) AS `Name_exp_11`,'codec_versions' AS `codec_versions` from `perspective_replay_event` where ((`perspective_replay_event`.`card_codec_version` is null) or (`perspective_replay_event`.`event_interpreter_version` is null) or (`perspective_replay_event`.`protocol_version` is null)) union all select 'perspective_replay_event_archive' AS `perspective_replay_event_archive`,concat(`perspective_replay_event_archive`.`room_id`,':',`perspective_replay_event_archive`.`set_id`,':',`perspective_replay_event_archive`.`event_sequence`,':',`perspective_replay_event_archive`.`visibility`,':',`perspective_replay_event_archive`.`owner_player_id`) AS `Name_exp_14`,'release_id' AS `release_id` from `perspective_replay_event_archive` where (`perspective_replay_event_archive`.`release_id` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_release_preflight_violation`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_release_preflight_violation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_release_preflight_violation` AS select `release_bundle`.`release_id` AS `release_id`,`release_bundle`.`game_id` AS `game_id`,`release_bundle`.`play_version` AS `play_version`,'MISSING_REQUIRED_COMPONENT' AS `violation_type`,`required_type`.`component_type` AS `violation_key` from ((`aoo_game_release` `release_bundle` join `aoo_component_type` `required_type` on((`required_type`.`required_for_active_game` = 1))) left join `aoo_game_release_component` `released` on(((`released`.`release_id` = `release_bundle`.`release_id`) and (`released`.`component_type` = `required_type`.`component_type`)))) where ((`release_bundle`.`status` in ('VALIDATED','ACTIVE')) and (`released`.`component_id` is null)) union all select `release_bundle`.`release_id` AS `release_id`,`release_bundle`.`game_id` AS `game_id`,`release_bundle`.`play_version` AS `play_version`,'MISSING_COMPILED_REGION' AS `violation_type`,`release_region`.`region_code` AS `violation_key` from ((`aoo_game_release` `release_bundle` join `aoo_game_release_region` `release_region` on((`release_region`.`release_id` = `release_bundle`.`release_id`))) left join `aoo_compiled_room_create_index` `compiled` on(((`compiled`.`release_id` = `release_bundle`.`release_id`) and (`compiled`.`region_code` = `release_region`.`region_code`)))) where ((`release_bundle`.`status` in ('VALIDATED','ACTIVE')) and (`compiled`.`release_id` is null)) union all select `release_bundle`.`release_id` AS `release_id`,`release_bundle`.`game_id` AS `game_id`,`release_bundle`.`play_version` AS `play_version`,'BUNDLE_HASH_MISMATCH' AS `violation_type`,`compiled`.`region_code` AS `violation_key` from (`aoo_game_release` `release_bundle` join `aoo_compiled_room_create_index` `compiled` on((`compiled`.`release_id` = `release_bundle`.`release_id`))) where (`compiled`.`bundle_hash` <> `release_bundle`.`bundle_hash`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_aoo_ui_rule_mapping_violation`
--

/*!50001 DROP VIEW IF EXISTS `v_aoo_ui_rule_mapping_violation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_aoo_ui_rule_mapping_violation` AS select `option_definition`.`game_id` AS `game_id`,`option_definition`.`play_version` AS `play_version`,`option_definition`.`option_key` AS `option_key`,'OPTION_WITHOUT_RULE_BINDING' AS `violation_type` from (`aoo_create_ui_option` `option_definition` left join `aoo_ui_rule_binding` `binding` on(((`binding`.`game_id` = `option_definition`.`game_id`) and (`binding`.`play_version` = `option_definition`.`play_version`) and (`binding`.`option_key` = `option_definition`.`option_key`)))) where ((`option_definition`.`status` = 'ACTIVE') and (`binding`.`option_key` is null)) union all select `rule_definition`.`game_id` AS `game_id`,`rule_definition`.`play_version` AS `play_version`,`rule_definition`.`rule_key` AS `option_key`,'REQUIRED_RULE_WITHOUT_UI_BINDING' AS `violation_type` from (`aoo_room_rule_definition` `rule_definition` left join `aoo_ui_rule_binding` `binding` on(((`binding`.`game_id` = `rule_definition`.`game_id`) and (`binding`.`play_version` = `rule_definition`.`play_version`) and (`binding`.`rule_key` = `rule_definition`.`rule_key`)))) where ((`rule_definition`.`status` = 'ACTIVE') and (`rule_definition`.`required_value` = 1) and (`binding`.`rule_key` is null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-26 20:03:44
